using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using MyAverisEntity;
using System.ComponentModel;
using Newtonsoft.Json;
using MyAverisClient;
using MyAverisCommon;
using Android.Animation;

namespace MyAa.Droid
{
    [Activity(Label = "DeclarationActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class DeclarationActivity : AppCompatActivity
    {
        ProgressDialog _processProgress;
        string strLookupResult, strSubmitResult;
        List<DeclarationDetail> declarations;
        Android.Support.V7.Widget.Toolbar toolbar;
        int index = 0;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.Declaration);

            toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Declaration);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            toolbar.FindViewById<TextView>(Resource.Id.lblDone).Click += Done_OnClick;
            toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Click += Submit_OnClick;
            FindViewById<RadioButton>(Resource.Id.rbAgree).CheckedChange += Agree_OnCheckedChange;
            FindViewById<RadioButton>(Resource.Id.rbYes).CheckedChange += Yes_OnCheckedChange;
            FindViewById<RadioButton>(Resource.Id.rbNo).CheckedChange += No_OnCheckedChange;

            _processProgress = new ProgressDialog(this);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);
            _processProgress.Show();

            BackgroundWorker lookupWorker = new BackgroundWorker();
            lookupWorker.DoWork += lookupWorker_DoWork;
            lookupWorker.RunWorkerCompleted += lookupWorker_RunWorkerCompleted;
            lookupWorker.RunWorkerAsync();
        }

        void Agree_OnCheckedChange(object sender, EventArgs e)
        {
            if (FindViewById<RadioButton>(Resource.Id.rbAgree).Checked)
                toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Visible;
            else
                toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Gone;
        }

        void No_OnCheckedChange(object sender, EventArgs e)
        {
            if (FindViewById<RadioButton>(Resource.Id.rbNo).Checked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblDone).Visibility = ViewStates.Visible;
            }
        }

        void Yes_OnCheckedChange(object sender, EventArgs e)
        {
            if (FindViewById<RadioButton>(Resource.Id.rbYes).Checked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblDone).Visibility = ViewStates.Visible;

                //expand
                FindViewById<LinearLayout>(Resource.Id.layRemarks).Visibility = ViewStates.Visible;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layRemarks).Measure(widthSpec, heightSpec);

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layRemarks), 0, FindViewById<LinearLayout>(Resource.Id.layRemarks).MeasuredHeight);
                mAnimator.Start();
            }
            else
            {
                //collapse;
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layRemarks).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layRemarks), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layRemarks).Visibility = ViewStates.Gone;
                };
            }
        }

        private ValueAnimator SlideAnimator(LinearLayout mLinearLayout, int start, int end)
        {
            ValueAnimator animator = ValueAnimator.OfInt(start, end);
            animator.Update +=
                (object sender, ValueAnimator.AnimatorUpdateEventArgs e) =>
                {
                    var value = (int)animator.AnimatedValue;
                    ViewGroup.LayoutParams layoutParams = mLinearLayout.LayoutParameters;
                    layoutParams.Height = value;
                    mLinearLayout.LayoutParameters = layoutParams;
                };
            return animator;
        }

        void Submit_OnClick(object sender, EventArgs e)
        {
            _processProgress.Show();

            BackgroundWorker jobAppWorker = new BackgroundWorker();
            jobAppWorker.DoWork += jobAppWorker_DoWork;
            jobAppWorker.RunWorkerCompleted += jobAppWorker_RunWorkerCompleted;
            jobAppWorker.RunWorkerAsync();
        }

        void Done_OnClick(object sender, EventArgs e)
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (CacheManager.JobInfo.Declarations == null)
                CacheManager.JobInfo.Declarations = new List<JobApplicationDeclarationInfo>();

            if (declarations != null && declarations.Count > 0)
            {
                List<JobApplicationDeclarationInfo> test = CacheManager.JobInfo.Declarations;
                var declaration = (from item in CacheManager.JobInfo.Declarations
                                   where item.DeclarationID == declarations[index].ID
                                   select item).FirstOrDefault();
                if (declaration != null)
                {
                    declaration.Answer = FindViewById<RadioButton>(Resource.Id.rbYes).Checked;
                    declaration.Remarks = FindViewById<EditText>(Resource.Id.etRemarks).Text;
                }
                else
                {
                    CacheManager.JobInfo.Declarations.Add(new JobApplicationDeclarationInfo()
                        {
                            DeclarationID = declarations[index].ID,
                            Answer = FindViewById<RadioButton>(Resource.Id.rbYes).Checked,
                            Remarks = FindViewById<EditText>(Resource.Id.etRemarks).Text
                        });
                }

                test = CacheManager.JobInfo.Declarations;

                JobApplicationDeclaration model = new JobApplicationDeclaration()
                {
                    DeclarationID = declarations[index].ID,
                    Answer = FindViewById<RadioButton>(Resource.Id.rbYes).Checked,
                    Remarks = FindViewById<EditText>(Resource.Id.etRemarks).Text
                };

                Database.UpdateDeclaration(model);
            }

            if (declarations != null && declarations.Count - 1 > index)
            {
                index++;
                FindViewById<EditText>(Resource.Id.etRemarks).Text = string.Empty;
                toolbar.FindViewById<TextView>(Resource.Id.lblDone).Visibility = ViewStates.Gone;
                FindViewById<LinearLayout>(Resource.Id.layAgreement).Visibility = ViewStates.Gone;
                FindViewById<LinearLayout>(Resource.Id.layDeclarationDetails).Visibility = ViewStates.Visible;

                if (CacheManager.AppLanguage == "Bahasa Indonesia")
                    FindViewById<TextView>(Resource.Id.tvDeclarationText).Text = declarations[index].DeclarationIndo;
                else
                    FindViewById<TextView>(Resource.Id.tvDeclarationText).Text = declarations[index].Declaration;

                JobApplicationDeclarationInfo detail = GetDeclarationDetail(declarations[index].ID);
                if (detail != null)
                {
                    toolbar.FindViewById<TextView>(Resource.Id.lblDone).Visibility = ViewStates.Visible;
                    if (detail.Answer.GetValueOrDefault())
                    {
                        FindViewById<RadioButton>(Resource.Id.rbYes).Checked = true;
                        FindViewById<EditText>(Resource.Id.etRemarks).Text = detail.Remarks;

                        //expand
                        FindViewById<LinearLayout>(Resource.Id.layRemarks).Visibility = ViewStates.Visible;
                        int widthSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                        int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                        FindViewById<LinearLayout>(Resource.Id.layRemarks).Measure(widthSpec, heightSpec);

                        ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layRemarks), 0, FindViewById<LinearLayout>(Resource.Id.layRemarks).MeasuredHeight);
                        mAnimator.Start();
                    }
                    else
                    {
                        FindViewById<RadioButton>(Resource.Id.rbNo).Checked = true;
                    }
                }
                else
                {
                    FindViewById<RadioGroup>(Resource.Id.rgAnswer).ClearCheck();

                    //collapse;
                    int finalHeight = FindViewById<LinearLayout>(Resource.Id.layRemarks).Height;

                    ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layRemarks), finalHeight, 0);
                    mAnimator.Start();
                    mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                    {
                        FindViewById<LinearLayout>(Resource.Id.layRemarks).Visibility = ViewStates.Gone;
                    };
                }
            }
            else
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblDone).Visibility = ViewStates.Gone;
                FindViewById<LinearLayout>(Resource.Id.layAgreement).Visibility = ViewStates.Visible;
                FindViewById<LinearLayout>(Resource.Id.layDeclarationDetails).Visibility = ViewStates.Gone;
            }
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            base.OnBackPressed();
        }

        private JobApplicationDeclarationInfo GetDeclarationDetail(Guid id)
        {
            if (CacheManager.JobInfo.Declarations != null)
            {
                var detail = (from item in CacheManager.JobInfo.Declarations
                              where item.DeclarationID == id
                              select item).FirstOrDefault();
                return detail;
            }
            return null;
        }

        void lookupWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("ApplicationType", CacheManager.ApplicationType));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strLookupResult = client.ProcessRequest("GetDeclarationDetails", headers);
        }

        void lookupWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strLookupResult))
                {
                    List<DeclarationDetailInfo> info = JsonConvert.DeserializeObject<List<DeclarationDetailInfo>>(strLookupResult);
                    var details = (from item in info
                                   select new DeclarationDetail()
                                   {
                                       ID = item.ID,
                                       No = item.No.GetValueOrDefault(),
                                       Declaration = item.Declaration,
                                       DeclarationIndo = item.DeclarationIndo
                                   }).ToList();

                    if (details != null && details.Count > 0)
                        Database.UpdateDeclarationDetails(details);

                    declarations = Database.GetDeclarationDetails();

                    if (declarations != null && declarations.Count > 0)
                    {
                        index = 0;
                        toolbar.FindViewById<TextView>(Resource.Id.lblDone).Visibility = ViewStates.Gone;
                        FindViewById<LinearLayout>(Resource.Id.layAgreement).Visibility = ViewStates.Gone;
                        FindViewById<LinearLayout>(Resource.Id.layDeclarationDetails).Visibility = ViewStates.Visible;

                        if (CacheManager.AppLanguage == "Bahasa Indonesia")
                            FindViewById<TextView>(Resource.Id.tvDeclarationText).Text = declarations[index].DeclarationIndo;
                        else
                            FindViewById<TextView>(Resource.Id.tvDeclarationText).Text = declarations[index].Declaration;

                        JobApplicationDeclarationInfo detail = GetDeclarationDetail(declarations[index].ID);
                        if (detail != null)
                        {
                            toolbar.FindViewById<TextView>(Resource.Id.lblDone).Visibility = ViewStates.Visible;
                            if (detail.Answer.GetValueOrDefault())
                            {
                                FindViewById<RadioButton>(Resource.Id.rbYes).Checked = true;
                                FindViewById<RadioButton>(Resource.Id.rbNo).Checked = false;
                                FindViewById<EditText>(Resource.Id.etRemarks).Text = detail.Remarks;

                                //expand
                                FindViewById<LinearLayout>(Resource.Id.layRemarks).Visibility = ViewStates.Visible;
                                int widthSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                                FindViewById<LinearLayout>(Resource.Id.layRemarks).Measure(widthSpec, heightSpec);

                                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layRemarks), 0, FindViewById<LinearLayout>(Resource.Id.layRemarks).MeasuredHeight);
                                mAnimator.Start();
                            }
                            else
                            {
                                FindViewById<RadioButton>(Resource.Id.rbNo).Checked = true;
                                FindViewById<RadioButton>(Resource.Id.rbYes).Checked = false;
                            }
                        }
                    }
                    else
                    {
                        toolbar.FindViewById<TextView>(Resource.Id.lblDone).Visibility = ViewStates.Gone;
                        FindViewById<LinearLayout>(Resource.Id.layAgreement).Visibility = ViewStates.Visible;
                        FindViewById<LinearLayout>(Resource.Id.layDeclarationDetails).Visibility = ViewStates.Gone;
                    }
                }
            }
            catch
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.EnableInternet));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                    Finish();
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
            try { _processProgress.Dismiss(); }
            catch { }
        }

        void jobAppWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            JobApplicationInfo model = CacheManager.JobInfo;
            model.Photo = null;

            string requestData = JsonConvert.SerializeObject(model,
                                              new JsonSerializerSettings() { DateFormatHandling = DateFormatHandling.MicrosoftDateFormat });
            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, requestData);
            strSubmitResult = client.ProcessRequest("SubmitJobApplication", headers);
        }

        void jobAppWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strSubmitResult))
                {
                    if (strSubmitResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strSubmitResult.ToUpper().Contains("LOCKED FOR VERIFICATION"))
                    {
                        CacheManager.JobInfo.IsLocked = true;
                        CacheManager.IsLocked = CacheManager.JobInfo.IsLocked.GetValueOrDefault();

                        JobApplication app = Database.GetJobApplication();
                        app.IsLocked = true;
                        Database.UpdateJobApplication(app);

                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.LockedInfoText));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            Finish();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strSubmitResult.ToUpper().Contains(InitialData.NewApplicationStatus.Rejected))
                    {
                        CacheManager.JobInfo.ApplicationStatus = InitialData.NewApplicationStatus.Rejected;

                        JobApplication app = Database.GetJobApplication();
                        app.ApplicationStatus = InitialData.NewApplicationStatus.Rejected;

                        Database.UpdateJobApplication(app);

                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.AppComplete));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            Finish();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strSubmitResult.ToUpper().Contains(InitialData.NewApplicationStatus.Accepted))
                    {
                        CacheManager.JobInfo.ApplicationStatus = InitialData.NewApplicationStatus.Accepted;

                        JobApplication app = Database.GetJobApplication();
                        app.ApplicationStatus = InitialData.NewApplicationStatus.Accepted;

                        Database.UpdateJobApplication(app);

                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.AppComplete));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            Finish();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.FailUpdate));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                }
                else
                {
                    Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                    alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                    alert.SetMessage(this.Resources.GetString(Resource.String.SubmitSuccess));
                    alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                    {
                        Finish();
                    });

                    RunOnUiThread(() =>
                    {
                        alert.Show();
                    });

                    if(CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.New)
                        CacheManager.JobInfo.ApplicationStatus = InitialData.NewApplicationStatus.Submitted;

                    JobApplication app = Database.GetJobApplication();
                    app.ApplicationStatus = CacheManager.JobInfo.ApplicationStatus;

                    Database.UpdateJobApplication(app);
                }
            }
            catch { }
            try { _processProgress.Dismiss(); }
            catch { }
        }
    }
}