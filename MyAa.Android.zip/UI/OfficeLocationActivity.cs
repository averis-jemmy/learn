using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using Android.Animation;
using Android.Graphics;
using System.ComponentModel;
using MyAverisClient;
using Newtonsoft.Json;
using MyAverisEntity;
using Android.Text.Method;
using Android.Text;
using Android.Gms.Maps.Model;
using Android.Gms.Maps;

namespace MyAa.Droid
{
    [Activity(Label = "OfficeLocationActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class OfficeLocationActivity : AppCompatActivity
    {
        bool medanExpand = false, pekanbaruExpand = false, jakartaExpand = false, jambiExpand = false;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.OfficeLocation);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.OfficeLocationTitle);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            medanExpand = false;
            pekanbaruExpand = false;
            jakartaExpand = false;
            jambiExpand = false;
            FindViewById<RelativeLayout>(Resource.Id.layMedanOfficeLoc).Click += MedanOffice_OnClick;
            FindViewById<RelativeLayout>(Resource.Id.layPekanbaruOfficeLoc).Click += PekanbaruOffice_OnClick;
            FindViewById<RelativeLayout>(Resource.Id.layJakartaOfficeLoc).Click += JakartaOffice_OnClick;
            FindViewById<RelativeLayout>(Resource.Id.layJambiOfficeLoc).Click += JambiOffice_OnClick;

            FindViewById<ImageView>(Resource.Id.imgMedanWaze).Click += MedanWaze_Click;
            FindViewById<ImageView>(Resource.Id.imgMedanGoogleMap).Click += MedanMap_Click;
            FindViewById<ImageView>(Resource.Id.imgPekanbaruWaze).Click += PekanbaruWaze_Click;
            FindViewById<ImageView>(Resource.Id.imgPekanbaruGoogleMap).Click += PekanbaruMap_Click;
            FindViewById<ImageView>(Resource.Id.imgJakartaWaze).Click += JakartaWaze_Click;
            FindViewById<ImageView>(Resource.Id.imgJakartaGoogleMap).Click += JakartaMap_Click;
            FindViewById<ImageView>(Resource.Id.imgJambiWaze).Click += JambiWaze_Click;
            FindViewById<ImageView>(Resource.Id.imgJambiGoogleMap).Click += JambiMap_Click;

            CacheManager.ProcessProgress.Dismiss();
        }

        void MedanWaze_Click(object sender, EventArgs e)
        {
            var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://waze.to/?ll=3.586529,98.682246&navigate=yes"));
            StartActivity(intent);
        }

        void MedanMap_Click(object sender, EventArgs e)
        {
            var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://maps.google.com/maps?daddr=3.586529,98.682246"));
            StartActivity(intent);
        }

        void PekanbaruWaze_Click(object sender, EventArgs e)
        {
            var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://waze.to/?ll=0.480265,101.418792&navigate=yes"));
            StartActivity(intent);
        }

        void PekanbaruMap_Click(object sender, EventArgs e)
        {
            var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://maps.google.com/maps?daddr=0.480265,101.418792"));
            StartActivity(intent);
        }

        void JakartaWaze_Click(object sender, EventArgs e)
        {
            var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://waze.to/?ll=-6.197907,106.822799&navigate=yes"));
            StartActivity(intent);
        }

        void JakartaMap_Click(object sender, EventArgs e)
        {
            var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://maps.google.com/maps?daddr=-6.197907,106.822799"));
            StartActivity(intent);
        }

        void JambiWaze_Click(object sender, EventArgs e)
        {
            var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://waze.to/?ll=-1.632887,103.620969&navigate=yes"));
            StartActivity(intent);
        }

        void JambiMap_Click(object sender, EventArgs e)
        {
            var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://maps.google.com/maps?daddr=-1.632887,103.620969"));
            StartActivity(intent);
        }

        private void MedanOffice_OnClick(object sender, EventArgs e)
        {
            if (medanExpand)
            {
                medanExpand = false;
                FindViewById<ImageView>(Resource.Id.imgMedanOfficeLoc).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layMedanOfficeLocDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layMedanOfficeLocDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layMedanOfficeLocDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                medanExpand = true;
                FindViewById<ImageView>(Resource.Id.imgMedanOfficeLoc).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layMedanOfficeLocDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layMedanOfficeLocDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layMedanOfficeLocDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layMedanOfficeLocDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layMedanOfficeLocDes), 0, height);
                mAnimator.Start();
            }
        }

        private void PekanbaruOffice_OnClick(object sender, EventArgs e)
        {
            if (pekanbaruExpand)
            {
                pekanbaruExpand = false;
                FindViewById<ImageView>(Resource.Id.imgPekanbaruOfficeLoc).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeLocDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeLocDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeLocDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                pekanbaruExpand = true;
                FindViewById<ImageView>(Resource.Id.imgPekanbaruOfficeLoc).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeLocDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeLocDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeLocDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeLocDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeLocDes), 0, height);
                mAnimator.Start();
            }
        }

        private void JakartaOffice_OnClick(object sender, EventArgs e)
        {
            if (jakartaExpand)
            {
                jakartaExpand = false;
                FindViewById<ImageView>(Resource.Id.imgJakartaOfficeLoc).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeLocDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeLocDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeLocDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                jakartaExpand = true;
                FindViewById<ImageView>(Resource.Id.imgJakartaOfficeLoc).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeLocDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeLocDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeLocDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeLocDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeLocDes), 0, height);
                mAnimator.Start();
            }
        }

        private void JambiOffice_OnClick(object sender, EventArgs e)
        {
            if (jambiExpand)
            {
                jambiExpand = false;
                FindViewById<ImageView>(Resource.Id.imgJambiOfficeLoc).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layJambiOfficeLocDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layJambiOfficeLocDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layJambiOfficeLocDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                jambiExpand = true;
                FindViewById<ImageView>(Resource.Id.imgJambiOfficeLoc).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layJambiOfficeLocDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layJambiOfficeLocDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layJambiOfficeLocDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layJambiOfficeLocDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layJambiOfficeLocDes), 0, height);
                mAnimator.Start();
            }
        }

        private ValueAnimator SlideAnimator(LinearLayout mLinearLayout, int start, int end)
        {
            ValueAnimator animator = ValueAnimator.OfInt(start, end);
            animator.Update +=
                (object sender, ValueAnimator.AnimatorUpdateEventArgs e) =>
                {
                    var value = (int)animator.AnimatedValue;
                    ViewGroup.LayoutParams layoutParams = mLinearLayout.LayoutParameters;
                    layoutParams.Height = value;
                    mLinearLayout.LayoutParameters = layoutParams;
                };
            return animator;
        }

        protected override void OnResume()
        {
            base.OnResume();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        protected override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }
    }
}