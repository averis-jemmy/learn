﻿using System;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using System.ComponentModel;
using MyAverisClient;
using System.Collections.Generic;
using MyAverisEntity;
using Newtonsoft.Json;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using Android.Support.V4.Widget;
using Android.Support.V7.App;
using Android.Support.Design.Widget;
using Android.Views.InputMethods;
using MyAverisCommon;
using Android.Gms.Common;
using Android.Util;
using Android.Support.V4.Content;
using Android.Preferences;
using System.IO;
using Android.Gms.Gcm.Iid;

namespace MyAa.Droid
{
    [Activity(Label = "MYAA", Theme = "@style/MyTheme.Base", WindowSoftInputMode = SoftInput.StateHidden, Icon = "@drawable/icon", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class MainActivity : AppCompatActivity
    {
        ProgressDialog _processProgress;
        string strResult, strLookupResult;

        Android.Support.V7.Widget.Toolbar toolbar;
        DrawerLayout drawerLayout;
        NavigationView navigationView;

        const int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
        const string TAG = "LoginActivity";

        BroadcastReceiver mRegistrationBroadcastReceiver;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            CacheManager.RestoreData();
            CacheManager.Init(Application.Context);
            CacheManager.InitLanguage(this);

            ServicePointManager.ServerCertificateValidationCallback =
                delegate(System.Object obj, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
                {
                    return (true);
                };
            System.Security.Cryptography.AesCryptoServiceProvider b = new System.Security.Cryptography.AesCryptoServiceProvider();
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            try
            {
                if (string.IsNullOrEmpty(Database.GetAppLanguage()))
                    Database.UpdateSettings("English");

                CacheManager.AppLanguage = Database.GetAppLanguage();

                var user = CacheManager.GetFromSharedPreferences();//Database.GetUser();

                if (user == null)
                {
                    var intent = new Intent(this, typeof(DiscoverAAActivity));
                    StartActivity(intent);
                    Finish();
                }
                else
                {
                    CacheManager.TokenID = user.TokenID;
                    CacheManager.UserID = user.UserID;
                    CacheManager.IsRecruiter = user.IsRecruiter;
                    CacheManager.HasProfilePicture = user.HasProfilePicture;
                    CacheManager.PositionApplied = user.PositionApplied;

                    mRegistrationBroadcastReceiver = new BroadcastReceiver();
                    mRegistrationBroadcastReceiver.Receive += (sender, e) =>
                    {
                        var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences((Context)sender);
                        var sentToken = sharedPreferences.GetBoolean(QuickstartPreferences.SENT_TOKEN_TO_SERVER, false);
                    };

                    if (CheckPlayServices())
                    {
                        var intent = new Intent(this, typeof(RegistrationIntentService));
                        StartService(intent);
                    }

                    SetContentView(Resource.Layout.Main);
                    drawerLayout = FindViewById<DrawerLayout>(Resource.Id.drawerLayout);

                    CacheManager.LoadData();

                    // Initialize toolbar
                    toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetTitle(Resource.String.MyAa);
                    //SupportActionBar.SetIcon(Resource.Drawable.Icon);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                    toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Click += Submit_OnClick;
                    toolbar.FindViewById<TextView>(Resource.Id.lblRefresh).Click += Refresh_OnClick;

                    // Attach item selected handler to navigation view
                    navigationView = FindViewById<NavigationView>(Resource.Id.navView);
                    navigationView.NavigationItemSelected += NavigationView_NavigationItemSelected;
                    navigationView.Menu.Clear();
                    if (!CacheManager.IsRecruiter)
                    {
                        navigationView.InflateMenu(Resource.Menu.menu_applicant);
                    }
                    else
                    {
                        navigationView.InflateMenu(Resource.Menu.menu_recruiter);
                    }

                    // Create ActionBarDrawerToggle button and add it to the toolbar
                    var drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, Resource.String.open_drawer, Resource.String.close_drawer);
                    drawerLayout.AddDrawerListener(drawerToggle);
                    drawerToggle.SyncState();

                    //Load default screen
                    var ft = FragmentManager.BeginTransaction();
                    //ft.AddToBackStack(null);
                    ft.Add(Resource.Id.HomeFrameLayout, new HomeFragment());
                    ft.Commit();

                    FindViewById<Button>(Resource.Id.nav_logout).Click += LogoutButton_OnClick;

                    _processProgress = new ProgressDialog(this);
                    _processProgress.Indeterminate = true;
                    _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
                    _processProgress.SetMessage("Loading...");
                    _processProgress.SetCancelable(false);
                    _processProgress.Show();

                    BackgroundWorker lookupWorker = new BackgroundWorker();
                    lookupWorker.DoWork += lookupWorker_DoWork;
                    lookupWorker.RunWorkerCompleted += lookupWorker_RunWorkerCompleted;
                    lookupWorker.RunWorkerAsync();
                }
            }
            catch (Exception ex)
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(ex.Message + "\t" + ex.StackTrace);
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                    var intent = new Intent(this, typeof(MainActivity));
                    StartActivity(intent);
                    FinishAffinity();
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        public override void OnBackPressed()
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle(this.Resources.GetString(Resource.String.Info));
            alert.SetMessage(this.Resources.GetString(Resource.String.ExitConfirmation));
            alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
            {
                FinishAffinity();
            });
            alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
            {
            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        void Submit_OnClick(object sender, EventArgs e)
        {
            if (ValidateData() && !CacheManager.IsLocked)
            {
                var intent = new Intent(this, typeof(DeclarationActivity));
                StartActivity(intent);
            }
        }

        void Refresh_OnClick(object sender, EventArgs e)
        {
            //Load default screen
            var ft = FragmentManager.BeginTransaction();
            ft.Replace(Resource.Id.HomeFrameLayout, new ApplicationListFragment());
            ft.Commit();
        }

        protected override void OnPause()
        {
            GC.Collect();
            LocalBroadcastManager.GetInstance(this).UnregisterReceiver(mRegistrationBroadcastReceiver);
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        protected override void OnResume()
        {
            base.OnResume();
            LocalBroadcastManager.GetInstance(this).RegisterReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(QuickstartPreferences.REGISTRATION_COMPLETE));

            try
            {
                if (CacheManager.IsLocked)
                    toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Gone;

                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }
        }

        public void UpdateControl()
        {
            try
            {
                if (CacheManager.IsLocked)
                    toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Gone;
                else
                    toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Visible;
            }
            catch { }
        }

        bool CheckPlayServices()
        {
            int resultCode = GooglePlayServicesUtil.IsGooglePlayServicesAvailable(this);
            if (resultCode != ConnectionResult.Success)
            {
                if (GooglePlayServicesUtil.IsUserRecoverableError(resultCode))
                {
                    GooglePlayServicesUtil.GetErrorDialog(resultCode, this,
                        PLAY_SERVICES_RESOLUTION_REQUEST).Show();
                }
                else
                {
                    Log.Info(TAG, "This device is not supported.");
                    Finish();
                }
                return false;
            }
            return true;
        }

        class BroadcastReceiver : Android.Content.BroadcastReceiver
        {
            public EventHandler<BroadcastEventArgs> Receive { get; set; }

            public override void OnReceive(Context context, Intent intent)
            {
                if (Receive != null)
                    Receive(context, new BroadcastEventArgs(intent));
            }
        }

        class BroadcastEventArgs : EventArgs
        {
            public Intent Intent { get; private set; }

            public BroadcastEventArgs(Intent intent)
            {
                Intent = intent;
            }
        }

        void NavigationView_NavigationItemSelected(object sender, NavigationView.NavigationItemSelectedEventArgs e)
        {
            if (!e.MenuItem.IsChecked)
            {
                var ft = FragmentManager.BeginTransaction();
                toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Gone;
                toolbar.FindViewById<TextView>(Resource.Id.lblRefresh).Visibility = ViewStates.Gone;
                SupportActionBar.SetTitle(Resource.String.MyAa);
                switch (e.MenuItem.ItemId)
                {
                    case (Resource.Id.navHome):
                        ft.Replace(Resource.Id.HomeFrameLayout, new HomeFragment());
                        break;
                    case (Resource.Id.navApplicationForm):
                        SupportActionBar.SetTitle(Resource.String.ApplicationForm);
                        if (!CacheManager.IsLocked && CacheManager.JobInfo != null &&
                            CacheManager.JobInfo.ApplicationStatus != InitialData.NewApplicationStatus.Accepted &&
                            CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Rejected)
                        {
                            toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Visible;
                        }
                        ft.Replace(Resource.Id.HomeFrameLayout, new ApplicationFormFragment());
                        break;
                    case (Resource.Id.navApplicationStatus):
                        SupportActionBar.SetTitle(Resource.String.ApplicationForm);
                        ft.Replace(Resource.Id.HomeFrameLayout, new ApplicationStatusFragment());
                        break;
                    case (Resource.Id.navApplicationList):
                        SupportActionBar.SetTitle(Resource.String.ApplicationList);
                        toolbar.FindViewById<TextView>(Resource.Id.lblRefresh).Visibility = ViewStates.Visible;
                        ft.Replace(Resource.Id.HomeFrameLayout, new ApplicationListFragment());
                        break;
                    case (Resource.Id.navPhoto):
                        SupportActionBar.SetTitle(Resource.String.Photo);
                        ft.Replace(Resource.Id.HomeFrameLayout, new PhotoFragment());
                        break;
                    case (Resource.Id.navVideo):
                        SupportActionBar.SetTitle(Resource.String.Video);
                        ft.Replace(Resource.Id.HomeFrameLayout, new VideoFragment());
                        break;
                    case (Resource.Id.navPreBoarding):
                        SupportActionBar.SetTitle(Resource.String.AaInfo);
                        ft.Replace(Resource.Id.HomeFrameLayout, new PreBoardingFragment());
                        break;
                    case (Resource.Id.navLanguage):
                        SupportActionBar.SetTitle(Resource.String.Language);
                        ft.Replace(Resource.Id.HomeFrameLayout, new LanguageFragment());
                        break;
                }
                ft.Commit();
            }
            drawerLayout.CloseDrawers();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    drawerLayout.OpenDrawer(Android.Support.V4.View.GravityCompat.Start);
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        void LogoutButton_OnClick(object sender, EventArgs e)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle(this.Resources.GetString(Resource.String.LogoutText));
            alert.SetMessage(this.Resources.GetString(Resource.String.LogoutConfirmation));
            if (CacheManager.JobInfo != null && CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.New)
                alert.SetMessage(this.Resources.GetString(Resource.String.LogoutConfirmation2));
            alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
            {
                CacheManager.ClearSharedPreferences();
                Database.ClearData();
                CacheManager.JobInfo = null;
                CacheManager.ProfileBitmap = null;
                try
                {
                    var instanceID = InstanceID.GetInstance(this);
                    instanceID.DeleteInstanceID();
                }
                catch { }
                var intent = new Intent(this, typeof(MainActivity));
                StartActivity(intent);
                FinishAffinity();
            });
            alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
            {
            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        void lookupWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("ApplicationType", CacheManager.ApplicationType));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strLookupResult = client.ProcessRequest("GetDeclarationDetails", headers);
        }

        void lookupWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strLookupResult))
                {
                    List<DeclarationDetailInfo> info = JsonConvert.DeserializeObject<List<DeclarationDetailInfo>>(strLookupResult);
                    var details = (from item in info
                                   select new DeclarationDetail()
                                   {
                                       ID = item.ID,
                                       No = item.No.GetValueOrDefault(),
                                       Declaration = item.Declaration,
                                       DeclarationIndo = item.DeclarationIndo
                                   }).ToList();

                    if (details != null && details.Count > 0)
                        Database.UpdateDeclarationDetails(details);
                }
            }
            catch { }

            if (!CacheManager.IsRecruiter)
            {
                if (CacheManager.JobInfo == null)
                {
                    BackgroundWorker worker = new BackgroundWorker();
                    worker.DoWork += worker_DoWork;
                    worker.RunWorkerCompleted += worker_RunWorkerCompleted;
                    worker.RunWorkerAsync();
                }
                else
                {
                    if (CacheManager.JobInfo != null && CacheManager.FromNotification)
                    {
                        BackgroundWorker shortWorker = new BackgroundWorker();
                        shortWorker.DoWork += shortWorker_DoWork;
                        shortWorker.RunWorkerCompleted += shortWorker_RunWorkerCompleted;
                        shortWorker.RunWorkerAsync();
                    }
                    else
                    {
                        try { _processProgress.Dismiss(); }
                        catch { }
                    }
                }
            }
            else
            {
                try { _processProgress.Dismiss(); }
                catch { }
            }
        }

        void shortWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetJobApplicationStatus", headers);
        }

        void shortWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        if (CacheManager.JobInfo == null)
                        {
                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                            alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                            alert.SetMessage(this.Resources.GetString(Resource.String.EnableInternet));
                            alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                            {
                                var intent = new Intent(this, typeof(MainActivity));
                                StartActivity(intent);
                                FinishAffinity();
                            });

                            RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                        }
                    }
                    else
                    {
                        ShortJobApplicationInfo info = null;
                        try
                        {
                            info = JsonConvert.DeserializeObject<ShortJobApplicationInfo>(strResult);
                        }
                        catch { }

                        CacheManager.PositionApplied = info.PositionApplied;
                        Database.UpdateUserPositionApplied(info.PositionApplied);
                        var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(this);
                        try
                        {
                            sharedPreferences.Edit().PutString(QuickstartPreferences.POSITION_APPLIED, info.PositionApplied).Apply();
                        }
                        catch { }

                        CacheManager.JobInfo.ApplicationStatus = info.ApplicationStatus;
                        CacheManager.JobInfo.IsLocked = info.IsLocked;
                        CacheManager.IsLocked = CacheManager.JobInfo.IsLocked.GetValueOrDefault();

                        JobApplication app = Database.GetJobApplication();
                        app.ApplicationStatus = info.ApplicationStatus;
                        app.IsLocked = info.IsLocked.GetValueOrDefault();

                        Database.UpdateJobApplication(app);

                        try
                        {
                            toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Gone;
                        }
                        catch { }

                        if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Accepted)
                        {
                            var ft = FragmentManager.BeginTransaction();
                            CacheManager.FromNotification = false;
                            SupportActionBar.SetTitle(Resource.String.AaInfo);
                            ft.Replace(Resource.Id.HomeFrameLayout, new PreBoardingFragment());
                            ft.Commit();
                            navigationView.Menu.GetItem(4).SetChecked(true);
                        }
                        else
                        {
                            var ft = FragmentManager.BeginTransaction();
                            CacheManager.FromNotification = false;
                            SupportActionBar.SetTitle(Resource.String.AaInfo);
                            ft.Replace(Resource.Id.HomeFrameLayout, new ApplicationStatusFragment());
                            ft.Commit();
                            navigationView.Menu.GetItem(4).SetChecked(true);
                        }
                    }
                }
            }
            catch { }

            if (CacheManager.FromNotification)
                CacheManager.FromNotification = false;

            try { _processProgress.Dismiss(); }
            catch { }
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetLatestJobApplication", headers);
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        if (CacheManager.JobInfo == null)
                        {
                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                            alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                            alert.SetMessage(this.Resources.GetString(Resource.String.EnableInternet));
                            alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                            {
                                var intent = new Intent(this, typeof(MainActivity));
                                StartActivity(intent);
                                FinishAffinity();
                            });

                            RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                        }
                    }
                    else
                    {
                        JobApplicationInfo info = null;
                        try
                        {
                            info = JsonConvert.DeserializeObject<JobApplicationInfo>(strResult);
                        }
                        catch { }

                        if (CacheManager.JobInfo == null)
                        {
                            if (info == null)
                            {
                                JobApplication model = new JobApplication()
                                {
                                    ApplicationStatus = InitialData.NewApplicationStatus.New,
                                    IsLocked = false
                                };

                                JobApplication final = Database.InsertJobApplication(model);

                                CacheManager.JobApplicationID = final.ID;

                                CacheManager.JobInfo = new JobApplicationInfo()
                                {
                                    ApplicationStatus = InitialData.NewApplicationStatus.New,
                                    IsLocked = false
                                };
                            }
                            else
                            {
                                CacheManager.JobInfo = info;
                                JobApplication model = new JobApplication()
                                {
                                    Title = info.Title,
                                    FirstName = info.FirstName,
                                    LastName = info.LastName,
                                    KnownAs = info.KnownAs,
                                    ChineseCharacter = info.ChineseCharacter,
                                    Gender = info.Gender,
                                    DateOfBirth = info.DateOfBirth,
                                    PlaceOfBirth = info.PlaceOfBirth,
                                    CountryOfBirth = info.CountryOfBirth,
                                    Nationality = info.Nationality,
                                    Race = info.Race,
                                    MaritalStatus = info.MaritalStatus,
                                    Religion = info.Religion,
                                    IdentityNo = info.IdentityNo,
                                    IsPassport = info.IsPassport,
                                    DateOfIssue = info.DateOfIssue,
                                    DateOfExpiry = info.DateOfExpiry,
                                    PlaceOfIssue = info.PlaceOfIssue,
                                    CountryOfIssue = info.CountryOfIssue,
                                    EmailAddress = info.EmailAddress,
                                    EmergencyContact = info.EmergencyContact,
                                    ServiceCompleted = info.ServiceCompleted,
                                    HighestRankAttained = info.HighestRankAttained,
                                    ExemptionReason = info.ExemptionReason,
                                    LiabilityForDuties = info.LiabilityForDuties,
                                    Photo = info.Photo,
                                    ApplicationStatus = info.ApplicationStatus,
                                    IsLocked = info.IsLocked.GetValueOrDefault()
                                };

                                JobApplication final = Database.InsertJobApplication(model);

                                if (info.CurrentAddress != null)
                                {
                                    JobApplicationAddress address = new JobApplicationAddress()
                                    {
                                        AddressType = InitialData.AddressType.CurrentAddress,
                                        Address = info.CurrentAddress.Address,
                                        PostalCode = info.CurrentAddress.PostalCode,
                                        Country = info.CurrentAddress.Country,
                                        HomeNumber = info.CurrentAddress.HomeNumber,
                                        MobileNumber = info.CurrentAddress.MobileNumber
                                    };

                                    Database.UpdateAddress(address);
                                }

                                if (info.HomeAddress != null)
                                {
                                    JobApplicationAddress address = new JobApplicationAddress()
                                    {
                                        AddressType = InitialData.AddressType.HomeAddress,
                                        Address = info.HomeAddress.Address,
                                        PostalCode = info.HomeAddress.PostalCode,
                                        Country = info.HomeAddress.Country,
                                        HomeNumber = info.HomeAddress.HomeNumber,
                                        MobileNumber = info.HomeAddress.MobileNumber
                                    };

                                    Database.UpdateAddress(address);
                                }

                                if (info.EmergencyAddress != null)
                                {
                                    JobApplicationAddress address = new JobApplicationAddress()
                                    {
                                        AddressType = InitialData.AddressType.EmergencyAddress,
                                        Address = info.EmergencyAddress.Address,
                                        PostalCode = info.EmergencyAddress.PostalCode,
                                        Country = info.EmergencyAddress.Country,
                                        HomeNumber = info.EmergencyAddress.HomeNumber,
                                        MobileNumber = info.EmergencyAddress.MobileNumber
                                    };

                                    Database.UpdateAddress(address);
                                }

                                if (info.PackageDetail != null)
                                {
                                    JobApplicationPackageDetail detail = new JobApplicationPackageDetail()
                                    {
                                        BaseSalary = info.PackageDetail.BaseSalary,
                                        ExpectedSalary = info.PackageDetail.ExpectedSalary,
                                        ContractualBonus = info.PackageDetail.ContractualBonus,
                                        PerformanceBonus = info.PackageDetail.PerformanceBonus,
                                        HousingAllowance = info.PackageDetail.HousingAllowance,
                                        TransportAllowance = info.PackageDetail.TransportAllowance,
                                        ConnectivityAllowance = info.PackageDetail.ConnectivityAllowance,
                                        ProjectAlowance = info.PackageDetail.ProjectAlowance,
                                        SpecialSkillsAllowance = info.PackageDetail.SpecialSkillsAllowance,
                                        CarParkAllowance = info.PackageDetail.CarParkAllowance,
                                        CarParkClaim = info.PackageDetail.CarParkClaim,
                                        PhoneClaim = info.PackageDetail.PhoneClaim,
                                        MileageClaim = info.PackageDetail.MileageClaim,
                                        MealClaim = info.PackageDetail.MealClaim,
                                        OvertimeClaim = info.PackageDetail.OvertimeClaim,
                                        StandbyClaim = info.PackageDetail.StandbyClaim,
                                        SelfMedicalBenefit = info.PackageDetail.SelfMedicalBenefit,
                                        FamilyMedicalBenefit = info.PackageDetail.FamilyMedicalBenefit,
                                        SelfInsuranceBenefit = info.PackageDetail.SelfInsuranceBenefit,
                                        FamilyInsuranceBenefit = info.PackageDetail.FamilyInsuranceBenefit,
                                        OpticalBenefit = info.PackageDetail.OpticalBenefit,
                                        DentalBenefit = info.PackageDetail.DentalBenefit,
                                        AnnualLeave = info.PackageDetail.AnnualLeave,
                                        MedicalLeave = info.PackageDetail.MedicalLeave,
                                        RetirementBenefit = info.PackageDetail.RetirementBenefit,
                                        EPFNumber = info.PackageDetail.EPFNumber,
                                        SOCSONumber = info.PackageDetail.SOCSONumber,
                                        IncomeTaxNumber = info.PackageDetail.IncomeTaxNumber,
                                        BankAccountNumber = info.PackageDetail.BankAccountNumber
                                    };

                                    Database.UpdatePackageDetail(detail);
                                }

                                if (info.Additional != null)
                                {
                                    JobApplicationAdditional additional = new JobApplicationAdditional()
                                    {
                                        ReferenceCheck = info.Additional.ReferenceCheck,
                                        ReferenceRemarks = info.Additional.ReferenceRemarks,
                                        DateAvailable = info.Additional.DateAvailable,
                                        CanTravel = info.Additional.CanTravel,
                                        CanRelocate = info.Additional.CanRelocate,
                                        ReasonForJoining = info.Additional.ReasonForJoining,
                                        CareerObjective = info.Additional.CareerObjective,
                                        Recommendation = info.Additional.Recommendation,
                                        KnowingCompany = info.Additional.KnowingCompany
                                    };

                                    Database.UpdateAdditional(additional);
                                }

                                foreach (JobApplicationFamilyInfo item in info.Families)
                                {
                                    item.UID = Guid.NewGuid();
                                    JobApplicationFamily family = new JobApplicationFamily()
                                    {
                                        ID = item.UID,
                                        FirstName = item.FirstName,
                                        LastName = item.LastName,
                                        Relationship = item.Relationship,
                                        IdentityNo = item.IdentityNo,
                                        JobTitle = item.JobTitle,
                                        Employer = item.Employer,
                                        Gender = item.Gender,
                                        DateOfBirth = item.DateOfBirth,
                                        Nationality = item.Nationality,
                                        CountryOfBirth = item.CountryOfBirth,
                                        IsSameCountry = item.IsSameCountry
                                    };

                                    Database.UpdateFamily(family);
                                }

                                foreach (JobApplicationEducationInfo item in info.Educations)
                                {
                                    item.UID = Guid.NewGuid();
                                    JobApplicationEducation education = new JobApplicationEducation()
                                    {
                                        ID = item.UID,
                                        Institution = item.Institution,
                                        Qualification = item.Qualification,
                                        CourseOfStudy = item.CourseOfStudy,
                                        Country = item.Country,
                                        StartDate = item.StartDate,
                                        EndDate = item.EndDate
                                    };

                                    Database.UpdateEducation(education);
                                }

                                foreach (JobApplicationLanguageInfo item in info.Languages)
                                {
                                    item.UID = Guid.NewGuid();
                                    JobApplicationLanguage language = new JobApplicationLanguage()
                                    {
                                        ID = item.UID,
                                        Language = item.Language,
                                        ReadAbility = item.ReadAbility,
                                        WriteAbility = item.WriteAbility,
                                        SpeakAbility = item.SpeakAbility
                                    };

                                    Database.UpdateLanguage(language);
                                }

                                foreach (JobApplicationWorkingHistoryInfo item in info.WorkingHistories)
                                {
                                    item.UID = Guid.NewGuid();
                                    JobApplicationWorkingHistory working = new JobApplicationWorkingHistory()
                                    {
                                        ID = item.UID,
                                        Company = item.Company,
                                        LastPositionHeld = item.LastPositionHeld,
                                        Country = item.Country,
                                        StartDate = item.StartDate,
                                        EndDate = item.EndDate,
                                        NameOfSuperior = item.NameOfSuperior,
                                        DesignationOfSuperior = item.DesignationOfSuperior,
                                        LastDrawnSalary = item.LastDrawnSalary,
                                        ReasonForLeaving = item.ReasonForLeaving,
                                    };

                                    Database.UpdateWorkingHistory(working);
                                }

                                foreach (JobApplicationActivityInfo item in info.Activities)
                                {
                                    item.UID = Guid.NewGuid();
                                    JobApplicationActivity activity = new JobApplicationActivity()
                                    {
                                        ID = item.UID,
                                        Organisation = item.Organisation,
                                        NatureOfActivities = item.NatureOfActivities,
                                        Country = item.Country,
                                        FromDate = item.FromDate,
                                        ToDate = item.ToDate
                                    };

                                    Database.UpdateActivity(activity);
                                }

                                foreach (JobApplicationReferenceInfo item in info.References)
                                {
                                    JobApplicationReference reference = new JobApplicationReference()
                                    {
                                        Name = item.Name,
                                        Occupation = item.Occupation,
                                        YearsKnown = item.YearsKnown,
                                        Address = item.Address,
                                        Employer = item.Employer,
                                        MobileNumber = item.MobileNumber,
                                        HomeNumber = item.HomeNumber,
                                        OfficeNumber = item.OfficeNumber
                                    };
                                    Database.UpdateReference(reference);
                                }

                                foreach (JobApplicationDeclarationInfo item in info.Declarations)
                                {
                                    JobApplicationDeclaration declaration = new JobApplicationDeclaration()
                                    {
                                        DeclarationID = item.DeclarationID,
                                        Answer = item.Answer,
                                        Remarks = item.Remarks
                                    };
                                    Database.UpdateDeclaration(declaration);
                                }

                                CacheManager.JobApplicationID = final.ID;
                            }

                            CacheManager.IsLocked = CacheManager.JobInfo.IsLocked.GetValueOrDefault();

                            if (CacheManager.JobInfo != null && CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Accepted && CacheManager.FromNotification)
                            {
                                var ft = FragmentManager.BeginTransaction();
                                CacheManager.FromNotification = false;
                                SupportActionBar.SetTitle(Resource.String.AaInfo);
                                ft.Replace(Resource.Id.HomeFrameLayout, new PreBoardingFragment());
                                ft.Commit();
                                navigationView.Menu.GetItem(4).SetChecked(true);
                            }
                        }
                    }
                }
            }
            catch { }

            if (CacheManager.FromNotification)
                CacheManager.FromNotification = false;

            try { _processProgress.Dismiss(); }
            catch { }
        }

        private void MessageBox(string title, string message)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle(title);
            alert.SetMessage(message);
            alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
            {

            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        private bool ValidateData()
        {
            #region Personal Info
            if (string.IsNullOrEmpty(CacheManager.JobInfo.FirstName))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your first name in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.Gender))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your gender in Personal Information section.");
                return false;
            }
            if (!CacheManager.JobInfo.DateOfBirth.HasValue)
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your date of birth in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.Nationality))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your nationality in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.Race))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your race in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.MaritalStatus))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your marital status in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.Religion))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your religion in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.IdentityNo))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your identity number in Personal Information section.");
                return false;
            }
            if (CacheManager.JobInfo.IsPassport.GetValueOrDefault())
            {
                if (!CacheManager.JobInfo.DateOfIssue.HasValue)
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your date of issue in Personal Information section.");
                    return false;
                }
                if (!CacheManager.JobInfo.DateOfExpiry.HasValue)
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your date of expiry in Personal Information section.");
                    return false;
                }
                if (string.IsNullOrEmpty(CacheManager.JobInfo.CountryOfIssue))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your country of issue in Personal Information section.");
                    return false;
                }
            }
            #endregion

            #region Contact Details
            if (string.IsNullOrEmpty(CacheManager.JobInfo.EmailAddress))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your email address in Contact Details section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.EmergencyContact))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your emergency contact name in Contact Details section.");
                return false;
            }
            if (CacheManager.JobInfo.CurrentAddress == null)
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your current address in Contact Details section.");
                return false;
            }
            if (CacheManager.JobInfo.CurrentAddress != null)
            {
                if (string.IsNullOrEmpty(CacheManager.JobInfo.CurrentAddress.Address))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your current address in Contact Details section.");
                    return false;
                }
                if (string.IsNullOrEmpty(CacheManager.JobInfo.CurrentAddress.PostalCode))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your current postal code in Contact Details section.");
                    return false;
                }
                if (string.IsNullOrEmpty(CacheManager.JobInfo.CurrentAddress.Country))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your current country in Contact Details section.");
                    return false;
                }
                if (string.IsNullOrEmpty(CacheManager.JobInfo.CurrentAddress.MobileNumber))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your current mobile number in Contact Details section.");
                    return false;
                }
            }
            if (CacheManager.JobInfo.EmergencyAddress == null)
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your emergency details in Contact Details section.");
                return false;
            }
            if (CacheManager.JobInfo.EmergencyAddress != null)
            {
                if (string.IsNullOrEmpty(CacheManager.JobInfo.EmergencyAddress.MobileNumber))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your emergency contact's mobile number in Contact Details section.");
                    return false;
                }
                else if (CacheManager.JobInfo.EmergencyAddress.MobileNumber == CacheManager.JobInfo.CurrentAddress.MobileNumber)
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Emergency contact's mobile number cannot be the same as current mobile number.");
                    return false;
                }
                else if (CacheManager.JobInfo.HomeAddress != null && CacheManager.JobInfo.EmergencyAddress.MobileNumber == CacheManager.JobInfo.HomeAddress.MobileNumber)
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Emergency contact's mobile number cannot be the same as home mobile number.");
                    return false;
                }
            }
            #endregion

            #region Family Details
            if (CacheManager.JobInfo.Families != null)
            {
                string name = string.Empty;
                foreach (JobApplicationFamilyInfo info in CacheManager.JobInfo.Families)
                {
                    if (string.IsNullOrEmpty(info.FirstName) ||
                        string.IsNullOrEmpty(info.Relationship))
                    {
                        name = info.FirstName + " " + info.LastName;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please complete your family information (" + name + ") in Family Details section.");
                    return false;
                }
            }
            #endregion

            #region Education
            if (CacheManager.JobInfo.Educations == null)
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your education history in Education section.");
                return false;
            }
            if (CacheManager.JobInfo.Educations != null)
            {
                if (CacheManager.JobInfo.Educations.Count == 0)
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your family member in Education section.");
                    return false;
                }
                string name = string.Empty;
                foreach (JobApplicationEducationInfo info in CacheManager.JobInfo.Educations)
                {
                    if (string.IsNullOrEmpty(info.Institution) || string.IsNullOrEmpty(info.Country) ||
                        !info.StartDate.HasValue)
                    {
                        name = info.Institution;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please complete your education history (" + name + ") in Education section.");
                    return false;
                }
            }
            #endregion

            #region Language
            if (CacheManager.JobInfo.Languages == null)
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your language skills in Language Skills section.");
                return false;
            }
            if (CacheManager.JobInfo.Languages != null)
            {
                if (CacheManager.JobInfo.Languages.Count == 0)
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input your language skills in Language Skills section.");
                    return false;
                }
                string name = string.Empty;
                foreach (JobApplicationLanguageInfo info in CacheManager.JobInfo.Languages)
                {
                    if (string.IsNullOrEmpty(info.Language))
                    {
                        name = info.Language;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please complete your language skills (" + name + ") in Language Skills section.");
                    return false;
                }
            }
            #endregion

            #region Working History
            if (CacheManager.JobInfo.WorkingHistories != null)
            {
                string name = string.Empty;
                foreach (JobApplicationWorkingHistoryInfo info in CacheManager.JobInfo.WorkingHistories)
                {
                    if (string.IsNullOrEmpty(info.Company) || string.IsNullOrEmpty(info.Country) ||
                        !info.StartDate.HasValue || string.IsNullOrEmpty(info.LastPositionHeld))
                    {
                        name = info.Company;
                    }
                    if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Accepted)
                    {
                        if (string.IsNullOrEmpty(info.Company) || string.IsNullOrEmpty(info.Country) ||
                        !info.StartDate.HasValue || string.IsNullOrEmpty(info.LastDrawnSalary) ||
                        string.IsNullOrEmpty(info.LastPositionHeld) || string.IsNullOrEmpty(info.ReasonForLeaving))
                        {
                            name = info.Company;
                        }
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please complete your working history (" + name + ") in Working History section.");
                    return false;
                }
            }
            #endregion

            #region Activity
            if (CacheManager.JobInfo.Activities != null)
            {
                string name = string.Empty;
                foreach (JobApplicationActivityInfo info in CacheManager.JobInfo.Activities)
                {
                    if (string.IsNullOrEmpty(info.Organisation) || string.IsNullOrEmpty(info.Country) ||
                        !info.FromDate.HasValue ||
                        string.IsNullOrEmpty(info.NatureOfActivities))
                    {
                        name = info.Organisation;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please complete your activity information (" + name + ") in Social/Political Activities section.");
                    return false;
                }
            }
            #endregion

            #region Reference
            if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Accepted)
            {
                if (CacheManager.JobInfo.References == null || (CacheManager.JobInfo.References != null && CacheManager.JobInfo.References.Count == 0))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input reference detail in References section.");
                    return false;
                }
            }
            if (CacheManager.JobInfo.References != null)
            {
                string name = string.Empty;
                foreach (JobApplicationReferenceInfo info in CacheManager.JobInfo.References)
                {
                    if (string.IsNullOrEmpty(info.Name) || !info.YearsKnown.HasValue ||
                        string.IsNullOrEmpty(info.Occupation) || string.IsNullOrEmpty(info.MobileNumber))
                    {
                        name = info.Name;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please complete your reference details (" + name + ") in References section.");
                    return false;
                }
            }
            #endregion

            #region Additional
            if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Accepted)
            {
                if (CacheManager.JobInfo.Additional == null)
                {
                    MessageBox(this.Resources.GetString(Resource.String.Error), "Please input additional detail in Additional section.");
                    return false;
                }
                else
                {
                    if (!CacheManager.JobInfo.Additional.CanRelocate.HasValue || !CacheManager.JobInfo.Additional.CanTravel.HasValue ||
                        string.IsNullOrEmpty(CacheManager.JobInfo.Additional.CareerObjective) || string.IsNullOrEmpty(CacheManager.JobInfo.Additional.KnowingCompany) ||
                        string.IsNullOrEmpty(CacheManager.JobInfo.Additional.ReasonForJoining) || string.IsNullOrEmpty(CacheManager.JobInfo.Additional.Recommendation) ||
                        !CacheManager.JobInfo.Additional.DateAvailable.HasValue || !CacheManager.JobInfo.Additional.ReferenceCheck.HasValue)
                    {
                        MessageBox(this.Resources.GetString(Resource.String.Error), "Please input all details in Additional section.");
                        return false;
                    }
                    if(CacheManager.JobInfo.Additional.ReferenceCheck.GetValueOrDefault() == false && string.IsNullOrEmpty(CacheManager.JobInfo.Additional.ReferenceRemarks))
                    {
                        MessageBox(this.Resources.GetString(Resource.String.Error), "Please input remarks for reference check in Additional section.");
                        return false;
                    }
                }
            }
            #endregion

            return true;
        }
    }
}