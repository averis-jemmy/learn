using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using MyAverisEntity;
using MyAverisCommon;

namespace MyAa.Droid
{
    [Activity(Label = "WorkingHistoriesActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class WorkingHistoriesActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.WorkingHistories);
            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.WorkingHistories);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            if (CacheManager.WorkingHistoryInfo != null && !CacheManager.IsLocked)
            {
                FindViewById<Button>(Resource.Id.btnDelete).Visibility = ViewStates.Visible;
                FindViewById<Button>(Resource.Id.btnDelete).Click += Delete_OnClick;
            }
            else
                FindViewById<Button>(Resource.Id.btnDelete).Visibility = ViewStates.Gone;

            FindViewById<Spinner>(Resource.Id.spinCountry).Adapter = new SpinnerData(this, CommonData.GetCountries());

            FindViewById<CheckBox>(Resource.Id.chkPresent).CheckedChange += Present_CheckedChange;

            if(CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Accepted)
            {
                FindViewById<TextView>(Resource.Id.tvLastDrawnSalary).Text = this.Resources.GetString(Resource.String.LastDrawnTitle);
                FindViewById<TextView>(Resource.Id.tvReason).Text = this.Resources.GetString(Resource.String.ReasonTitle);
            }

            if (!CacheManager.IsLocked)
            {
                FindViewById<TextView>(Resource.Id.etStartDate).Click += StartDate_OnClick;
                FindViewById<TextView>(Resource.Id.etEndDate).Click += EndDate_OnClick;
            }

            if (CacheManager.WorkingHistoryInfo != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        void Present_CheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            if (FindViewById<CheckBox>(Resource.Id.chkPresent).Checked)
                FindViewById<TextView>(Resource.Id.etEndDate).Text = string.Empty;
        }

        private void StartDate_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DateTime? endDate = null;
            try
            {
                endDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etStartDate).Text = time.ToString("dd - MMM - yyyy");
            }, selected, DateTime.Now.AddYears(-50), endDate.HasValue ? endDate : DateTime.Now);
            frag.Show(FragmentManager, DatePickerFragment.TAG);
        }

        private void EndDate_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DateTime? startDate = null;
            try
            {
                startDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etEndDate).Text = time.ToString("dd - MMM - yyyy");
            }, selected, startDate.HasValue ? startDate : DateTime.Now.AddYears(-50), DateTime.Now);
            frag.Show(FragmentManager, DatePickerFragment.TAG);

            FindViewById<CheckBox>(Resource.Id.chkPresent).Checked = false;
        }

        void Delete_OnClick(object sender, EventArgs e)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle(this.Resources.GetString(Resource.String.Info));
            alert.SetMessage(this.Resources.GetString(Resource.String.DeleteConfirmation));
            alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
            {
                JobApplicationWorkingHistory model = new JobApplicationWorkingHistory()
                {
                    ID = CacheManager.WorkingHistoryInfo.UID
                };

                Database.DeleteWorkingHistory(model);

                if (CacheManager.JobInfo.WorkingHistories.Count >= CacheManager.WorkingHistoryPosition + 1 &&
                            CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition] != null)
                {
                    CacheManager.JobInfo.WorkingHistories.RemoveAt(CacheManager.WorkingHistoryPosition);
                }

                Finish();
            });
            alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
            {
            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            FindViewById<EditText>(Resource.Id.etCompanyName).Text = CacheManager.WorkingHistoryInfo.Company;
            FindViewById<EditText>(Resource.Id.etLastPositionHeld).Text = CacheManager.WorkingHistoryInfo.LastPositionHeld;
            FindViewById<EditText>(Resource.Id.etNameOfSuperior).Text = CacheManager.WorkingHistoryInfo.NameOfSuperior;
            FindViewById<EditText>(Resource.Id.etDesignationOfSuperior).Text = CacheManager.WorkingHistoryInfo.DesignationOfSuperior;
            
            try
            {
                if (!string.IsNullOrEmpty(CacheManager.WorkingHistoryInfo.LastDrawnSalary))
                    FindViewById<EditText>(Resource.Id.etLastDrawnSalary).Text = Cryptography.Decryption(CacheManager.WorkingHistoryInfo.LastDrawnSalary);
            }
            catch { }

            FindViewById<EditText>(Resource.Id.etReason).Text = CacheManager.WorkingHistoryInfo.ReasonForLeaving;

            if (CacheManager.WorkingHistoryInfo.StartDate.HasValue)
                FindViewById<TextView>(Resource.Id.etStartDate).Text = CacheManager.WorkingHistoryInfo.StartDate.Value.ToString("dd - MMM - yyyy");

            if (CacheManager.WorkingHistoryInfo.EndDate.HasValue)
            {
                FindViewById<CheckBox>(Resource.Id.chkPresent).Checked = false;
                FindViewById<TextView>(Resource.Id.etEndDate).Text = CacheManager.WorkingHistoryInfo.EndDate.Value.ToString("dd - MMM - yyyy");
            }

            FindViewById<Spinner>(Resource.Id.spinCountry).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.WorkingHistoryInfo.Country));
        }

        private void LockData()
        {
            FindViewById<CheckBox>(Resource.Id.chkPresent).Enabled = false;
            FindViewById<EditText>(Resource.Id.etCompanyName).Enabled = false;
            FindViewById<EditText>(Resource.Id.etLastPositionHeld).Enabled = false;
            FindViewById<EditText>(Resource.Id.etNameOfSuperior).Enabled = false;
            FindViewById<EditText>(Resource.Id.etDesignationOfSuperior).Enabled = false;
            FindViewById<EditText>(Resource.Id.etLastDrawnSalary).Enabled = false;
            FindViewById<EditText>(Resource.Id.etReason).Enabled = false;

            FindViewById<Spinner>(Resource.Id.spinCountry).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                if (CacheManager.JobInfo.WorkingHistories == null)
                    CacheManager.JobInfo.WorkingHistories = new List<JobApplicationWorkingHistoryInfo>();

                if (CacheManager.WorkingHistoryInfo == null)
                {
                    JobApplicationWorkingHistoryInfo info = new JobApplicationWorkingHistoryInfo();
                    info.UID = Guid.NewGuid();
                    info.Company = FindViewById<EditText>(Resource.Id.etCompanyName).Text;
                    info.LastPositionHeld = FindViewById<EditText>(Resource.Id.etLastPositionHeld).Text;
                    info.NameOfSuperior = FindViewById<EditText>(Resource.Id.etNameOfSuperior).Text;
                    info.DesignationOfSuperior = FindViewById<EditText>(Resource.Id.etDesignationOfSuperior).Text;

                    try
                    {
                        decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etLastDrawnSalary).Text);
                        info.LastDrawnSalary = Cryptography.Encryption(number.ToString());
                    }
                    catch
                    {
                        info.LastDrawnSalary = string.Empty;
                    }

                    info.ReasonForLeaving = FindViewById<EditText>(Resource.Id.etReason).Text;

                    try
                    {
                        info.StartDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                        "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        info.StartDate = null;
                    }

                    try
                    {
                        info.EndDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                        "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        info.EndDate = null;
                    }

                    info.Country = FindViewById<Spinner>(Resource.Id.spinCountry).SelectedItem.ToString();

                    CacheManager.JobInfo.WorkingHistories.Add(info);

                    JobApplicationWorkingHistory model = new JobApplicationWorkingHistory()
                    {
                        ID = info.UID,
                        Company = info.Company,
                        LastPositionHeld = info.LastPositionHeld,
                        Country = info.Country,
                        StartDate = info.StartDate,
                        EndDate = info.EndDate,
                        NameOfSuperior = info.NameOfSuperior,
                        DesignationOfSuperior = info.DesignationOfSuperior,
                        LastDrawnSalary = info.LastDrawnSalary,
                        ReasonForLeaving = info.ReasonForLeaving
                    };

                    Database.UpdateWorkingHistory(model);
                }
                else
                {
                    if (CacheManager.JobInfo.WorkingHistories.Count >= CacheManager.WorkingHistoryPosition + 1 &&
                        CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition] != null)
                    {
                        Guid UID = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].UID;
                        CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition] = new JobApplicationWorkingHistoryInfo();
                        CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].UID = UID;

                        CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].Company = FindViewById<EditText>(Resource.Id.etCompanyName).Text;
                        CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].LastPositionHeld = FindViewById<EditText>(Resource.Id.etLastPositionHeld).Text;
                        CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].NameOfSuperior = FindViewById<EditText>(Resource.Id.etNameOfSuperior).Text;
                        CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].DesignationOfSuperior = FindViewById<EditText>(Resource.Id.etDesignationOfSuperior).Text;
                        
                        try
                        {
                            decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etLastDrawnSalary).Text);
                            CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].LastDrawnSalary = Cryptography.Encryption(number.ToString());
                        }
                        catch
                        {
                            CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].LastDrawnSalary = string.Empty;
                        }

                        CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].ReasonForLeaving = FindViewById<EditText>(Resource.Id.etReason).Text;

                        try
                        {
                            CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].StartDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                            "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        }
                        catch
                        {
                            CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].StartDate = null;
                        }

                        try
                        {
                            CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].EndDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                            "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        }
                        catch
                        {
                            CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].EndDate = null;
                        }

                        CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].Country = FindViewById<Spinner>(Resource.Id.spinCountry).SelectedItem.ToString();

                        JobApplicationWorkingHistory model = new JobApplicationWorkingHistory()
                        {
                            ID = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].UID,
                            Company = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].Company,
                            LastPositionHeld = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].LastPositionHeld,
                            Country = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].Country,
                            StartDate = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].StartDate,
                            EndDate = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].EndDate,
                            NameOfSuperior = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].NameOfSuperior,
                            DesignationOfSuperior = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].DesignationOfSuperior,
                            LastDrawnSalary = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].LastDrawnSalary,
                            ReasonForLeaving = CacheManager.JobInfo.WorkingHistories[CacheManager.WorkingHistoryPosition].ReasonForLeaving,
                        };

                        Database.UpdateWorkingHistory(model);
                    }
                }
            }

            Finish();
        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etCompanyName).Text))
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.CompanyConfirmation));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
                {
                    Finish();
                });
                alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return false;
            }
            return true;
        }
    }
}