using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MyAverisClient;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.ComponentModel;
using MyAverisEntity;
using MyAverisCommon;
using Newtonsoft.Json;
using Android.Views.InputMethods;
using Android.Support.V7.App;
using Android.Support.V4.Content;
using Android.Gms.Common;
using Android.Util;
using Android.Preferences;
using Android.Gms.Gcm;
using Android.Gms.Gcm.Iid;
using Android.Provider;
using Android.Telephony;

namespace MyAa.Droid
{
    [Activity(Label = "MYAA", Theme = "@style/MyTheme.Base", WindowSoftInputMode = SoftInput.StateHidden, Icon = "@drawable/icon", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class LoginActivity : AppCompatActivity
    {
        ProgressDialog _processProgress;
        string strResult;

        static EditText etVerify;
        private SmsReceiver mSmsReceiver;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            ServicePointManager.ServerCertificateValidationCallback =
                delegate(Object obj, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
                {
                    return (true);
                };
            System.Security.Cryptography.AesCryptoServiceProvider b = new System.Security.Cryptography.AesCryptoServiceProvider();
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            //Window.RequestFeature(WindowFeatures.NoTitle);
            Window.SetFlags(WindowManagerFlags.Fullscreen, WindowManagerFlags.Fullscreen);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Login);

            FindViewById<TextView>(Resource.Id.lblClose).Click += Close_OnClick;

            FindViewById<Spinner>(Resource.Id.spinCountry).Adapter = new SpinnerData(this, CommonData.GetCountries());
            FindViewById<Spinner>(Resource.Id.spinCountry).ItemSelected += Country_ItemSelected;

            mSmsReceiver = new SmsReceiver();

            Button btnSubmit = (Button)FindViewById(Resource.Id.btnSubmit);
            btnSubmit.Click += SubmitButton_OnClick;

            TextView tvResend = (TextView)FindViewById(Resource.Id.tvResend);
            Button btnVerify = (Button)FindViewById(Resource.Id.btnVerify);
            etVerify = (EditText)FindViewById(Resource.Id.etVerificationCode);
            btnVerify.Click += VerifyButton_OnClick;
            tvResend.Click += ResendText_OnClick;

            _processProgress = new ProgressDialog(this);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);
            //_processProgress.SetButton("Cancel", (senderAlert, args) =>
            //{
            //CancelEvent();
            //});

            try
            {
                RegisterReceiver(mSmsReceiver, new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));
            }
            catch { }
        }

        void Country_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            if (!string.IsNullOrEmpty(FindViewById<Spinner>(Resource.Id.spinCountry).SelectedItem.ToString()))
            {
                FindViewById<EditText>(Resource.Id.etCountryCode).Text = "+" + CommonData.GetCountryCode(FindViewById<Spinner>(Resource.Id.spinCountry).SelectedItem.ToString());
            }
            else
            {
                FindViewById<EditText>(Resource.Id.etCountryCode).Text = string.Empty;
                FindViewById<EditText>(Resource.Id.etPhoneNumber).Text = string.Empty;
            }
        }

        [BroadcastReceiver]
        [IntentFilter(new[] { "android.provider.Telephony.SMS_RECEIVED" })]
        public class SmsReceiver : BroadcastReceiver
        {
            public static readonly string IntentAction = "android.provider.Telephony.SMS_RECEIVED";

            public override void OnReceive(Context context, Intent intent)
            {
                try
                {
                    if (intent.Action != IntentAction) return;

                    SmsMessage[] messages = Telephony.Sms.Intents.GetMessagesFromIntent(intent);

                    string activationCode = string.Empty;

                    for (var i = 0; i < messages.Length; i++)
                    {
                        if (messages[i].MessageBody.Contains("activation code"))
                            activationCode = messages[i].MessageBody.Substring(messages[i].MessageBody.Length - 6);
                    }

                    if (!string.IsNullOrEmpty(activationCode))
                        etVerify.Text = activationCode;
                }
                catch { }
            }
        }

        protected override void OnResume()
        {
            base.OnResume();
        }

        protected override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            try
            {
                UnregisterReceiver(mSmsReceiver);
                GC.Collect();
            }
            catch { }
        }

        void Close_OnClick(object sender, EventArgs e)
        {
            Finish();
        }

        void SubmitButton_OnClick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(FindViewById<Spinner>(Resource.Id.spinCountry).SelectedItem.ToString()))
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.CountrySelect));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return;
            }
            if (string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etPhoneNumber).Text))
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.InputMobile));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return;
            }

            _processProgress.Show();

            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += worker_DoWork;
            worker.RunWorkerCompleted += worker_RunWorkerCompleted;
            worker.RunWorkerAsync();
        }

        void ResendText_OnClick(object sender, EventArgs e)
        {
            _processProgress.Show();

            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += worker_DoWork;
            worker.RunWorkerCompleted += worker_RunWorkerCompleted;
            worker.RunWorkerAsync();
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            CacheManager.PhoneNumber = FindViewById<EditText>(Resource.Id.etCountryCode).Text.Replace("+", "");

            string number = FindViewById<EditText>(Resource.Id.etPhoneNumber).Text;
            number = number.Substring(0, FindViewById<EditText>(Resource.Id.etCountryCode).Text.Replace("+", "").Length);
            if (number == CacheManager.PhoneNumber)
            {
                CacheManager.PhoneNumber = string.Empty;
            }

            if (FindViewById<EditText>(Resource.Id.etPhoneNumber).Text[0] == '0')
                CacheManager.PhoneNumber += FindViewById<EditText>(Resource.Id.etPhoneNumber).Text.Substring(1);
            else
                CacheManager.PhoneNumber += FindViewById<EditText>(Resource.Id.etPhoneNumber).Text;

            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("ApplicationType", CacheManager.ApplicationType));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.PhoneNumber + "\"");
            strResult = client.ProcessRequest("SignIn", headers);
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!string.IsNullOrEmpty(strResult))
            {
                try { _processProgress.Dismiss(); }
                catch { }

                if (strResult.ToUpper().Contains("UNKNOWN NUMBER"))
                {
                    Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                    alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                    alert.SetMessage(this.Resources.GetString(Resource.String.NotRegistered));
                    alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                    {
                        CacheManager.PhoneNumber = string.Empty;
                    });

                    RunOnUiThread(() =>
                    {
                        alert.Show();
                    });
                    return;
                }
                else if (strResult.ToUpper().Contains("REQUESTED"))
                {
                    Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                    alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                    alert.SetMessage(this.Resources.GetString(Resource.String.HasRequested));
                    alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                    {
                        CacheManager.PhoneNumber = string.Empty;
                    });

                    RunOnUiThread(() =>
                    {
                        alert.Show();
                    });
                    return;
                }
                else
                {
                    Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                    alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                    alert.SetMessage(this.Resources.GetString(Resource.String.FailLogin));
                    alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                    {
                        CacheManager.PhoneNumber = string.Empty;
                    });

                    RunOnUiThread(() =>
                    {
                        alert.Show();
                    });
                    return;
                }
            }

            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            FindViewById<LinearLayout>(Resource.Id.layoutPhone).Visibility = ViewStates.Gone;
            FindViewById<LinearLayout>(Resource.Id.layoutVerify).Visibility = ViewStates.Visible;

            try { _processProgress.Dismiss(); }
            catch { }
        }

        void VerifyButton_OnClick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etVerificationCode).Text)
                || FindViewById<EditText>(Resource.Id.etVerificationCode).Text.Length < 6)
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.InputVerifyCode));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return;
            }

            _processProgress.Show();

            BackgroundWorker verifyWorker = new BackgroundWorker();
            verifyWorker.DoWork += verifyWorker_DoWork;
            verifyWorker.RunWorkerCompleted += verifyWorker_RunWorkerCompleted;
            verifyWorker.RunWorkerAsync();
        }

        void verifyWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            Verification model = new Verification();
            model.VerificationCode = FindViewById<EditText>(Resource.Id.etVerificationCode).Text;
            model.PhoneNumber = CacheManager.PhoneNumber;
            model.DeviceType = InitialData.DeviceType.Android;

            string requestData = JsonConvert.SerializeObject(model);

            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("ApplicationType", CacheManager.ApplicationType));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, requestData);
            strResult = client.ProcessRequest("Verify", headers);
        }

        void verifyWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                UserInfo info = JsonConvert.DeserializeObject<UserInfo>(strResult);
                if (info != null)
                {
                    string token = CacheManager.DeviceToken;

                    CacheManager.SaveIntoSharedPreferences(info, token);

                    User user = Database.UpdateUser(new User()
                    {
                        UserID = info.UserID,
                        Name = info.UserName,
                        EmailAddress = info.Email,
                        PhoneNumber = info.PhoneNumber,
                        TokenID = info.TokenID.GetValueOrDefault(),
                        IsRecruiter = info.IsRecruiter,
                        DeviceType = InitialData.DeviceType.Android,
                        HasProfilePicture = info.HasProfilePicture.GetValueOrDefault(),
                        PositionApplied = info.PositionApplied,
                        DeviceToken = token
                    });

                    //System.Threading.Thread.Sleep(1000);

                    if (info.IsRecruiter)
                    {
                        Database.UpdateSettings("English");
                    }
                    else
                    {
                        try
                        {
                            View customView = LayoutInflater.Inflate(Resource.Layout.Language, null);
                            Android.Support.V7.App.AlertDialog.Builder builder = new Android.Support.V7.App.AlertDialog.Builder(this);
                            builder.SetView(customView);
                            builder.SetPositiveButton(this.Resources.GetString(Resource.String.OK), OkClicked);
                            
                            RunOnUiThread(() =>
                            {
                                builder.Show();
                            });
                        }
                        catch {
                            var main = new Intent(this, typeof(MainActivity));
                            StartActivity(main);
                            FinishAffinity();
                        }
                    }
                }
                else
                {
                    Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                    alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                    alert.SetMessage(this.Resources.GetString(Resource.String.FailLogin));
                    alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                    {
                    });

                    RunOnUiThread(() =>
                    {
                        alert.Show();
                    });

                    FindViewById<EditText>(Resource.Id.etVerificationCode).Text = "";
                }
            }
            catch
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.FailLogin));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });

                FindViewById<EditText>(Resource.Id.etVerificationCode).Text = "";
            }
            try { _processProgress.Dismiss(); }
            catch { }
        }

        private void OkClicked(object sender, DialogClickEventArgs args)
        {
            try
            {
                var dialog = (Android.Support.V7.App.AlertDialog)sender;
                var rbEnglish = dialog.FindViewById<RadioButton>(Resource.Id.rbEnglish);
                var rbIndonesia = dialog.FindViewById<RadioButton>(Resource.Id.rbIndonesia);
                if (rbEnglish.Checked)
                    Database.UpdateSettings("English");
                else
                    Database.UpdateSettings("Bahasa Indonesia");
            }
            catch { }

            var main = new Intent(this, typeof(MainActivity));
            StartActivity(main);
            FinishAffinity();
        }
    }
}