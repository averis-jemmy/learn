using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using Android.Animation;
using Android.Graphics;
using System.ComponentModel;
using MyAverisClient;
using Newtonsoft.Json;
using MyAverisEntity;
using Android.Text.Method;
using Android.Text;

namespace MyAa.Droid
{
    [Activity(Label = "FoodBeverageActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class FoodBeverageActivity : AppCompatActivity
    {
        bool medanExpand = false, pekanbaruExpand = false, jakartaExpand = false, jambiExpand = false;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.FoodBeverage);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.FoodBeverageTitle);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            medanExpand = false;
            pekanbaruExpand = false;
            jakartaExpand = false;
            jambiExpand = false;
            FindViewById<RelativeLayout>(Resource.Id.layMedanOfficeFood).Click += MedanOffice_OnClick;
            FindViewById<RelativeLayout>(Resource.Id.layPekanbaruOfficeFood).Click += PekanbaruOffice_OnClick;
            FindViewById<RelativeLayout>(Resource.Id.layJakartaOfficeFood).Click += JakartaOffice_OnClick;
            FindViewById<RelativeLayout>(Resource.Id.layJambiOfficeFood).Click += JambiOffice_OnClick;

            CacheManager.ProcessProgress.Dismiss();
        }

        private void MedanOffice_OnClick(object sender, EventArgs e)
        {
            if (medanExpand)
            {
                medanExpand = false;
                FindViewById<ImageView>(Resource.Id.imgMedanOfficeFood).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layMedanOfficeFoodDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layMedanOfficeFoodDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layMedanOfficeFoodDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                medanExpand = true;
                FindViewById<ImageView>(Resource.Id.imgMedanOfficeFood).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layMedanOfficeFoodDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layMedanOfficeFoodDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layMedanOfficeFoodDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layMedanOfficeFoodDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layMedanOfficeFoodDes), 0, height);
                mAnimator.Start();
            }
        }

        private void PekanbaruOffice_OnClick(object sender, EventArgs e)
        {
            if (pekanbaruExpand)
            {
                pekanbaruExpand = false;
                FindViewById<ImageView>(Resource.Id.imgPekanbaruOfficeFood).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeFoodDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeFoodDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeFoodDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                pekanbaruExpand = true;
                FindViewById<ImageView>(Resource.Id.imgPekanbaruOfficeFood).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeFoodDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeFoodDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeFoodDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeFoodDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layPekanbaruOfficeFoodDes), 0, height);
                mAnimator.Start();
            }
        }

        private void JakartaOffice_OnClick(object sender, EventArgs e)
        {
            if (jakartaExpand)
            {
                jakartaExpand = false;
                FindViewById<ImageView>(Resource.Id.imgJakartaOfficeFood).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeFoodDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeFoodDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeFoodDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                jakartaExpand = true;
                FindViewById<ImageView>(Resource.Id.imgJakartaOfficeFood).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeFoodDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeFoodDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeFoodDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeFoodDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layJakartaOfficeFoodDes), 0, height);
                mAnimator.Start();
            }
        }

        private void JambiOffice_OnClick(object sender, EventArgs e)
        {
            if (jambiExpand)
            {
                jambiExpand = false;
                FindViewById<ImageView>(Resource.Id.imgJambiOfficeFood).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layJambiOfficeFoodDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layJambiOfficeFoodDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layJambiOfficeFoodDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                jambiExpand = true;
                FindViewById<ImageView>(Resource.Id.imgJambiOfficeFood).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layJambiOfficeFoodDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layJambiOfficeFoodDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layJambiOfficeFoodDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layJambiOfficeFoodDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layJambiOfficeFoodDes), 0, height);
                mAnimator.Start();
            }
        }

        private ValueAnimator SlideAnimator(LinearLayout mLinearLayout, int start, int end)
        {
            ValueAnimator animator = ValueAnimator.OfInt(start, end);
            animator.Update +=
                (object sender, ValueAnimator.AnimatorUpdateEventArgs e) =>
                {
                    var value = (int)animator.AnimatedValue;
                    ViewGroup.LayoutParams layoutParams = mLinearLayout.LayoutParameters;
                    layoutParams.Height = value;
                    mLinearLayout.LayoutParameters = layoutParams;
                };
            return animator;
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        protected override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }
    }
}