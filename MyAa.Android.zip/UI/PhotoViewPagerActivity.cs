using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using System.ComponentModel;
using MyAverisClient;
using MyAverisEntity;
using Newtonsoft.Json;
using Android.Support.V7.App;
using Square.Picasso;
using Square.OkHttp;
using Android.Support.V4.View;

namespace MyAa.Droid
{
    [Activity(Label = "PhotoViewPagerActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class PhotoViewPagerActivity : AppCompatActivity
    {
        String StatePosition = "STATE_POSITION";
        PhotoGridViewAdapter adapter;
        ViewPager vp;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            int pagerPosition = savedInstanceState == null ? 0 : savedInstanceState.GetInt(StatePosition);

            SetContentView(Resource.Layout.PhotoViewPager);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Photo);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            vp = FindViewById<ViewPager>(Resource.Id.view_pager);
            if (CacheManager.Photos != null)
            {
                vp.Adapter = new PhotoPagerAdapter(this, CacheManager.Photos);
                vp.CurrentItem = CacheManager.PhotoAdapterPosition;
            }
        }

        protected override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        protected override void OnSaveInstanceState(Bundle outState)
        {
            outState.PutInt(StatePosition, vp.CurrentItem);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }
    }
}