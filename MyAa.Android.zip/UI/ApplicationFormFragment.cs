using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using MyAverisCommon;
using System.ComponentModel;
using MyAverisEntity;
using MyAverisClient;
using Square.Picasso;
using Newtonsoft.Json;
using Android.Preferences;

namespace MyAa.Droid
{
    [Activity(Label = "ApplicationFormFragment")]
    public class ApplicationFormFragment : Fragment
    {
        Java.IO.File imageFile, imageDir;
        ImageView imgProf;
        ProgressDialog _processProgress;
        View view;
        Android.Net.Uri contentUri = null;
        int request = 0;
        Bitmap bmp = null;
        string strResult;
        byte[] bitmapData;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            _processProgress = new ProgressDialog(this.Activity);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);

            _processProgress.Show();
            BackgroundWorker shortWorker = new BackgroundWorker();
            shortWorker.DoWork += shortWorker_DoWork;
            shortWorker.RunWorkerCompleted += shortWorker_RunWorkerCompleted;
            shortWorker.RunWorkerAsync();
        }

        public override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        public override void OnDestroyView()
        {
            GC.Collect();
            base.OnDestroyView();
        }

        public override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        public override void OnResume()
        {
            base.OnResume();
            if (CacheManager.ReturnFromCamera)
            {
                //view.FindViewById<ScrollView>(Resource.Id.scrollApplicationForm).Visibility = ViewStates.Gone;
                //view.FindViewById<LinearLayout>(Resource.Id.layInstructions).Visibility = ViewStates.Gone;
                //view.FindViewById<ScrollView>(Resource.Id.scrollApplicationForm).Visibility = ViewStates.Visible;
            }
            else
                CacheManager.ReturnFromCamera = false;
        }

        void shortWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetJobApplicationStatus", headers);
        }

        void shortWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this.Activity, typeof(MainActivity));
                            StartActivity(intent);
                            this.Activity.FinishAffinity();
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        if (CacheManager.JobInfo == null)
                        {
                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                            alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                            alert.SetMessage(this.Resources.GetString(Resource.String.EnableInternet));
                            alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                            {
                                var intent = new Intent(this.Activity, typeof(MainActivity));
                                StartActivity(intent);
                                this.Activity.FinishAffinity();
                            });

                            this.Activity.RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                        }
                    }
                    else
                    {
                        ShortJobApplicationInfo info = null;
                        try
                        {
                            info = JsonConvert.DeserializeObject<ShortJobApplicationInfo>(strResult);
                        }
                        catch { }

                        CacheManager.PositionApplied = info.PositionApplied;
                        Database.UpdateUserPositionApplied(info.PositionApplied);
                        var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(this.Activity);
                        try
                        {
                            sharedPreferences.Edit().PutString(QuickstartPreferences.POSITION_APPLIED, info.PositionApplied).Apply();
                        }
                        catch { }

                        CacheManager.JobInfo.ApplicationStatus = info.ApplicationStatus;
                        CacheManager.JobInfo.IsLocked = info.IsLocked;
                        CacheManager.IsLocked = CacheManager.JobInfo.IsLocked.GetValueOrDefault();

                        JobApplication app = Database.GetJobApplication();
                        app.ApplicationStatus = info.ApplicationStatus;
                        app.IsLocked = info.IsLocked.GetValueOrDefault();

                        Database.UpdateJobApplication(app);

                        try
                        {
                            ((MainActivity)this.Activity).UpdateControl();
                        }
                        catch { }

                        ResumeData();
                    }
                }
            }
            catch { }

            try { _processProgress.Dismiss(); }
            catch { }
        }

        private void ResumeData()
        {
            if (view != null)
            {
                if (string.IsNullOrEmpty(CacheManager.JobInfo.ApplicationStatus))
                {
                    CacheManager.JobInfo.ApplicationStatus = InitialData.NewApplicationStatus.New;

                    JobApplication app = Database.GetJobApplication();
                    app.ApplicationStatus = CacheManager.JobInfo.ApplicationStatus;
                    Database.UpdateJobApplication(app);
                }

                //view.FindViewById<TextView>(Resource.Id.tvApplicationStatus).Text = CacheManager.JobInfo.ApplicationStatus;
                //view.FindViewById<TextView>(Resource.Id.tvPositionApplied).Text = CacheManager.PositionApplied;
                if (CacheManager.IsLocked)
                {
                    if (CacheManager.JobInfo != null && CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Submitted)
                        view.FindViewById<TextView>(Resource.Id.tvLockedInfo).Visibility = ViewStates.Visible;
                    else
                        view.FindViewById<TextView>(Resource.Id.tvLockedInfo).Visibility = ViewStates.Gone;
                }
                else
                    view.FindViewById<TextView>(Resource.Id.tvLockedInfo).Visibility = ViewStates.Gone;

                try
                {
                    if (CacheManager.JobInfo.Photo != null)
                    {
                        if (CacheManager.ProfileBitmap != null)
                            CacheManager.ProfileBitmap.Dispose();
                        CacheManager.ProfileBitmap = null;
                        CacheManager.ProfileBitmap = BitmapFactory.DecodeByteArray(CacheManager.JobInfo.Photo, 0, CacheManager.JobInfo.Photo.Length);
                    }
                }
                catch { }

                if (CacheManager.ProfileBitmap == null)
                {
                    float d = this.Activity.Resources.DisplayMetrics.Density;
                    Picasso picasso = Picasso.With(this.Activity);
                    string filePath = CacheManager.ProfileURL + CacheManager.UserID.ToString() + ".jpg";
                    picasso.Load(filePath)
                        .Placeholder(Resource.Drawable.prof_pic)
                        .Error(Resource.Drawable.prof_pic)
                        .Resize((int)d * 150, (int)d * 150)
                        .CenterInside()
                        .Tag(this.Activity)
                        .Into(imgProf);
                }
                else
                {
                    try
                    {
                        imgProf.SetScaleType(Android.Widget.ImageView.ScaleType.CenterInside);
                        imgProf.SetImageBitmap(CacheManager.ProfileBitmap);
                    }
                    catch { }
                }

                PopulateData();

                if (CacheManager.JobInfo.ApplicationStatus != InitialData.NewApplicationStatus.MedicalCheckUp &&
                    CacheManager.JobInfo.ApplicationStatus != InitialData.NewApplicationStatus.Accepted &&
                    CacheManager.JobInfo.ApplicationStatus != InitialData.NewApplicationStatus.FailedMedical &&
                    CacheManager.JobInfo.ApplicationStatus != InitialData.NewApplicationStatus.KIV)
                {
                    view.FindViewById<LinearLayout>(Resource.Id.layMCU).Visibility = ViewStates.Gone;
                }
                else
                    view.FindViewById<LinearLayout>(Resource.Id.layMCU).Visibility = ViewStates.Visible;
            }
        }

        private void PopulateData()
        {
            if (view != null && CacheManager.JobInfo != null)
            {
                if (!string.IsNullOrEmpty(CacheManager.JobInfo.FirstName))
                {
                    string personalInfo = string.Empty;
                    personalInfo += CacheManager.JobInfo.Title + " " + CacheManager.JobInfo.FirstName;

                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.LastName))
                        personalInfo += " " + CacheManager.JobInfo.LastName;

                    view.FindViewById<TextView>(Resource.Id.tvPersonalInfo).Text = personalInfo;
                    view.FindViewById<TextView>(Resource.Id.tvPersonalInfo).SetTextColor(Color.Black);
                }
                else
                {
                    view.FindViewById<TextView>(Resource.Id.tvPersonalInfo).Text = this.Activity.Resources.GetString(Resource.String.TapToEditTitle);
                }

                if (!string.IsNullOrEmpty(CacheManager.JobInfo.EmailAddress))
                {
                    string contactDetails = string.Empty;
                    contactDetails += CacheManager.JobInfo.EmailAddress;
                    if (CacheManager.JobInfo.CurrentAddress != null && !string.IsNullOrEmpty(CacheManager.JobInfo.CurrentAddress.Address))
                        contactDetails += "\n" + CacheManager.JobInfo.CurrentAddress.MobileNumber;

                    view.FindViewById<TextView>(Resource.Id.tvContactDetails).Text = contactDetails;
                    view.FindViewById<TextView>(Resource.Id.tvContactDetails).SetTextColor(Color.Black);
                }
                else
                {
                    view.FindViewById<TextView>(Resource.Id.tvContactDetails).Text = this.Activity.Resources.GetString(Resource.String.TapToEditTitle);
                }

                LinearLayout layoutFamily = view.FindViewById<LinearLayout>(Resource.Id.layFamilyDetailsData);
                try
                {
                    int count = layoutFamily.ChildCount;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        View v = layoutFamily.GetChildAt(i);
                        if (v.GetType().Equals(typeof(RelativeLayout)))
                        {
                            layoutFamily.RemoveViewAt(i);
                        }
                    }
                }
                catch { }

                if (CacheManager.JobInfo.Families != null && CacheManager.JobInfo.Families.Count > 0)
                {
                    view.FindViewById<TextView>(Resource.Id.tvFamilyDetails).Visibility = ViewStates.Gone;
                    //layout.RemoveAllViews();

                    float d = this.Activity.Resources.DisplayMetrics.Density;
                    for (int i = 0; i < CacheManager.JobInfo.Families.Count; i++)
                    {
                        JobApplicationFamilyInfo info = CacheManager.JobInfo.Families[i];

                        RelativeLayout rel = new RelativeLayout(this.Activity);
                        RelativeLayout.LayoutParams layParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MatchParent, RelativeLayout.LayoutParams.WrapContent);
                        rel.LayoutParameters = layParams;
                        rel.SetPadding((int)(10 * d), (int)(10 * d), (int)(10 * d), (int)(10 * d));
                        rel.Clickable = true;
                        rel.Tag = i;
                        layoutFamily.AddView(rel);

                        TextView tv = new TextView(this.Activity);
                        RelativeLayout.LayoutParams tvParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MatchParent, RelativeLayout.LayoutParams.WrapContent);
                        tvParams.LeftMargin = (int)(10 * d);
                        tv.LayoutParameters = tvParams;
                        tv.Text = info.FirstName;
                        if (!string.IsNullOrEmpty(info.LastName))
                            tv.Text += " " + info.LastName;
                        if (!string.IsNullOrEmpty(info.Relationship))
                            tv.Text += ", " + info.Relationship;
                        tv.SetTextColor(Color.Black);
                        rel.AddView(tv);

                        ImageView iv = new ImageView(this.Activity);
                        RelativeLayout.LayoutParams ivParams = new RelativeLayout.LayoutParams((int)(20 * d), (int)(20 * d));
                        ivParams.RightMargin = (int)(10 * d);
                        ivParams.AddRule(LayoutRules.AlignParentRight);
                        iv.LayoutParameters = ivParams;
                        iv.SetScaleType(Android.Widget.ImageView.ScaleType.FitXy);
                        iv.SetImageResource(Resource.Drawable.edit);
                        rel.AddView(iv);
                        rel.Click += FamilyData_Click;
                    }
                }
                else
                {
                    view.FindViewById<TextView>(Resource.Id.tvFamilyDetails).Visibility = ViewStates.Visible;
                }

                LinearLayout layoutEducation = view.FindViewById<LinearLayout>(Resource.Id.layEducationData);
                try
                {
                    int count = layoutEducation.ChildCount;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        View v = layoutEducation.GetChildAt(i);
                        if (v.GetType().Equals(typeof(RelativeLayout)))
                        {
                            layoutEducation.RemoveViewAt(i);
                        }
                    }
                }
                catch { }

                if (CacheManager.JobInfo.Educations != null && CacheManager.JobInfo.Educations.Count > 0)
                {
                    view.FindViewById<TextView>(Resource.Id.tvEducation).Visibility = ViewStates.Gone;

                    float d = this.Activity.Resources.DisplayMetrics.Density;
                    for (int i = 0; i < CacheManager.JobInfo.Educations.Count; i++)
                    {
                        JobApplicationEducationInfo info = CacheManager.JobInfo.Educations[i];

                        RelativeLayout rel = new RelativeLayout(this.Activity);
                        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        rel.LayoutParameters = layParams;
                        rel.SetPadding((int)(10 * d), (int)(10 * d), (int)(10 * d), (int)(10 * d));
                        rel.Clickable = true;
                        rel.Tag = i;
                        layoutEducation.AddView(rel);

                        TextView tv = new TextView(this.Activity);
                        RelativeLayout.LayoutParams tvParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MatchParent, RelativeLayout.LayoutParams.WrapContent);
                        tvParams.LeftMargin = (int)(10 * d);
                        tv.LayoutParameters = tvParams;
                        tv.Text = info.Institution;
                        if (info.StartDate.HasValue)
                            tv.Text += "\n" + info.StartDate.GetValueOrDefault().ToString("yyyy") + " - " + (info.EndDate.HasValue ? info.EndDate.GetValueOrDefault().ToString("yyyy") : "PRESENT");
                        tv.SetTextColor(Color.Black);
                        rel.AddView(tv);

                        ImageView iv = new ImageView(this.Activity);
                        RelativeLayout.LayoutParams ivParams = new RelativeLayout.LayoutParams((int)(20 * d), (int)(20 * d));
                        ivParams.RightMargin = (int)(10 * d);
                        ivParams.AddRule(LayoutRules.AlignParentRight);
                        iv.LayoutParameters = ivParams;
                        iv.SetScaleType(Android.Widget.ImageView.ScaleType.FitXy);
                        iv.SetImageResource(Resource.Drawable.edit);
                        rel.AddView(iv);
                        rel.Click += EducationData_Click;
                    }
                }
                else
                {
                    view.FindViewById<TextView>(Resource.Id.tvEducation).Visibility = ViewStates.Visible;
                }

                LinearLayout layoutLanguage = view.FindViewById<LinearLayout>(Resource.Id.layLanguageSkillsData);
                try
                {
                    int count = layoutLanguage.ChildCount;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        View v = layoutLanguage.GetChildAt(i);
                        if (v.GetType().Equals(typeof(RelativeLayout)))
                        {
                            layoutLanguage.RemoveViewAt(i);
                        }
                    }
                }
                catch { }

                if (CacheManager.JobInfo.Languages != null && CacheManager.JobInfo.Languages.Count > 0)
                {
                    view.FindViewById<TextView>(Resource.Id.tvLanguageSkills).Visibility = ViewStates.Gone;

                    float d = this.Activity.Resources.DisplayMetrics.Density;
                    for (int i = 0; i < CacheManager.JobInfo.Languages.Count; i++)
                    {
                        JobApplicationLanguageInfo info = CacheManager.JobInfo.Languages[i];

                        RelativeLayout rel = new RelativeLayout(this.Activity);
                        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        rel.LayoutParameters = layParams;
                        rel.SetPadding((int)(10 * d), (int)(10 * d), (int)(10 * d), (int)(10 * d));
                        rel.Clickable = true;
                        rel.Tag = i;
                        layoutLanguage.AddView(rel);

                        TextView tv = new TextView(this.Activity);
                        RelativeLayout.LayoutParams tvParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MatchParent, RelativeLayout.LayoutParams.WrapContent);
                        tvParams.LeftMargin = (int)(10 * d);
                        tv.LayoutParameters = tvParams;
                        tv.Text = info.Language;
                        tv.SetTextColor(Color.Black);
                        rel.AddView(tv);

                        ImageView iv = new ImageView(this.Activity);
                        RelativeLayout.LayoutParams ivParams = new RelativeLayout.LayoutParams((int)(20 * d), (int)(20 * d));
                        ivParams.RightMargin = (int)(10 * d);
                        ivParams.AddRule(LayoutRules.AlignParentRight);
                        iv.LayoutParameters = ivParams;
                        iv.SetScaleType(Android.Widget.ImageView.ScaleType.FitXy);
                        iv.SetImageResource(Resource.Drawable.edit);
                        rel.AddView(iv);
                        rel.Click += LanguageData_Click;
                    }
                }
                else
                {
                    view.FindViewById<TextView>(Resource.Id.tvLanguageSkills).Visibility = ViewStates.Visible;
                }

                LinearLayout layoutWorkingHistory = view.FindViewById<LinearLayout>(Resource.Id.layWorkingHistoriesData);
                try
                {
                    int count = layoutWorkingHistory.ChildCount;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        View v = layoutWorkingHistory.GetChildAt(i);
                        if (v.GetType().Equals(typeof(RelativeLayout)))
                        {
                            layoutWorkingHistory.RemoveViewAt(i);
                        }
                    }
                }
                catch { }

                if (CacheManager.JobInfo.WorkingHistories != null && CacheManager.JobInfo.WorkingHistories.Count > 0)
                {
                    view.FindViewById<TextView>(Resource.Id.tvWorkingHistories).Visibility = ViewStates.Gone;

                    float d = this.Activity.Resources.DisplayMetrics.Density;
                    for (int i = 0; i < CacheManager.JobInfo.WorkingHistories.Count; i++)
                    {
                        JobApplicationWorkingHistoryInfo info = CacheManager.JobInfo.WorkingHistories[i];

                        RelativeLayout rel = new RelativeLayout(this.Activity);
                        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        rel.LayoutParameters = layParams;
                        rel.SetPadding((int)(10 * d), (int)(10 * d), (int)(10 * d), (int)(10 * d));
                        rel.Clickable = true;
                        rel.Tag = i;
                        layoutWorkingHistory.AddView(rel);

                        TextView tv = new TextView(this.Activity);
                        RelativeLayout.LayoutParams tvParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MatchParent, RelativeLayout.LayoutParams.WrapContent);
                        tvParams.LeftMargin = (int)(10 * d);
                        tv.LayoutParameters = tvParams;
                        tv.Text = info.Company;
                        if (info.StartDate.HasValue)
                            tv.Text += "\n" + info.StartDate.GetValueOrDefault().ToString("yyyy") + " - " + (info.EndDate.HasValue ? info.EndDate.GetValueOrDefault().ToString("yyyy") : "PRESENT");
                        if (!string.IsNullOrEmpty(info.LastPositionHeld))
                            tv.Text += "\n" + info.LastPositionHeld;
                        tv.SetTextColor(Color.Black);
                        rel.AddView(tv);

                        ImageView iv = new ImageView(this.Activity);
                        RelativeLayout.LayoutParams ivParams = new RelativeLayout.LayoutParams((int)(20 * d), (int)(20 * d));
                        ivParams.RightMargin = (int)(10 * d);
                        ivParams.AddRule(LayoutRules.AlignParentRight);
                        iv.LayoutParameters = ivParams;
                        iv.SetScaleType(Android.Widget.ImageView.ScaleType.FitXy);
                        iv.SetImageResource(Resource.Drawable.edit);
                        rel.AddView(iv);
                        rel.Click += WorkingHistoryData_Click;
                    }
                }
                else
                {
                    view.FindViewById<TextView>(Resource.Id.tvWorkingHistories).Visibility = ViewStates.Visible;
                }

                LinearLayout layoutActivity = view.FindViewById<LinearLayout>(Resource.Id.layActivitiesData);
                try
                {
                    int count = layoutActivity.ChildCount;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        View v = layoutActivity.GetChildAt(i);
                        if (v.GetType().Equals(typeof(RelativeLayout)))
                        {
                            layoutActivity.RemoveViewAt(i);
                        }
                    }
                }
                catch { }

                if (CacheManager.JobInfo.Activities != null && CacheManager.JobInfo.Activities.Count > 0)
                {
                    view.FindViewById<TextView>(Resource.Id.tvActivities).Visibility = ViewStates.Gone;

                    float d = this.Activity.Resources.DisplayMetrics.Density;
                    for (int i = 0; i < CacheManager.JobInfo.Activities.Count; i++)
                    {
                        JobApplicationActivityInfo info = CacheManager.JobInfo.Activities[i];

                        RelativeLayout rel = new RelativeLayout(this.Activity);
                        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        rel.LayoutParameters = layParams;
                        rel.SetPadding((int)(10 * d), (int)(10 * d), (int)(10 * d), (int)(10 * d));
                        rel.Clickable = true;
                        rel.Tag = i;
                        layoutActivity.AddView(rel);

                        TextView tv = new TextView(this.Activity);
                        RelativeLayout.LayoutParams tvParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MatchParent, RelativeLayout.LayoutParams.WrapContent);
                        tvParams.LeftMargin = (int)(10 * d);
                        tv.LayoutParameters = tvParams;
                        tv.Text = info.Organisation;
                        if (info.FromDate.HasValue)
                            tv.Text += "\n" + info.FromDate.GetValueOrDefault().ToString("yyyy") + " - " + (info.ToDate.HasValue ? info.ToDate.GetValueOrDefault().ToString("yyyy") : "PRESENT");
                        tv.SetTextColor(Color.Black);
                        rel.AddView(tv);

                        ImageView iv = new ImageView(this.Activity);
                        RelativeLayout.LayoutParams ivParams = new RelativeLayout.LayoutParams((int)(20 * d), (int)(20 * d));
                        ivParams.RightMargin = (int)(10 * d);
                        ivParams.AddRule(LayoutRules.AlignParentRight);
                        iv.LayoutParameters = ivParams;
                        iv.SetScaleType(Android.Widget.ImageView.ScaleType.FitXy);
                        iv.SetImageResource(Resource.Drawable.edit);
                        rel.AddView(iv);
                        rel.Click += ActivityData_Click;
                    }
                }
                else
                {
                    view.FindViewById<TextView>(Resource.Id.tvActivities).Visibility = ViewStates.Visible;
                }

                if (CacheManager.JobInfo.References != null && CacheManager.JobInfo.References.Count > 0)
                {
                    string reference = string.Empty;
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.References[0].Name))
                    {
                        reference += CacheManager.JobInfo.References[0].Name + "\n" + CacheManager.JobInfo.References[0].Occupation;
                    }

                    if (CacheManager.JobInfo.References.Count > 1 && !string.IsNullOrEmpty(CacheManager.JobInfo.References[1].Name))
                    {
                        reference += "\n\n" + CacheManager.JobInfo.References[1].Name + "\n" + CacheManager.JobInfo.References[1].Occupation;
                    }

                    view.FindViewById<TextView>(Resource.Id.tvReference).Text = reference;
                    view.FindViewById<TextView>(Resource.Id.tvReference).SetTextColor(Color.Black);
                }
                else
                {
                    view.FindViewById<TextView>(Resource.Id.tvReference).Text = this.Activity.Resources.GetString(Resource.String.TapToEditTitle);
                }

                if (CacheManager.JobInfo.PackageDetail != null)
                {
                    try
                    {
                        string detail = string.Empty;
                        if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.ExpectedSalary))
                        {
                            detail += this.Activity.Resources.GetString(Resource.String.ExpectedText) + " : " + Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.ExpectedSalary);

                            view.FindViewById<TextView>(Resource.Id.tvRemuneration).Text = detail;
                            view.FindViewById<TextView>(Resource.Id.tvRemuneration).SetTextColor(Color.Black);
                        }
                        else
                        {
                            view.FindViewById<TextView>(Resource.Id.tvRemuneration).Text = this.Activity.Resources.GetString(Resource.String.TapToEditTitle);
                        }
                    }
                    catch
                    {
                        view.FindViewById<TextView>(Resource.Id.tvRemuneration).Text = this.Activity.Resources.GetString(Resource.String.TapToEditTitle);
                    }
                }
                else
                {
                    view.FindViewById<TextView>(Resource.Id.tvRemuneration).Text = this.Activity.Resources.GetString(Resource.String.TapToEditTitle);
                }

                if (CacheManager.JobInfo.Additional != null)
                {
                    try
                    {
                        string detail = string.Empty;
                        if (CacheManager.JobInfo.Additional.DateAvailable.HasValue)
                        {
                            detail += this.Activity.Resources.GetString(Resource.String.DateAvailableText) + " : " + CacheManager.JobInfo.Additional.DateAvailable.GetValueOrDefault().ToString("dd-MM-yyyy");

                            view.FindViewById<TextView>(Resource.Id.tvAdditional).Text = detail;
                            view.FindViewById<TextView>(Resource.Id.tvAdditional).SetTextColor(Color.Black);
                        }
                        else
                        {
                            view.FindViewById<TextView>(Resource.Id.tvAdditional).Text = this.Activity.Resources.GetString(Resource.String.TapToEditTitle);
                        }
                    }
                    catch
                    {
                        view.FindViewById<TextView>(Resource.Id.tvAdditional).Text = this.Activity.Resources.GetString(Resource.String.TapToEditTitle);
                    }
                }
                else
                {
                    view.FindViewById<TextView>(Resource.Id.tvAdditional).Text = this.Activity.Resources.GetString(Resource.String.TapToEditTitle);
                }
            }
        }

        void FamilyData_Click(object sender, EventArgs e)
        {
            RelativeLayout layout = sender as RelativeLayout;
            int tag = -1;
            try
            {
                tag = (int)layout.Tag;
            }
            catch { }
            if (tag > -1)
            {
                CacheManager.FamilyPosition = tag;
                CacheManager.FamilyInfo = CacheManager.JobInfo.Families[tag];
                var intent = new Intent(this.Activity, typeof(FamilyDetailsActivity));
                StartActivity(intent);
            }
        }

        void EducationData_Click(object sender, EventArgs e)
        {
            RelativeLayout layout = sender as RelativeLayout;
            int tag = -1;
            try
            {
                tag = (int)layout.Tag;
            }
            catch { }
            if (tag > -1)
            {
                CacheManager.EducationPosition = tag;
                CacheManager.EducationInfo = CacheManager.JobInfo.Educations[tag];
                var intent = new Intent(this.Activity, typeof(EducationDetailsActivity));
                StartActivity(intent);
            }
        }

        void LanguageData_Click(object sender, EventArgs e)
        {
            RelativeLayout layout = sender as RelativeLayout;
            int tag = -1;
            try
            {
                tag = (int)layout.Tag;
            }
            catch { }
            if (tag > -1)
            {
                CacheManager.LanguagePosition = tag;
                CacheManager.LanguageInfo = CacheManager.JobInfo.Languages[tag];
                var intent = new Intent(this.Activity, typeof(LanguageSkillsActivity));
                StartActivity(intent);
            }
        }

        void WorkingHistoryData_Click(object sender, EventArgs e)
        {
            RelativeLayout layout = sender as RelativeLayout;
            int tag = -1;
            try
            {
                tag = (int)layout.Tag;
            }
            catch { }
            if (tag > -1)
            {
                CacheManager.WorkingHistoryPosition = tag;
                CacheManager.WorkingHistoryInfo = CacheManager.JobInfo.WorkingHistories[tag];
                var intent = new Intent(this.Activity, typeof(WorkingHistoriesActivity));
                StartActivity(intent);
            }
        }

        void ActivityData_Click(object sender, EventArgs e)
        {
            RelativeLayout layout = sender as RelativeLayout;
            int tag = -1;
            try
            {
                tag = (int)layout.Tag;
            }
            catch { }
            if (tag > -1)
            {
                CacheManager.ActivityPosition = tag;
                CacheManager.ActivityInfo = CacheManager.JobInfo.Activities[tag];
                var intent = new Intent(this.Activity, typeof(ActivitiesActivity));
                StartActivity(intent);
            }
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            try
            {
                if (view == null)
                    view = inflater.Inflate(Resource.Layout.ApplicationFormFragment, container, false);

                view.FindViewById<RelativeLayout>(Resource.Id.layPersonalInfo).Click += PersonalInfo_OnClick;
                view.FindViewById<RelativeLayout>(Resource.Id.layContactDetails).Click += ContactDetails_OnClick;
                view.FindViewById<RelativeLayout>(Resource.Id.layFamilyDetails).Click += FamilyDetails_OnClick;
                view.FindViewById<RelativeLayout>(Resource.Id.layEducation).Click += EducationDetails_OnClick;
                view.FindViewById<RelativeLayout>(Resource.Id.layLanguageSkills).Click += LanguageSkills_OnClick;
                view.FindViewById<RelativeLayout>(Resource.Id.layWorkingHistory).Click += WorkingHistories_OnClick;
                view.FindViewById<RelativeLayout>(Resource.Id.layActivities).Click += Activities_OnClick;
                view.FindViewById<RelativeLayout>(Resource.Id.layReferences).Click += References_OnClick;
                view.FindViewById<RelativeLayout>(Resource.Id.layRemuneration).Click += Remuneration_OnClick;
                view.FindViewById<RelativeLayout>(Resource.Id.layAdditional).Click += Additional_OnClick;
                view.FindViewById<ImageView>(Resource.Id.imgProf).Click += ProfilePicture_OnClick;

                imgProf = view.FindViewById<ImageView>(Resource.Id.imgProf);
            }
            catch { }

            return view;
        }

        void ProfilePicture_OnClick(object sender, EventArgs e)
        {
            SelectImage();
        }

        void PersonalInfo_OnClick(object sender, EventArgs e)
        {
            var intent = new Intent(this.Activity, typeof(PersonalInfoActivity));
            StartActivity(intent);
        }

        void ContactDetails_OnClick(object sender, EventArgs e)
        {
            var intent = new Intent(this.Activity, typeof(ContactDetailsActivity));
            StartActivity(intent);
        }

        void FamilyDetails_OnClick(object sender, EventArgs e)
        {
            if (!CacheManager.IsLocked)
            {
                CacheManager.FamilyInfo = null;
                var intent = new Intent(this.Activity, typeof(FamilyDetailsActivity));
                StartActivity(intent);
            }
        }

        void EducationDetails_OnClick(object sender, EventArgs e)
        {
            if (!CacheManager.IsLocked)
            {
                CacheManager.EducationInfo = null;
                var intent = new Intent(this.Activity, typeof(EducationDetailsActivity));
                StartActivity(intent);
            }
        }

        void LanguageSkills_OnClick(object sender, EventArgs e)
        {
            if (!CacheManager.IsLocked)
            {
                CacheManager.LanguageInfo = null;
                var intent = new Intent(this.Activity, typeof(LanguageSkillsActivity));
                StartActivity(intent);
            }
        }

        void WorkingHistories_OnClick(object sender, EventArgs e)
        {
            if (!CacheManager.IsLocked)
            {
                CacheManager.WorkingHistoryInfo = null;
                var intent = new Intent(this.Activity, typeof(WorkingHistoriesActivity));
                StartActivity(intent);
            }
        }

        void Activities_OnClick(object sender, EventArgs e)
        {
            if (!CacheManager.IsLocked)
            {
                CacheManager.ActivityInfo = null;
                var intent = new Intent(this.Activity, typeof(ActivitiesActivity));
                StartActivity(intent);
            }
        }

        void References_OnClick(object sender, EventArgs e)
        {
            var intent = new Intent(this.Activity, typeof(ReferencesActivity));
            StartActivity(intent);
        }

        void Remuneration_OnClick(object sender, EventArgs e)
        {
            var intent = new Intent(this.Activity, typeof(RemunerationActivity));
            StartActivity(intent);
        }

        void Additional_OnClick(object sender, EventArgs e)
        {
            var intent = new Intent(this.Activity, typeof(AdditionalInfoActivity));
            StartActivity(intent);
        }

        public override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);

            try
            {
                if (resultCode == Result.Ok)
                {
                    if (requestCode == 3)
                    {
                        _processProgress.Show();
                        BackgroundWorker worker = new BackgroundWorker();
                        worker.DoWork += worker_DoWork;
                        worker.RunWorkerCompleted += worker_RunWorkerCompleted;
                        worker.RunWorkerAsync();
                    }
                    else
                    {
                        contentUri = null;
                        request = 0;
                        if (requestCode == 1)
                        {
                            request = 1;
                            contentUri = Android.Net.Uri.FromFile(imageFile);

                            imageFile = new Java.IO.File(imageDir, String.Format("myPhoto_{0}.jpg", Guid.NewGuid()));

                            Bitmap bmp = GetBitmap(contentUri);
                            ExifInterface ei = new ExifInterface(contentUri.Path);
                            string orientation = ei.GetAttribute(ExifInterface.TagOrientation);

                            switch (orientation)
                            {
                                case "6":
                                    bmp = RotateImage(bmp, 90);
                                    break;
                                case "3":
                                    bmp = RotateImage(bmp, 180);
                                    break;
                                case "8":
                                    bmp = RotateImage(bmp, 270);
                                    break;
                                case "1":
                                default:
                                    break;
                            }

                            try
                            {
                                GC.Collect();

                                var stream = new FileStream(imageFile.Path, FileMode.Create);
                                bmp.Compress(Bitmap.CompressFormat.Jpeg, 75, stream);
                                stream.Close();

                                GC.Collect();

                                contentUri = Android.Net.Uri.FromFile(imageFile);

                                CacheManager.ReturnFromCamera = true;
                                Intent intent = new Intent(this.Activity, typeof(CropImage));
                                intent.PutExtra("image-path", contentUri.Path);
                                intent.PutExtra("scale", true);
                                StartActivityForResult(intent, 3);
                            }
                            catch { }
                        }
                        if (requestCode == 2)
                        {
                            request = 2;
                            contentUri = data.Data;

                            imageFile = new Java.IO.File(imageDir, String.Format("myPhoto_{0}.jpg", Guid.NewGuid()));

                            Bitmap bmp = GetBitmap(contentUri);
                            ExifInterface ei = new ExifInterface(GetRealPathFromURI(contentUri));
                            string orientation = ei.GetAttribute(ExifInterface.TagOrientation);

                            switch (orientation)
                            {
                                case "6":
                                    bmp = RotateImage(bmp, 90);
                                    break;
                                case "3":
                                    bmp = RotateImage(bmp, 180);
                                    break;
                                case "8":
                                    bmp = RotateImage(bmp, 270);
                                    break;
                                case "1":
                                default:
                                    break;
                            }

                            try
                            {
                                GC.Collect();

                                var stream = new FileStream(imageFile.Path, FileMode.Create);
                                bmp.Compress(Bitmap.CompressFormat.Jpeg, 75, stream);
                                stream.Close();

                                GC.Collect();

                                contentUri = Android.Net.Uri.FromFile(imageFile);

                                CacheManager.ReturnFromCamera = true;
                                Intent intent = new Intent(this.Activity, typeof(CropImage));
                                intent.PutExtra("image-path", contentUri.Path);
                                intent.PutExtra("scale", true);
                                StartActivityForResult(intent, 3);
                            }
                            catch { }
                        }
                    }
                }
            }
            catch { }
        }

        public String GetRealPathFromURI(Android.Net.Uri contentUri)
        {
            string doc_id = "";
            using (var c1 = this.Activity.ContentResolver.Query(contentUri, null, null, null, null))
            {
                c1.MoveToFirst();
                String document_id = c1.GetString(0);
                doc_id = document_id.Substring(document_id.LastIndexOf(":") + 1);
            }

            string path = null;

            // The projection contains the columns we want to return in our query.
            string selection = Android.Provider.MediaStore.Images.Media.InterfaceConsts.Id + " =? ";
            using (var cursor = this.Activity.ManagedQuery(Android.Provider.MediaStore.Images.Media.ExternalContentUri, null, selection, new string[] { doc_id }, null))
            {
                if (cursor == null) return path;
                var columnIndex = cursor.GetColumnIndexOrThrow(Android.Provider.MediaStore.Images.Media.InterfaceConsts.Data);
                cursor.MoveToFirst();
                path = cursor.GetString(columnIndex);
            }
            return path;
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            if (contentUri != null && request != 0)
            {
                try
                {
                    bitmapData = null;
                    bmp = NGetBitmap(contentUri);

                    using (var stream = new MemoryStream())
                    {
                        bmp.Compress(Bitmap.CompressFormat.Jpeg, 50, stream);
                        bitmapData = stream.ToArray();
                    }

                    GC.Collect();
                }
                catch { }
            }
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (bitmapData != null)
            {
                BackgroundWorker uploadWorker = new BackgroundWorker();
                uploadWorker.DoWork += uploadWorker_DoWork;
                uploadWorker.RunWorkerCompleted += uploadWorker_RunWorkerCompleted;
                uploadWorker.RunWorkerAsync();
            }
            else
            {
                try { _processProgress.Dismiss(); }
                catch { }

                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.FailUpload));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                this.Activity.RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
        }

        void uploadWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("UploadProfilePicture", headers, bitmapData);
        }

        void uploadWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            GC.Collect();

            if (!string.IsNullOrEmpty(strResult))
            {
                try { _processProgress.Dismiss(); }
                catch { }

                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.FailUpload));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                this.Activity.RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
            else
            {
                BackgroundWorker updateWorker = new BackgroundWorker();
                updateWorker.DoWork += updateWorker_DoWork;
                updateWorker.RunWorkerCompleted += updateWorker_RunWorkerCompleted;
                updateWorker.RunWorkerAsync();
            }
        }

        void updateWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                JobApplication app = Database.GetJobApplication();

                if (bitmapData != null)
                {
                    CacheManager.JobInfo.Photo = bitmapData;
                    app.Photo = bitmapData;
                    Database.UpdateJobApplication(app);

                    Java.IO.File proImageDir = new Java.IO.File(Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryPictures),
                                "MyAverisImage");
                    if (!proImageDir.Exists())
                    {
                        proImageDir.Mkdirs();
                    }
                    Java.IO.File proImageFile = new Java.IO.File(proImageDir, "prof_pic.jpg");

                    try
                    {
                        var stream = new FileStream(proImageFile.Path, FileMode.Create);
                        bmp.Compress(Bitmap.CompressFormat.Jpeg, 50, stream);
                        stream.Close();
                    }
                    catch { }
                }

                GC.Collect();

                List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
                headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
                headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

                RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
                strResult = client.ProcessRequest("GetUserData", headers);
            }
            catch { }
        }

        void updateWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this.Activity, typeof(MainActivity));
                            StartActivity(intent);
                            this.Activity.FinishAffinity();
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        if (CacheManager.JobInfo == null)
                        {
                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                            alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                            alert.SetMessage(this.Resources.GetString(Resource.String.EnableInternet));
                            alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                            {

                            });

                            this.Activity.RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                        }
                    }
                    else
                    {
                        UserData info = null;
                        try
                        {
                            info = JsonConvert.DeserializeObject<UserData>(strResult);
                        }
                        catch { }

                        CacheManager.HasProfilePicture = info.HasProfilePicture.GetValueOrDefault();
                        Database.UpdateUserHasProfilePicture(info.HasProfilePicture.GetValueOrDefault());

                        var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(this.Activity);
                        try
                        {
                            sharedPreferences.Edit().PutBoolean(QuickstartPreferences.HAS_PROFILE_PICTURE, info.HasProfilePicture.GetValueOrDefault()).Apply();
                        }
                        catch { }

                        OnResume();
                    }
                }
            }
            catch { }
            try { _processProgress.Dismiss(); }
            catch { }
        }

        public static Bitmap RotateImage(Bitmap source, float angle)
        {
            Matrix matrix = new Matrix();
            matrix.PostRotate(angle);
            return Bitmap.CreateBitmap(source, 0, 0, source.Width, source.Height, matrix, true);
        }

        private Bitmap GetBitmap(Android.Net.Uri uriImage)
        {
            Android.Graphics.Bitmap mBitmap = null;
            mBitmap = Android.Provider.MediaStore.Images.Media.GetBitmap(this.Activity.ContentResolver, uriImage);
            mBitmap = ResizeBitmap(mBitmap, 1500, 1500);
            return mBitmap;
        }

        private Bitmap NGetBitmap(Android.Net.Uri uriImage)
        {
            Android.Graphics.Bitmap mBitmap = null;
            mBitmap = Android.Provider.MediaStore.Images.Media.GetBitmap(this.Activity.ContentResolver, uriImage);
            mBitmap = ResizeBitmap(mBitmap, 750, 750);
            return mBitmap;
        }

        private Bitmap ResizeBitmap(Bitmap image, int maxWidth, int maxHeight)
        {
            if (maxHeight > 0 && maxWidth > 0)
            {
                int width = image.Width;
                int height = image.Height;
                float ratioBitmap = (float)width / (float)height;
                float ratioMax = (float)maxWidth / (float)maxHeight;

                int finalWidth = maxWidth;
                int finalHeight = maxHeight;
                if (ratioMax > 1)
                {
                    finalWidth = (int)((float)maxHeight * ratioBitmap);
                }
                else
                {
                    finalHeight = (int)((float)maxWidth / ratioBitmap);
                }
                image = Bitmap.CreateScaledBitmap(image, finalWidth, finalHeight, true);
                return image;
            }
            else
            {
                return image;
            }
        }

        private void SelectImage()
        {
            string[] items = { "Take Photo", "Choose from Gallery", "Cancel" };
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
            alert.SetTitle("Add Photo!");
            alert.SetItems(items, (senderAlert, args) =>
            {
                //bool result = Utility.checkPermission(MainActivity.this);
                if (items[args.Which] == "Take Photo")
                {
                    if (IsThereAnAppToTakePictures())
                    {
                        CreateDirectoryForPictures();
                        CacheManager.ReturnFromCamera = true;
                        Intent intent = new Intent(MediaStore.ActionImageCapture);
                        imageFile = new Java.IO.File(imageDir, String.Format("myPhoto_{0}.jpg", Guid.NewGuid()));
                        intent.PutExtra(MediaStore.ExtraOutput, Android.Net.Uri.FromFile(imageFile));
                        StartActivityForResult(intent, 1);
                    }
                }
                else if (items[args.Which] == "Choose from Library")
                {
                    CreateDirectoryForPictures();
                    CacheManager.ReturnFromCamera = true;
                    Intent intent = new Intent();
                    intent.SetType("image/*");
                    intent.SetAction(Intent.ActionGetContent);
                    StartActivityForResult(Intent.CreateChooser(intent, "Select File"), 2);
                }
            });

            this.Activity.RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        private bool IsThereAnAppToTakePictures()
        {
            Intent intent = new Intent(MediaStore.ActionImageCapture);
            PackageManager pm = this.Activity.PackageManager;
            IList<ResolveInfo> availableActivities = pm.QueryIntentActivities(intent, PackageInfoFlags.MatchDefaultOnly);
            return availableActivities != null && availableActivities.Count > 0;
        }

        private void CreateDirectoryForPictures()
        {
            try
            {
                imageDir = new Java.IO.File(Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryPictures),
                    "MyAverisImage");
                if (!imageDir.Exists())
                {
                    imageDir.Mkdirs();
                }
            }
            catch { }
        }

        /* Checks if external storage is available for read and write */
        public bool IsExternalStorageWritable()
        {
            if (Android.OS.Environment.ExternalStorageState == Android.OS.Environment.MediaMounted)
            {
                return true;
            }
            return false;
        }
    }
}