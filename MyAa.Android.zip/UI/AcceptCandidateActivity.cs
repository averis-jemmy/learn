using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using Android.Animation;
using Android.Graphics;
using System.ComponentModel;
using MyAverisClient;
using Newtonsoft.Json;
using MyAverisEntity;
using MyAverisCommon;

namespace MyAa.Droid
{
    [Activity(Label = "AcceptCandidateActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class AcceptCandidateActivity : AppCompatActivity
    {
        ProgressDialog _processProgress;
        string strResult;
        PreBoardingInfo model;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.AcceptCandidate);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.MyAa);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            FindViewById<Spinner>(Resource.Id.spinOffice).Adapter = new SpinnerData(this, CommonData.Offices);

            FindViewById<TextView>(Resource.Id.etJoinDate).Click += JoinDate_OnClick;

            FindViewById<Button>(Resource.Id.btnAccept).Click += Accept_OnClick;

            _processProgress = new ProgressDialog(this);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);
        }

        void Accept_OnClick(object sender, EventArgs e)
        {
            if (ValidateData())
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.Confirmation));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
                {
                    _processProgress.Show();

                    BackgroundWorker acceptWorker = new BackgroundWorker();
                    acceptWorker.DoWork += acceptWorker_DoWork;
                    acceptWorker.RunWorkerCompleted += acceptWorker_RunWorkerCompleted;
                    acceptWorker.RunWorkerAsync();
                });
                alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
        }

        void acceptWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            string requestData = JsonConvert.SerializeObject(model,
                                              new JsonSerializerSettings() { DateFormatHandling = DateFormatHandling.MicrosoftDateFormat });
            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, requestData);
            strResult = client.ProcessRequest("Accept", headers);
        }

        void acceptWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!string.IsNullOrEmpty(strResult))
            {
                try { _processProgress.Dismiss(); }
                catch { }

                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.FailUpdate));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return;
            }
            else
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.HireSuccess));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                    try
                    {
                        var item = (from info in CacheManager.JobApplicationInfos
                                    where info.ID == CacheManager.JobID
                                    select info).FirstOrDefault();

                        CacheManager.JobApplicationInfos.Remove(item);
                    }
                    catch { }

                    SetResult(Result.Ok);
                    Finish();
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
            try { _processProgress.Dismiss(); }
            catch { }
        }

        private void JoinDate_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etJoinDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etJoinDate).Text = time.ToString("dd - MMM - yyyy");
            }, selected, DateTime.Now, DateTime.Now.AddYears(1));
            frag.Show(FragmentManager, DatePickerFragment.TAG);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        private void MessageBox(string title, string message)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle(title);
            alert.SetMessage(message);
            alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
            {

            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(FindViewById<Spinner>(Resource.Id.spinOffice).SelectedItem.ToString()))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input office.");
                return false;
            }
            if (string.IsNullOrEmpty(FindViewById<TextView>(Resource.Id.etJoinDate).Text))
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Please input join date.");
                return false;
            }

            try
            {
                model = new PreBoardingInfo();
                model.JobID = CacheManager.JobID;
                model.UserID = CacheManager.UserID;
                model.Position = CacheManager.PositionApplied;
                model.Office = FindViewById<Spinner>(Resource.Id.spinOffice).SelectedItem.ToString();
                model.JoinDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etJoinDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch
            {
                MessageBox(this.Resources.GetString(Resource.String.Error), "Data errors.");
                return false;
            }

            return true;
        }
    }
}