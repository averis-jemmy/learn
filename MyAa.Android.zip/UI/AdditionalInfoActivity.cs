using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using Android.Animation;
using Android.Graphics;
using MyAverisCommon;
using MyAverisEntity;

namespace MyAa.Droid
{
    [Activity(Label = "AdditionalInfoActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class AdditionalInfoActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.AdditionalInfo);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Additional);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            if (!CacheManager.IsLocked)
            {
                FindViewById<TextView>(Resource.Id.etDateAvailable).Click += DateAvailable_OnClick;
            }

            if (CacheManager.JobInfo != null && CacheManager.JobInfo.Additional != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        private void DateAvailable_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDateAvailable).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etDateAvailable).Text = time.ToString("dd - MMM - yyyy");
            }, selected, DateTime.Now, DateTime.Now.AddYears(5));
            frag.Show(FragmentManager, DatePickerFragment.TAG);
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            if (CacheManager.JobInfo.Additional.ReferenceCheck.HasValue)
            {
                if (CacheManager.JobInfo.Additional.ReferenceCheck.GetValueOrDefault())
                    FindViewById<RadioButton>(Resource.Id.rbRefYes).Checked = true;
                else
                    FindViewById<RadioButton>(Resource.Id.rbRefNo).Checked = true;
            }
            FindViewById<EditText>(Resource.Id.etRefRemarks).Text = CacheManager.JobInfo.Additional.ReferenceRemarks;

            if (CacheManager.JobInfo.Additional.DateAvailable.HasValue)
                FindViewById<TextView>(Resource.Id.etDateAvailable).Text = CacheManager.JobInfo.Additional.DateAvailable.Value.ToString("dd - MMM - yyyy");

            if (CacheManager.JobInfo.Additional.CanTravel.HasValue)
            {
                if (CacheManager.JobInfo.Additional.CanTravel.GetValueOrDefault())
                    FindViewById<RadioButton>(Resource.Id.rbTravelYes).Checked = true;
                else
                    FindViewById<RadioButton>(Resource.Id.rbTravelNo).Checked = true;
            }

            if (CacheManager.JobInfo.Additional.CanRelocate.HasValue)
            {
                if (CacheManager.JobInfo.Additional.CanRelocate.GetValueOrDefault())
                    FindViewById<RadioButton>(Resource.Id.rbRelYes).Checked = true;
                else
                    FindViewById<RadioButton>(Resource.Id.rbRelNo).Checked = true;
            }

            FindViewById<EditText>(Resource.Id.etReasonForJoining).Text = CacheManager.JobInfo.Additional.ReasonForJoining;
            FindViewById<EditText>(Resource.Id.etCareerObjective).Text = CacheManager.JobInfo.Additional.CareerObjective;
            FindViewById<EditText>(Resource.Id.etRecommendation).Text = CacheManager.JobInfo.Additional.Recommendation;
            FindViewById<EditText>(Resource.Id.etKnowingCompany).Text = CacheManager.JobInfo.Additional.KnowingCompany;
        }

        private void LockData()
        {
            FindViewById<RadioButton>(Resource.Id.rbRefYes).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbRefNo).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbTravelYes).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbTravelNo).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbRelYes).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbRelNo).Enabled = false;

            FindViewById<EditText>(Resource.Id.etRefRemarks).Enabled = false;
            FindViewById<EditText>(Resource.Id.etReasonForJoining).Enabled = false;
            FindViewById<EditText>(Resource.Id.etCareerObjective).Enabled = false;
            FindViewById<EditText>(Resource.Id.etRecommendation).Enabled = false;
            FindViewById<EditText>(Resource.Id.etKnowingCompany).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                if (CacheManager.JobInfo.Additional == null)
                    CacheManager.JobInfo.Additional = new JobApplicationAdditionalInfo();

                if (!FindViewById<RadioButton>(Resource.Id.rbRefYes).Checked && !FindViewById<RadioButton>(Resource.Id.rbRefNo).Checked)
                    CacheManager.JobInfo.Additional.ReferenceCheck = null;
                else
                    CacheManager.JobInfo.Additional.ReferenceCheck = FindViewById<RadioButton>(Resource.Id.rbRefYes).Checked;

                try
                {
                    CacheManager.JobInfo.Additional.DateAvailable = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDateAvailable).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                }
                catch
                {
                    CacheManager.JobInfo.Additional.DateAvailable = null;
                }

                if (!FindViewById<RadioButton>(Resource.Id.rbTravelYes).Checked && !FindViewById<RadioButton>(Resource.Id.rbTravelNo).Checked)
                    CacheManager.JobInfo.Additional.CanTravel = null;
                else
                    CacheManager.JobInfo.Additional.CanTravel = FindViewById<RadioButton>(Resource.Id.rbTravelYes).Checked;

                if (!FindViewById<RadioButton>(Resource.Id.rbRelYes).Checked && !FindViewById<RadioButton>(Resource.Id.rbRelNo).Checked)
                    CacheManager.JobInfo.Additional.CanRelocate = null;
                else
                    CacheManager.JobInfo.Additional.CanRelocate = FindViewById<RadioButton>(Resource.Id.rbRelYes).Checked;

                CacheManager.JobInfo.Additional.ReferenceRemarks = FindViewById<EditText>(Resource.Id.etRefRemarks).Text;
                CacheManager.JobInfo.Additional.ReasonForJoining = FindViewById<EditText>(Resource.Id.etReasonForJoining).Text;
                CacheManager.JobInfo.Additional.CareerObjective = FindViewById<EditText>(Resource.Id.etCareerObjective).Text;
                CacheManager.JobInfo.Additional.Recommendation = FindViewById<EditText>(Resource.Id.etRecommendation).Text;
                CacheManager.JobInfo.Additional.KnowingCompany = FindViewById<EditText>(Resource.Id.etKnowingCompany).Text;

                JobApplicationAdditional model = new JobApplicationAdditional()
                {
                    ReferenceCheck = CacheManager.JobInfo.Additional.ReferenceCheck,
                    ReferenceRemarks = CacheManager.JobInfo.Additional.ReferenceRemarks,
                    DateAvailable = CacheManager.JobInfo.Additional.DateAvailable,
                    CanTravel = CacheManager.JobInfo.Additional.CanTravel,
                    CanRelocate = CacheManager.JobInfo.Additional.CanRelocate,
                    ReasonForJoining = CacheManager.JobInfo.Additional.ReasonForJoining,
                    CareerObjective = CacheManager.JobInfo.Additional.CareerObjective,
                    Recommendation = CacheManager.JobInfo.Additional.Recommendation,
                    KnowingCompany = CacheManager.JobInfo.Additional.KnowingCompany
                };

                Database.UpdateAdditional(model);
            }

            Finish();
        }

        private bool ValidateData()
        {
            return true;
        }
    }
}