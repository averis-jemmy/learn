using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using MyAverisCommon;
using System.ComponentModel;
using MyAverisEntity;
using MyAverisClient;
using Square.Picasso;
using Android.Support.V7.App;
using Newtonsoft.Json;

namespace MyAa.Droid
{
    [Activity(Label = "JobApplicationDisplayActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class JobApplicationDisplayActivity : AppCompatActivity
    {
        ImageView imgProf;
        ProgressDialog _processProgress;
        string strResult, strStatus;
        int HIRED = 1;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.JobApplicationDisplay);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.JobApplication);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            FindViewById<Spinner>(Resource.Id.spinApplicationStatus).Adapter = new SpinnerData(this, CommonData.GetApplicationStatuses());

            FindViewById<Button>(Resource.Id.btnUpdate).Click += Update_OnClick;
            FindViewById<Button>(Resource.Id.btnLockUnlock).Click += LockUnlock_OnClick;

            if (CacheManager.JobInfo != null && !CacheManager.JobInfo.IsLocked.GetValueOrDefault())
                FindViewById<Button>(Resource.Id.btnLockUnlock).Text = this.Resources.GetString(Resource.String.LockText);
            else
                FindViewById<Button>(Resource.Id.btnLockUnlock).Text = this.Resources.GetString(Resource.String.UnlockText);

            _processProgress = new ProgressDialog(this);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);

            imgProf = FindViewById<ImageView>(Resource.Id.imgProf);

            float d = this.Resources.DisplayMetrics.Density;
            Picasso picasso = Picasso.With(this);
            string filePath = CacheManager.ProfileURL + CacheManager.JobInfo.UserID.ToString() + ".jpg";
            picasso.Load(filePath)
                .Placeholder(Resource.Drawable.prof_pic)
                .Error(Resource.Drawable.prof_pic)
                .Resize((int)d * 150, (int)d * 150)
                .CenterInside()
                .Tag(this)
                .Into(imgProf);

            PopulateData();
            CacheManager.ProcessProgress.Dismiss();
        }

        protected override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        void Update_OnClick(object sender, EventArgs e)
        {
            try
            {
                strStatus = CommonData.GetStatusCode(FindViewById<Spinner>(Resource.Id.spinApplicationStatus).SelectedItem.ToString());

                if (string.IsNullOrEmpty(strStatus))
                {
                    Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                    alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                    alert.SetMessage(this.Resources.GetString(Resource.String.StatusRequired));
                    alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                    {
                    });

                    RunOnUiThread(() =>
                    {
                        alert.Show();
                    });
                }
                else
                {
                    if (strStatus == InitialData.NewApplicationStatus.Accepted)
                    {
                        var intent = new Intent(this, typeof(AcceptCandidateActivity));
                        StartActivityForResult(intent, HIRED);
                    }
                    else
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                        alert.SetMessage(this.Resources.GetString(Resource.String.StatusConfirmation));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
                        {
                            _processProgress.Show();

                            BackgroundWorker statusWorker = new BackgroundWorker();
                            statusWorker.DoWork += statusWorker_DoWork;
                            statusWorker.RunWorkerCompleted += statusWorker_RunWorkerCompleted;
                            statusWorker.RunWorkerAsync();
                        });
                        alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
                        {
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                }
            }
            catch { }
        }

        void statusWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            ShortJobApplicationInfo model = new ShortJobApplicationInfo()
            {
                ID = CacheManager.JobID,
                UserID = CacheManager.UserID,
                ApplicationStatus = strStatus
            };
            string requestData = JsonConvert.SerializeObject(model,
                                              new JsonSerializerSettings() { DateFormatHandling = DateFormatHandling.MicrosoftDateFormat });

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, requestData);
            strResult = client.ProcessRequest("UpdateJobApplicationStatus", headers);
        }

        void statusWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!string.IsNullOrEmpty(strResult))
            {
                try { _processProgress.Dismiss(); }
                catch { }

                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.FailUpdate));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return;
            }
            else
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.UpdateSuccess));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                    try
                    {
                        if (strStatus == InitialData.NewApplicationStatus.Rejected ||
                            strStatus == InitialData.NewApplicationStatus.RejectedOffer ||
                            strStatus == InitialData.NewApplicationStatus.KIV ||
                            strStatus == InitialData.NewApplicationStatus.FailedMedical)
                        {
                            var item = (from info in CacheManager.JobApplicationInfos
                                        where info.ID == CacheManager.JobID
                                        select info).FirstOrDefault();

                            CacheManager.JobApplicationInfos.Remove(item);
                        }
                    }
                    catch { }

                    Finish();
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
            try { _processProgress.Dismiss(); }
            catch { }
        }

        void LockUnlock_OnClick(object sender, EventArgs e)
        {
            if (FindViewById<Button>(Resource.Id.btnLockUnlock).Text == this.Resources.GetString(Resource.String.UnlockText))
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.UnlockConfirmation));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
                {
                    _processProgress.Show();

                    BackgroundWorker unlockWorker = new BackgroundWorker();
                    unlockWorker.DoWork += unlockWorker_DoWork;
                    unlockWorker.RunWorkerCompleted += unlockWorker_RunWorkerCompleted;
                    unlockWorker.RunWorkerAsync();
                });
                alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
            else
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.LockConfirmation));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
                {
                    _processProgress.Show();

                    BackgroundWorker lockWorker = new BackgroundWorker();
                    lockWorker.DoWork += lockWorker_DoWork;
                    lockWorker.RunWorkerCompleted += lockWorker_RunWorkerCompleted;
                    lockWorker.RunWorkerAsync();
                });
                alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
        }

        void unlockWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.JobID.ToString() + "\"");
            strResult = client.ProcessRequest("Unlock", headers);
        }

        void unlockWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!string.IsNullOrEmpty(strResult))
            {
                try { _processProgress.Dismiss(); }
                catch { }

                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.FailUpdate));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return;
            }
            else
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.UnlockSuccess));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                    CacheManager.JobInfo.IsLocked = false;
                    FindViewById<Button>(Resource.Id.btnLockUnlock).Text = "LOCK";
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
            try { _processProgress.Dismiss(); }
            catch { }
        }

        void lockWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.JobID.ToString() + "\"");
            strResult = client.ProcessRequest("Lock", headers);
        }

        void lockWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!string.IsNullOrEmpty(strResult))
            {
                try { _processProgress.Dismiss(); }
                catch { }

                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.FailUpdate));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return;
            }
            else
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.LockSuccess));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                    CacheManager.JobInfo.IsLocked = true;
                    FindViewById<Button>(Resource.Id.btnLockUnlock).Text = this.Resources.GetString(Resource.String.UnlockText);
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
            try { _processProgress.Dismiss(); }
            catch { }
        }

        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);

            if (requestCode == HIRED)
            {
                if (resultCode == Result.Ok)
                {
                    Finish();
                }
            }
        }

        protected override void OnResume()
        {
            base.OnResume();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        private void PopulateData()
        {
            if (CacheManager.JobInfo != null)
            {
                string name = string.Empty;
                name += CacheManager.JobInfo.Title + " " + CacheManager.JobInfo.FirstName;
                if (!string.IsNullOrEmpty(CacheManager.JobInfo.LastName))
                    name += " " + CacheManager.JobInfo.LastName;

                FindViewById<TextView>(Resource.Id.tvName).Text = name;
                FindViewById<TextView>(Resource.Id.tvGender).Text = "Gender: " + (CacheManager.JobInfo.Gender == "M" ? "Male" : "Female");
                FindViewById<TextView>(Resource.Id.tvDOB).Text = "Date of Birth: " +
                    (CacheManager.JobInfo.DateOfBirth.HasValue ? CacheManager.JobInfo.DateOfBirth.GetValueOrDefault().ToString("dd-MMM-yyyy") : string.Empty);
                FindViewById<TextView>(Resource.Id.tvPlaceOfBirth).Text = "Place of Birth: " + CacheManager.JobInfo.PlaceOfBirth;
                FindViewById<TextView>(Resource.Id.tvCountryOfBirth).Text = "Country of Birth: " + CacheManager.JobInfo.CountryOfBirth;
                FindViewById<TextView>(Resource.Id.tvNationality).Text = "Nationality: " + CacheManager.JobInfo.Nationality;
                FindViewById<TextView>(Resource.Id.tvRace).Text = "Race: " + CacheManager.JobInfo.Race;
                FindViewById<TextView>(Resource.Id.tvMaritalStatus).Text = "Marital Status: " + CacheManager.JobInfo.MaritalStatus;
                FindViewById<TextView>(Resource.Id.tvReligion).Text = "Religion: " + CacheManager.JobInfo.Religion;

                FindViewById<TextView>(Resource.Id.tvIdentityNumber).Text = "Identity Number/Passport No: " + CacheManager.JobInfo.IdentityNo;
                if (CacheManager.JobInfo.DateOfIssue.HasValue)
                {
                    FindViewById<TextView>(Resource.Id.tvDateOfIssue).Text = "Date of Issue: " +
                        (CacheManager.JobInfo.DateOfIssue.HasValue ? CacheManager.JobInfo.DateOfIssue.GetValueOrDefault().ToString("dd-MMM-yyyy") : string.Empty);
                    FindViewById<TextView>(Resource.Id.tvDateOfExpiry).Text = "Date of Expiry: " +
                        (CacheManager.JobInfo.DateOfExpiry.HasValue ? CacheManager.JobInfo.DateOfExpiry.GetValueOrDefault().ToString("dd-MMM-yyyy") : string.Empty);
                    FindViewById<TextView>(Resource.Id.tvPlaceOfIssue).Text = "Place of Issue: " + CacheManager.JobInfo.PlaceOfIssue;
                    FindViewById<TextView>(Resource.Id.tvCountryOfIssue).Text = "Country of Issue: " + CacheManager.JobInfo.CountryOfIssue;
                    FindViewById<TextView>(Resource.Id.tvDateOfIssue).Visibility = ViewStates.Visible;
                    FindViewById<TextView>(Resource.Id.tvDateOfExpiry).Visibility = ViewStates.Visible;
                    FindViewById<TextView>(Resource.Id.tvPlaceOfIssue).Visibility = ViewStates.Visible;
                    FindViewById<TextView>(Resource.Id.tvCountryOfIssue).Visibility = ViewStates.Visible;
                }
                else
                {
                    FindViewById<TextView>(Resource.Id.tvDateOfIssue).Visibility = ViewStates.Gone;
                    FindViewById<TextView>(Resource.Id.tvDateOfExpiry).Visibility = ViewStates.Gone;
                    FindViewById<TextView>(Resource.Id.tvPlaceOfIssue).Visibility = ViewStates.Gone;
                    FindViewById<TextView>(Resource.Id.tvCountryOfIssue).Visibility = ViewStates.Gone;
                }

                FindViewById<TextView>(Resource.Id.tvEmailAddress).Text = CacheManager.JobInfo.EmailAddress;

                string address = CacheManager.JobInfo.CurrentAddress.Address +
                    "\n" + CacheManager.JobInfo.CurrentAddress.PostalCode + "\n" + CacheManager.JobInfo.CurrentAddress.Country;
                address += "\nHome Number: " + CacheManager.JobInfo.CurrentAddress.HomeNumber;
                address += "\nMobile Number: " + CacheManager.JobInfo.CurrentAddress.MobileNumber;

                FindViewById<TextView>(Resource.Id.tvCurrentAddress).Text = address;

                if (CacheManager.JobInfo.HomeAddress != null)
                {
                    address = CacheManager.JobInfo.HomeAddress.Address +
                    "\n" + CacheManager.JobInfo.HomeAddress.PostalCode + "\n" + CacheManager.JobInfo.HomeAddress.Country;
                    address += "\nHome Number: " + CacheManager.JobInfo.HomeAddress.HomeNumber;
                    address += "\nMobile Number: " + CacheManager.JobInfo.HomeAddress.MobileNumber;
                }

                FindViewById<TextView>(Resource.Id.tvHomeAddress).Text = address;

                address = "Emergency Contact Person: " + CacheManager.JobInfo.EmergencyContact + "\n";
                if (!string.IsNullOrEmpty(CacheManager.JobInfo.EmergencyAddress.Address))
                {
                    address += CacheManager.JobInfo.EmergencyAddress.Address +
                    "\n" + CacheManager.JobInfo.EmergencyAddress.PostalCode + "\n" + CacheManager.JobInfo.EmergencyAddress.Country;
                    address += "\nHome Number: " + CacheManager.JobInfo.EmergencyAddress.HomeNumber;
                    address += "\nMobile Number: " + CacheManager.JobInfo.EmergencyAddress.MobileNumber;
                }
                else
                {
                    address += CacheManager.JobInfo.CurrentAddress.Address +
                    "\n" + CacheManager.JobInfo.CurrentAddress.PostalCode + "\n" + CacheManager.JobInfo.CurrentAddress.Country;
                    address += "\nHome Number: " + CacheManager.JobInfo.CurrentAddress.HomeNumber;
                    address += "\nMobile Number: " + CacheManager.JobInfo.EmergencyAddress.MobileNumber;
                }

                FindViewById<TextView>(Resource.Id.tvEmergencyAddress).Text = address;

                LinearLayout layoutFamily = FindViewById<LinearLayout>(Resource.Id.layFamilyDetailsData);
                try
                {
                    int count = layoutFamily.ChildCount;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        View v = layoutFamily.GetChildAt(i);
                        if (v.GetType().Equals(typeof(RelativeLayout)))
                        {
                            layoutFamily.RemoveViewAt(i);
                        }
                    }
                }
                catch { }

                if (CacheManager.JobInfo.Families != null && CacheManager.JobInfo.Families.Count > 0)
                {
                    FindViewById<TextView>(Resource.Id.tvFamilyDetails).Visibility = ViewStates.Gone;

                    float d = this.Resources.DisplayMetrics.Density;
                    for (int i = 0; i < CacheManager.JobInfo.Families.Count; i++)
                    {
                        JobApplicationFamilyInfo info = CacheManager.JobInfo.Families[i];

                        LinearLayout rel = new LinearLayout(this);
                        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        rel.LayoutParameters = layParams;
                        rel.SetPadding((int)(10 * d), (int)(10 * d), (int)(10 * d), (int)(10 * d));
                        rel.Clickable = true;
                        rel.Tag = i;
                        rel.Orientation = Android.Widget.Orientation.Vertical;
                        layoutFamily.AddView(rel);

                        TextView tvFamilyName = new TextView(this);
                        LinearLayout.LayoutParams tvParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        tvParams.LeftMargin = (int)(10 * d);
                        tvParams.TopMargin = (int)(5 * d);
                        tvFamilyName.LayoutParameters = tvParams;
                        string familyName = info.FirstName;
                        if (!string.IsNullOrEmpty(info.LastName))
                            familyName += " " + info.LastName;
                        tvFamilyName.Text = familyName;
                        tvFamilyName.SetTypeface(tvFamilyName.Typeface, TypefaceStyle.Bold);
                        tvFamilyName.SetTextColor(Color.Black);
                        rel.AddView(tvFamilyName);

                        TextView tvFamilyDetails = new TextView(this);
                        LinearLayout.LayoutParams tvFParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        tvFParams.LeftMargin = (int)(10 * d);
                        tvFamilyDetails.LayoutParameters = tvFParams;
                        string familyDetails = "Relationship: " + info.Relationship +
                            "\nIC/Passport No: " + info.IdentityNo + "\nGender: " + (info.Gender == "M" ? "Male" : "Female") +
                            "\nDate of Birth: " + info.DateOfBirth.GetValueOrDefault().ToString("dd-MMM-yyyy") +
                            "\nCountry of Birth: " + info.CountryOfBirth + "\nNationality: " + info.Nationality +
                            "\nJob Title: " + info.JobTitle + "\nEmployer: " + info.Employer + "\n" +
                            (info.IsSameCountry.GetValueOrDefault() ? "Currently in the same country" : "Currently in different country");
                        tvFamilyDetails.Text = familyDetails;
                        tvFamilyDetails.SetTextColor(Color.Black);
                        rel.AddView(tvFamilyDetails);
                    }
                }
                else
                {
                    FindViewById<TextView>(Resource.Id.tvFamilyDetails).Visibility = ViewStates.Visible;
                }

                LinearLayout layoutEducation = FindViewById<LinearLayout>(Resource.Id.layEducationData);
                try
                {
                    int count = layoutEducation.ChildCount;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        View v = layoutEducation.GetChildAt(i);
                        if (v.GetType().Equals(typeof(RelativeLayout)))
                        {
                            layoutEducation.RemoveViewAt(i);
                        }
                    }
                }
                catch { }

                if (CacheManager.JobInfo.Educations != null && CacheManager.JobInfo.Educations.Count > 0)
                {
                    var educations = (from item in CacheManager.JobInfo.Educations
                                      orderby item.EndDate == null ? DateTime.Now : item.EndDate descending
                                      select item).ToList();

                    FindViewById<TextView>(Resource.Id.tvEducation).Visibility = ViewStates.Gone;

                    float d = this.Resources.DisplayMetrics.Density;
                    for (int i = 0; i < educations.Count; i++)
                    {
                        JobApplicationEducationInfo info = educations[i];

                        LinearLayout rel = new LinearLayout(this);
                        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        rel.LayoutParameters = layParams;
                        rel.SetPadding((int)(10 * d), (int)(10 * d), (int)(10 * d), (int)(10 * d));
                        rel.Clickable = true;
                        rel.Tag = i;
                        rel.Orientation = Android.Widget.Orientation.Vertical;
                        layoutEducation.AddView(rel);

                        TextView tvEducationName = new TextView(this);
                        LinearLayout.LayoutParams tvParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        tvParams.LeftMargin = (int)(10 * d);
                        tvParams.TopMargin = (int)(5 * d);
                        tvEducationName.LayoutParameters = tvParams;
                        string institution = info.Institution;
                        tvEducationName.Text = institution;
                        tvEducationName.SetTypeface(tvEducationName.Typeface, TypefaceStyle.Bold);
                        tvEducationName.SetTextColor(Color.Black);
                        rel.AddView(tvEducationName);

                        TextView tvEducationDetails = new TextView(this);
                        LinearLayout.LayoutParams tvEParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        tvEParams.LeftMargin = (int)(10 * d);
                        tvEducationDetails.LayoutParameters = tvEParams;
                        string details = info.StartDate.GetValueOrDefault().ToString("dd-MMM-yyyy") + " - " +
                            (info.EndDate.HasValue ? info.EndDate.GetValueOrDefault().ToString("dd-MMM-yyyy") : "PRESENT") +
                            "\nCountry: " + info.Country + "\nQualification: " + info.Qualification +
                            "\nCourse of Study: " + info.CourseOfStudy;
                        tvEducationDetails.Text = details;
                        tvEducationDetails.SetTextColor(Color.Black);
                        rel.AddView(tvEducationDetails);
                    }
                }
                else
                {
                    FindViewById<TextView>(Resource.Id.tvEducation).Visibility = ViewStates.Visible;
                }

                LinearLayout layoutLangauge = FindViewById<LinearLayout>(Resource.Id.layLanguageSkillsData);
                try
                {
                    int count = layoutLangauge.ChildCount;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        View v = layoutLangauge.GetChildAt(i);
                        if (v.GetType().Equals(typeof(RelativeLayout)))
                        {
                            layoutLangauge.RemoveViewAt(i);
                        }
                    }
                }
                catch { }

                if (CacheManager.JobInfo.Languages != null && CacheManager.JobInfo.Languages.Count > 0)
                {
                    FindViewById<TextView>(Resource.Id.tvLanguageSkills).Visibility = ViewStates.Gone;

                    float d = this.Resources.DisplayMetrics.Density;
                    for (int i = 0; i < CacheManager.JobInfo.Languages.Count; i++)
                    {
                        JobApplicationLanguageInfo info = CacheManager.JobInfo.Languages[i];

                        LinearLayout rel = new LinearLayout(this);
                        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        rel.LayoutParameters = layParams;
                        rel.SetPadding((int)(10 * d), (int)(10 * d), (int)(10 * d), (int)(10 * d));
                        rel.Clickable = true;
                        rel.Tag = i;
                        rel.Orientation = Android.Widget.Orientation.Vertical;
                        layoutLangauge.AddView(rel);

                        TextView tvLanguageName = new TextView(this);
                        LinearLayout.LayoutParams tvParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        tvParams.LeftMargin = (int)(10 * d);
                        tvParams.TopMargin = (int)(5 * d);
                        tvLanguageName.LayoutParameters = tvParams;
                        string language = info.Language;
                        tvLanguageName.Text = language;
                        tvLanguageName.SetTypeface(tvLanguageName.Typeface, TypefaceStyle.Bold);
                        tvLanguageName.SetTextColor(Color.Black);
                        rel.AddView(tvLanguageName);

                        TextView tvLanguageDetails = new TextView(this);
                        LinearLayout.LayoutParams tvLParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        tvLParams.LeftMargin = (int)(10 * d);
                        tvLanguageDetails.LayoutParameters = tvLParams;
                        string[] level = new string[4]{
                            "", "AVERAGE", "GOOD", "EXCELLENT"
                        };
                        string details = "Reading Ability: " + level[info.ReadAbility.GetValueOrDefault()] +
                            "\nWriting Ability: " + level[info.WriteAbility.GetValueOrDefault()] +
                            "\nSpeaking Ability: " + level[info.SpeakAbility.GetValueOrDefault()];
                        tvLanguageDetails.Text = details;
                        tvLanguageDetails.SetTextColor(Color.Black);
                        rel.AddView(tvLanguageDetails);
                    }
                }
                else
                {
                    FindViewById<TextView>(Resource.Id.tvLanguageSkills).Visibility = ViewStates.Visible;
                }

                LinearLayout layoutWorkingHistory = FindViewById<LinearLayout>(Resource.Id.layWorkingHistoriesData);
                try
                {
                    int count = layoutWorkingHistory.ChildCount;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        View v = layoutWorkingHistory.GetChildAt(i);
                        if (v.GetType().Equals(typeof(RelativeLayout)))
                        {
                            layoutWorkingHistory.RemoveViewAt(i);
                        }
                    }
                }
                catch { }

                if (CacheManager.JobInfo.WorkingHistories != null && CacheManager.JobInfo.WorkingHistories.Count > 0)
                {
                    var workingHistories = (from item in CacheManager.JobInfo.WorkingHistories
                                            orderby item.EndDate == null ? DateTime.Now : item.EndDate descending
                                            select item).ToList();

                    FindViewById<TextView>(Resource.Id.tvWorkingHistories).Visibility = ViewStates.Gone;

                    float d = this.Resources.DisplayMetrics.Density;
                    for (int i = 0; i < workingHistories.Count; i++)
                    {
                        JobApplicationWorkingHistoryInfo info = workingHistories[i];

                        LinearLayout rel = new LinearLayout(this);
                        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        rel.LayoutParameters = layParams;
                        rel.SetPadding((int)(10 * d), (int)(10 * d), (int)(10 * d), (int)(10 * d));
                        rel.Clickable = true;
                        rel.Tag = i;
                        rel.Orientation = Android.Widget.Orientation.Vertical;
                        layoutWorkingHistory.AddView(rel);

                        TextView tvCompanyName = new TextView(this);
                        LinearLayout.LayoutParams tvParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        tvParams.LeftMargin = (int)(10 * d);
                        tvParams.TopMargin = (int)(5 * d);
                        tvCompanyName.LayoutParameters = tvParams;
                        string company = info.Company;
                        tvCompanyName.Text = company;
                        tvCompanyName.SetTypeface(tvCompanyName.Typeface, TypefaceStyle.Bold);
                        tvCompanyName.SetTextColor(Color.Black);
                        rel.AddView(tvCompanyName);

                        TextView tvCompanyDetails = new TextView(this);
                        LinearLayout.LayoutParams tvCParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        tvCParams.LeftMargin = (int)(10 * d);
                        tvCompanyDetails.LayoutParameters = tvCParams;
                        string details = info.StartDate.GetValueOrDefault().ToString("dd-MMM-yyyy") + " - " +
                            (info.EndDate.HasValue ? info.EndDate.GetValueOrDefault().ToString("dd-MMM-yyyy") : "PRESENT") +
                            "\nCity/Country: " + info.Country + "\nLast Position Held: " + info.LastPositionHeld +
                            "\nName of Superior: " + info.NameOfSuperior + "\nDesignation of Superior: " + info.DesignationOfSuperior +
                            "\nLast Drawn Salary (Rp): " + Cryptography.Decryption(info.LastDrawnSalary) + "\nReason for leaving: " + info.ReasonForLeaving;
                        tvCompanyDetails.Text = details;
                        tvCompanyDetails.SetTextColor(Color.Black);
                        rel.AddView(tvCompanyDetails);
                    }
                }
                else
                {
                    FindViewById<TextView>(Resource.Id.tvWorkingHistories).Visibility = ViewStates.Visible;
                }

                LinearLayout layoutActivity = FindViewById<LinearLayout>(Resource.Id.layActivitiesData);
                try
                {
                    int count = layoutActivity.ChildCount;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        View v = layoutActivity.GetChildAt(i);
                        if (v.GetType().Equals(typeof(RelativeLayout)))
                        {
                            layoutActivity.RemoveViewAt(i);
                        }
                    }
                }
                catch { }

                if (CacheManager.JobInfo.Activities != null && CacheManager.JobInfo.Activities.Count > 0)
                {
                    var activities = (from item in CacheManager.JobInfo.Activities
                                      orderby item.ToDate == null ? DateTime.Now : item.ToDate descending
                                      select item).ToList();

                    FindViewById<TextView>(Resource.Id.tvActivities).Visibility = ViewStates.Gone;

                    float d = this.Resources.DisplayMetrics.Density;
                    for (int i = 0; i < activities.Count; i++)
                    {
                        JobApplicationActivityInfo info = activities[i];

                        LinearLayout rel = new LinearLayout(this);
                        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        rel.LayoutParameters = layParams;
                        rel.SetPadding((int)(10 * d), (int)(10 * d), (int)(10 * d), (int)(10 * d));
                        rel.Clickable = true;
                        rel.Tag = i;
                        rel.Orientation = Android.Widget.Orientation.Vertical;
                        layoutActivity.AddView(rel);

                        TextView tvActivityName = new TextView(this);
                        LinearLayout.LayoutParams tvParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        tvParams.LeftMargin = (int)(10 * d);
                        tvParams.TopMargin = (int)(5 * d);
                        tvActivityName.LayoutParameters = tvParams;
                        string organisation = info.Organisation;
                        tvActivityName.Text = organisation;
                        tvActivityName.SetTypeface(tvActivityName.Typeface, TypefaceStyle.Bold);
                        tvActivityName.SetTextColor(Color.Black);
                        rel.AddView(tvActivityName);

                        TextView tvActivityDetails = new TextView(this);
                        LinearLayout.LayoutParams tvAParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        tvAParams.LeftMargin = (int)(10 * d);
                        tvActivityDetails.LayoutParameters = tvAParams;
                        string details = info.FromDate.GetValueOrDefault().ToString("dd-MMM-yyyy") + " - " +
                            (info.ToDate.HasValue ? info.ToDate.GetValueOrDefault().ToString("dd-MMM-yyyy") : "PRESENT") +
                            "\nCountry: " + info.Country + "\nNature of Activities: " + info.NatureOfActivities;
                        tvActivityDetails.Text = details;
                        tvActivityDetails.SetTextColor(Color.Black);
                        rel.AddView(tvActivityDetails);
                    }
                }
                else
                {
                    FindViewById<TextView>(Resource.Id.tvActivities).Visibility = ViewStates.Visible;
                }

                FindViewById<TextView>(Resource.Id.tvReference).Visibility = ViewStates.Gone;
                FindViewById<TextView>(Resource.Id.tvReference1).Visibility = ViewStates.Gone;
                FindViewById<TextView>(Resource.Id.tvReferenceDetails1).Visibility = ViewStates.Gone;
                FindViewById<TextView>(Resource.Id.tvReference2).Visibility = ViewStates.Gone;
                FindViewById<TextView>(Resource.Id.tvReferenceDetails2).Visibility = ViewStates.Gone;
                if (CacheManager.JobInfo.References != null && CacheManager.JobInfo.References.Count > 0)
                {
                    string reference = string.Empty;
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.References[0].Name))
                    {
                        FindViewById<TextView>(Resource.Id.tvReference1).Visibility = ViewStates.Visible;
                        FindViewById<TextView>(Resource.Id.tvReferenceDetails1).Visibility = ViewStates.Visible;
                        FindViewById<TextView>(Resource.Id.tvReference1).Text = CacheManager.JobInfo.References[0].Name;

                        reference = "Occupation: " + CacheManager.JobInfo.References[0].Occupation +
                            "\nYears Known: " + (CacheManager.JobInfo.References[0].YearsKnown.GetValueOrDefault() > 0 ? CacheManager.JobInfo.References[0].YearsKnown.GetValueOrDefault().ToString() : string.Empty) +
                            "\nAddress: " + CacheManager.JobInfo.References[0].Address +
                            "\nEmployer: " + CacheManager.JobInfo.References[0].Employer +
                            "\nTelephone: " + CacheManager.JobInfo.References[0].MobileNumber +
                            "\nHome: " + CacheManager.JobInfo.References[0].HomeNumber +
                            "\nOffice: " + CacheManager.JobInfo.References[0].OfficeNumber;

                        FindViewById<TextView>(Resource.Id.tvReferenceDetails1).Text = reference;
                    }

                    if (CacheManager.JobInfo.References.Count > 1 && !string.IsNullOrEmpty(CacheManager.JobInfo.References[1].Name))
                    {
                        FindViewById<TextView>(Resource.Id.tvReference2).Visibility = ViewStates.Visible;
                        FindViewById<TextView>(Resource.Id.tvReferenceDetails2).Visibility = ViewStates.Visible;
                        FindViewById<TextView>(Resource.Id.tvReference2).Text = CacheManager.JobInfo.References[1].Name;

                        reference = "Occupation: " + CacheManager.JobInfo.References[1].Occupation +
                            "\nYears Known: " + (CacheManager.JobInfo.References[1].YearsKnown.GetValueOrDefault() > 0 ? CacheManager.JobInfo.References[1].YearsKnown.GetValueOrDefault().ToString() : string.Empty) +
                            "\nAddress: " + CacheManager.JobInfo.References[1].Address +
                            "\nEmployer: " + CacheManager.JobInfo.References[1].Employer +
                            "\nTelephone: " + CacheManager.JobInfo.References[1].MobileNumber +
                            "\nHome: " + CacheManager.JobInfo.References[1].HomeNumber +
                            "\nOffice: " + CacheManager.JobInfo.References[1].OfficeNumber;

                        FindViewById<TextView>(Resource.Id.tvReferenceDetails2).Text = reference;
                    }
                }
                else
                {
                    FindViewById<TextView>(Resource.Id.tvReference).Visibility = ViewStates.Visible;
                }

                if (CacheManager.JobInfo.PackageDetail != null)
                {
                    try
                    {
                        string detail = string.Empty;
                        if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.ExpectedSalary))
                        {
                            detail = "Monthly Basic Salary (Rp) : " + Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.BaseSalary) +
                                "\nExpected Salary (Rp) : " + Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.ExpectedSalary) +
                                "\nFixed/Variable Bonus (Rp) : " + Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.PerformanceBonus) +
                                "\nFixed Commission/Allowance (Rp) : " + Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.ContractualBonus) +
                                "\nOther Benefits (Rp) : " + Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.HousingAllowance) +
                                "\nNotice Period : " + Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.TransportAllowance);

                            FindViewById<TextView>(Resource.Id.tvRemuneration).Text = detail;
                            FindViewById<TextView>(Resource.Id.tvRemuneration).SetTextColor(Color.Black);
                        }
                        else
                        {
                            FindViewById<TextView>(Resource.Id.tvRemuneration).Text = "--Not Available--";
                        }
                    }
                    catch
                    {
                        FindViewById<TextView>(Resource.Id.tvRemuneration).Text = "--Not Available--";
                    }
                }
                else
                {
                    FindViewById<TextView>(Resource.Id.tvRemuneration).Text = "--Not Available--";
                }

                if (CacheManager.JobInfo.Additional != null)
                {
                    try
                    {
                        string detail = string.Empty;
                        if (CacheManager.JobInfo.Additional.DateAvailable.HasValue)
                        {
                            detail = "Could we conduct a reference check with your present and previous employers? If No, please state reasons. : " + (CacheManager.JobInfo.Additional.ReferenceCheck.GetValueOrDefault() ? "Yes" : "No") +
                                "\nReason : " + CacheManager.JobInfo.Additional.ReferenceRemarks +
                                "\nDate available to start work (dd-mm-yyyy) : " + CacheManager.JobInfo.Additional.DateAvailable.GetValueOrDefault().ToString("dd-MM-yyyy") +
                                "\nAre you willing to travel in the course of your employment ? : " + (CacheManager.JobInfo.Additional.CanTravel.GetValueOrDefault() ? "Yes" : "No") +
                                "\nAre you willing to relocate ? : " + (CacheManager.JobInfo.Additional.CanRelocate.GetValueOrDefault() ? "Yes" : "No") +
                                "\nWhy do you wish to join this company ? : " + CacheManager.JobInfo.Additional.ReasonForJoining +
                                "\nWhat is your career objective ? : " + CacheManager.JobInfo.Additional.CareerObjective +
                                "\nPlease furnish any additional information you consider to be helpful in your application : " + CacheManager.JobInfo.Additional.Recommendation +
                                "\nHow did you come to know of the RGE Group ? : " + CacheManager.JobInfo.Additional.KnowingCompany;

                            FindViewById<TextView>(Resource.Id.tvAdditional).Text = detail;
                            FindViewById<TextView>(Resource.Id.tvAdditional).SetTextColor(Color.Black);
                        }
                        else
                        {
                            FindViewById<TextView>(Resource.Id.tvAdditional).Text = "--Not Available--";
                        }
                    }
                    catch
                    {
                        FindViewById<TextView>(Resource.Id.tvAdditional).Text = "--Not Available--";
                    }
                }
                else
                {
                    FindViewById<TextView>(Resource.Id.tvAdditional).Text = "--Not Available--";
                }

                foreach (JobApplicationDeclarationInfo declaration in CacheManager.JobInfo.Declarations)
                {
                    FindViewById<TextView>(Resource.Id.tvDeclaration).Text += "\n" + declaration.DeclarationDetail + "\n" +
                        (declaration.Answer.GetValueOrDefault() ? "Yes" : "No");
                    if (declaration.Answer.GetValueOrDefault())
                        FindViewById<TextView>(Resource.Id.tvDeclaration).Text += "\nRemarks: " + declaration.Remarks;
                    FindViewById<TextView>(Resource.Id.tvDeclaration).Text += "\n\n";
                }
            }
        }
    }
}