using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using System.ComponentModel;
using MyAverisClient;
using Newtonsoft.Json;

namespace MyAa.Droid
{
    [Activity(Label = "PhotoFragment")]
    public class PhotoFragment : Fragment
    {
        ProgressDialog _processProgress;
        String strResult;
        ListView listView;
        CategoriesList adapter;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            _processProgress = new ProgressDialog(this.Activity);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);
        }

        public override void OnResume()
        {
            base.OnResume();

            _processProgress.Show();

            BackgroundWorker refreshWorker = new BackgroundWorker();
            refreshWorker.DoWork += refreshWorker_DoWork;
            refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
            refreshWorker.RunWorkerAsync();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.PhotoFragment, container, false);

            listView = view.FindViewById<ListView>(Resource.Id.listPhoto);
            listView.ItemClick += OnListItemClick;

            if (CacheManager.IsRecruiter)
            {
                view.FindViewById<Button>(Resource.Id.btnUploadPhoto).Visibility = ViewStates.Visible;
                view.FindViewById<Button>(Resource.Id.btnUploadPhoto).Click += UploadPhoto_OnClick;

                //this.Activity.RegisterForContextMenu(listView);
            }

            return view;
        }

        public override void OnCreateContextMenu(IContextMenu menu, View v, IContextMenuContextMenuInfo menuInfo)
        {
            base.OnCreateContextMenu(menu, v, menuInfo);
            if (v.Id == Resource.Id.listPhoto)
            {
                MenuInflater inflater = this.Activity.MenuInflater;
                inflater.Inflate(Resource.Menu.menu_list, menu);
            }
        }

        public override bool OnContextItemSelected(IMenuItem item)
        {
            Android.Widget.AdapterView.AdapterContextMenuInfo info = (Android.Widget.AdapterView.AdapterContextMenuInfo)item.MenuInfo;
            switch (item.ItemId)
            {
                case Resource.Id.menuOpen:
                    return true;
                case Resource.Id.menuDelete:
                    return true;
                default:
                    return base.OnContextItemSelected(item);
            }
        }

        void UploadPhoto_OnClick(object sender, EventArgs e)
        {
            var intent = new Intent(this.Activity, typeof(UploadPhotoActivity));
            StartActivity(intent);
        }

        void OnListItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            string category = adapter[e.Position].Key;
            if (!string.IsNullOrEmpty(category))
            {
                CacheManager.Category = category;
                var intent = new Intent(this.Activity, typeof(PhotoListActivity));
                StartActivity(intent);
            }
        }

        void refreshWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetPhotoCategories", headers);
        }

        void refreshWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this.Activity, typeof(MainActivity));
                            StartActivity(intent);
                            this.Activity.FinishAffinity();
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.FailRefresh));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        List<KeyValuePair<string, int>> infos = JsonConvert.DeserializeObject<List<KeyValuePair<string, int>>>(strResult);
                        adapter = new CategoriesList(this.Activity, infos);
                        listView.Adapter = adapter;
                    }
                }
            }
            catch { }
            try { _processProgress.Dismiss(); }
            catch { }
        }
    }
}