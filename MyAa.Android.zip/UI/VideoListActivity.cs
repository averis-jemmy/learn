using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using System.ComponentModel;
using MyAverisClient;
using MyAverisEntity;
using Newtonsoft.Json;
using Android.Support.V7.App;

namespace MyAa.Droid
{
    [Activity(Label = "VideoListActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class VideoListActivity : AppCompatActivity
    {
        ProgressDialog _processProgress;
        String strResult;
        ListView listView;
        VideosList adapter;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.VideoList);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Video);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            listView = FindViewById<ListView>(Resource.Id.listVideo);
            listView.ItemClick += OnListItemClick;

            RegisterForContextMenu(listView);

            _processProgress = new ProgressDialog(this);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);

            _processProgress.Show();

            BackgroundWorker refreshWorker = new BackgroundWorker();
            refreshWorker.DoWork += refreshWorker_DoWork;
            refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
            refreshWorker.RunWorkerAsync();
        }

        public override void OnCreateContextMenu(IContextMenu menu, View v, IContextMenuContextMenuInfo menuInfo)
        {
            if (v.Id == Resource.Id.listVideo)
            {
                if (CacheManager.IsRecruiter)
                {
                    try
                    {
                        string videoCode = adapter[((Android.Widget.AdapterView.AdapterContextMenuInfo)menuInfo).Position].VideoCode;
                        CacheManager.VideoID = adapter[((Android.Widget.AdapterView.AdapterContextMenuInfo)menuInfo).Position].ID;
                        if (!string.IsNullOrEmpty(videoCode))
                        {
                            CacheManager.VideoCode = videoCode;
                        }
                    }
                    catch { }
                    var info = (AdapterView.AdapterContextMenuInfo)menuInfo;
                    var menuItems = Resources.GetStringArray(Resource.Array.Menu);
                    for (var i = 0; i < menuItems.Length; i++)
                        menu.Add(Menu.None, i, i, menuItems[i]);
                }
            }
        }

        public override bool OnContextItemSelected(IMenuItem item)
        {
            var info = (AdapterView.AdapterContextMenuInfo)item.MenuInfo;
            var menuItemIndex = item.ItemId;
            var menuItems = Resources.GetStringArray(Resource.Array.Menu);
            var menuItemName = menuItems[menuItemIndex];

            switch (menuItemName)
            {
                case "Open":
                    if (!string.IsNullOrEmpty(CacheManager.VideoCode))
                    {
                        var intent = new Intent(this, typeof(YouTubePlayerActivity));
                        StartActivity(intent);
                    }
                    break;
                case "Delete":
                    _processProgress.Show();

                    BackgroundWorker deleteWorker = new BackgroundWorker();
                    deleteWorker.DoWork += deleteWorker_DoWork;
                    deleteWorker.RunWorkerCompleted += deleteWorker_RunWorkerCompleted;
                    deleteWorker.RunWorkerAsync();
                    break;
                default:
                    break;
            }

            return true;
        }

        void deleteWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.VideoID.ToString() + "\"");
            strResult = client.ProcessRequest("DeleteVideo", headers);
        }

        void deleteWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    try { _processProgress.Dismiss(); }
                    catch { }

                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.FailDelete));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                        return;
                    }
                }
            }
            catch { }

            BackgroundWorker refreshWorker = new BackgroundWorker();
            refreshWorker.DoWork += refreshWorker_DoWork;
            refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
            refreshWorker.RunWorkerAsync();
        }

        void OnListItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            string videoCode = adapter[e.Position].VideoCode;
            if (!string.IsNullOrEmpty(videoCode))
            {
                CacheManager.VideoCode = videoCode;
                var intent = new Intent(this, typeof(YouTubePlayerActivity));
                StartActivity(intent);
            }
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        void refreshWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.Category + "\"");
            strResult = client.ProcessRequest("GetVideoFromCategory", headers);
        }

        void refreshWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.FailRefresh));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        List<VideoInfo> infos = JsonConvert.DeserializeObject<List<VideoInfo>>(strResult);

                        CacheManager.Videos = infos;
                        adapter = new VideosList(this, infos);
                        listView.Adapter = adapter;
                    }
                }
            }
            catch { }
            try { _processProgress.Dismiss(); }
            catch { }
        }
    }
}