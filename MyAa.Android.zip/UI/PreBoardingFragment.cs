using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using System.ComponentModel;
using MyAverisClient;
using Newtonsoft.Json;
using MyAverisEntity;
using MyAverisCommon;
using Google.YouTube.Player;

namespace MyAa.Droid
{
    [Activity(Label = "PreBoardingFragment")]
    public class PreBoardingFragment : Fragment, IYouTubePlayerOnInitializedListener
    {
        ProgressDialog _processProgress;
        String strResult, strWelcomeSpeechCode;
        RelativeLayout layWelcomePart;
        LinearLayout layNormalWelcomeMessage, layWelcomeMessage;
        TextView tvWelcomeMessage, tvLastWelcomeMessage;
        TextView tvJoinDate, tvLocation, tvContact;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            _processProgress = new ProgressDialog(this.Activity);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);

            CacheManager.ProcessProgress = new ProgressDialog(this.Activity);
            CacheManager.ProcessProgress.Indeterminate = true;
            CacheManager.ProcessProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            CacheManager.ProcessProgress.SetMessage("Loading...");
            CacheManager.ProcessProgress.SetCancelable(false);
        }

        public override void OnResume()
        {
            base.OnResume();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.PreBoardingFragment, container, false);
            layWelcomePart = view.FindViewById<RelativeLayout>(Resource.Id.layWelcomePart);
            layNormalWelcomeMessage = view.FindViewById<LinearLayout>(Resource.Id.layNormalWelcomeMessage);
            layWelcomeMessage = view.FindViewById<LinearLayout>(Resource.Id.layWelcomeMessage);
            tvWelcomeMessage = view.FindViewById<TextView>(Resource.Id.tvWelcomeMessage);
            tvLastWelcomeMessage = view.FindViewById<TextView>(Resource.Id.tvLastWelcomeMessage);
            tvJoinDate = view.FindViewById<TextView>(Resource.Id.tvJoinDate);
            tvLocation = view.FindViewById<TextView>(Resource.Id.tvLocation);
            tvContact = view.FindViewById<TextView>(Resource.Id.tvContact);

            view.FindViewById<RelativeLayout>(Resource.Id.layUsefulLink).Click += UsefulLink_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layDressCode).Click += DressCode_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layOfficeLocation).Click += OfficeLocation_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layOperations).Click += Operations_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layFoodBeverage).Click += FoodBeverage_Click;

            _processProgress.Show();
            layWelcomePart.Visibility = ViewStates.Gone;
            layNormalWelcomeMessage.Visibility = ViewStates.Gone;
            layWelcomeMessage.Visibility = ViewStates.Gone;

            if (CacheManager.JobInfo != null && CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Accepted)
            {
                layWelcomePart.Visibility = ViewStates.Visible;
                BackgroundWorker refreshWorker = new BackgroundWorker();
                refreshWorker.DoWork += refreshWorker_DoWork;
                refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
                refreshWorker.RunWorkerAsync();
            }
            else
            {
                try { _processProgress.Dismiss(); }
                catch { }
            }

            return view;
        }

        public override void OnPause()
        {
            base.OnPause();
        }

        public override void OnDestroyView()
        {
            GC.Collect();
            base.OnDestroyView();
        }

        public override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        void FoodBeverage_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(FoodBeverageActivity));
            StartActivity(intent);
        }

        void Operations_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(OperationsActivity));
            StartActivity(intent);
        }

        void OfficeLocation_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(OfficeLocationActivity));
            StartActivity(intent);
        }

        void UsefulLink_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(UsefulLinkActivity));
            StartActivity(intent);
        }

        void DressCode_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(DressCodeActivity));
            StartActivity(intent);
        }

        public override void OnCreateContextMenu(IContextMenu menu, View v, IContextMenuContextMenuInfo menuInfo)
        {
            base.OnCreateContextMenu(menu, v, menuInfo);
            if (v.Id == Resource.Id.listPhoto)
            {
                MenuInflater inflater = this.Activity.MenuInflater;
                inflater.Inflate(Resource.Menu.menu_list, menu);
            }
        }

        public override bool OnContextItemSelected(IMenuItem item)
        {
            Android.Widget.AdapterView.AdapterContextMenuInfo info = (Android.Widget.AdapterView.AdapterContextMenuInfo)item.MenuInfo;
            switch (item.ItemId)
            {
                case Resource.Id.menuOpen:
                    return true;
                case Resource.Id.menuDelete:
                    return true;
                default:
                    return base.OnContextItemSelected(item);
            }
        }

        void refreshWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetPreBoardingInfo", headers);
        }

        void refreshWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this.Activity, typeof(MainActivity));
                            StartActivity(intent);
                            this.Activity.FinishAffinity();
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });

                        try { _processProgress.Dismiss(); }
                        catch { }
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        layNormalWelcomeMessage.Visibility = ViewStates.Visible;

                        try { _processProgress.Dismiss(); }
                        catch { }
                    }
                    else
                    {
                        PreBoardingInfo info = JsonConvert.DeserializeObject<PreBoardingInfo>(strResult);
                        if ((info.JoinDate.GetValueOrDefault() - DateTime.Now).TotalDays < 100)
                        {
                            layWelcomeMessage.Visibility = ViewStates.Visible;
                            tvJoinDate.Text = info.JoinDate.GetValueOrDefault().ToString("dd-MMM-yyyy");
                            var model = CacheManager.GetOfficeDetail(info.Office);
                            tvLocation.Text = model.Key;
                            tvContact.Text = model.Value;
                        }
                        else
                        {
                            layNormalWelcomeMessage.Visibility = ViewStates.Visible;
                        }

                        try { _processProgress.Dismiss(); }
                        catch { }
                    }
                }
                else
                {
                    layNormalWelcomeMessage.Visibility = ViewStates.Visible;

                    try { _processProgress.Dismiss(); }
                    catch { }
                }
            }
            catch
            {
                layNormalWelcomeMessage.Visibility = ViewStates.Visible;

                try { _processProgress.Dismiss(); }
                catch { }
            }
        }

        void welcomeSpeechWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetWelcomeSpeechCode", null);
        }

        void welcomeSpeechWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                strWelcomeSpeechCode = JsonConvert.DeserializeObject<string>(strResult);
            }
            catch { }

            if (!string.IsNullOrEmpty(strWelcomeSpeechCode))
            {
                YouTubePlayerFragment mYoutubePlayerFragment = new YouTubePlayerFragment();
                mYoutubePlayerFragment.Initialize(CacheManager.DeveloperKey, this);
                FragmentTransaction fragmentTransaction = FragmentManager.BeginTransaction();
                fragmentTransaction.Replace(Resource.Id.youtube_fragment, mYoutubePlayerFragment);
                fragmentTransaction.Commit();
            }

            try { _processProgress.Dismiss(); }
            catch { }
        }

        public void OnInitializationFailure(IYouTubePlayerProvider provider, YouTubeInitializationResult errorReason)
        {
            if (errorReason.IsUserRecoverableError)
            {
                errorReason.GetErrorDialog(this.Activity, 1).Show();
            }
            else
            {
                String errorMessage = String.Format(
                        GetString(Resource.String.ErrorMessage), errorReason.ToString());
                Toast.MakeText(this.Activity, errorMessage, ToastLength.Long).Show();
            }
        }

        public void OnInitializationSuccess(IYouTubePlayerProvider p0, IYouTubePlayer yPlayer, bool p2)
        {
            if (yPlayer != null)
                yPlayer.CueVideo(strWelcomeSpeechCode);
        }
    }
}