using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using System.ComponentModel;
using MyAverisClient;
using Newtonsoft.Json;
using MyAverisCommon;

namespace MyAa.Droid
{
    [Activity(Label = "ApplicationStatusFragment")]
    public class ApplicationStatusFragment : Fragment
    {
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public override void OnResume()
        {
            base.OnResume();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.ApplicationStatusFragment, container, false);

            if(view != null)
            {
                TextView tvAppStatus = view.FindViewById<TextView>(Resource.Id.tvApplicationStatus);
                if (CacheManager.JobInfo != null && !string.IsNullOrEmpty(CacheManager.JobInfo.ApplicationStatus))
                {
                    if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.New)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.NewApplication);
                    else if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Submitted)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.Processing);
                    else if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Interview1)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.Interview1);
                    else if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Interview2)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.Interview2);
                    else if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.FinalInterview)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.FinalRound);
                    else if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Rejected)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.Rejected);
                    else if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.RejectedOffer)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.RejectedOffer);
                    else if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.MedicalCheckUp)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.MedicalCheckUp);
                    else if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.KIV)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.KeepInView);
                    else if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.FailedMedical)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.FailedMCU);
                    else if (CacheManager.JobInfo.ApplicationStatus == InitialData.NewApplicationStatus.Accepted)
                        tvAppStatus.Text = this.Resources.GetString(Resource.String.Hired);
                    else
                        tvAppStatus.Text = string.Empty;
                }
                else
                    tvAppStatus.Text = this.Resources.GetString(Resource.String.NewApplication);
            }

            return view;
        }
    }
}