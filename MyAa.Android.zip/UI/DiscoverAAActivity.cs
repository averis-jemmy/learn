using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Content.PM;
using Android.Support.V7.App;
using Android.Support.Design.Widget;
using Android.Views.InputMethods;
using Android.Content.Res;
using Java.Util;
using MyAverisCommon;

namespace MyAa.Droid
{
    [Activity(Label = "MYAA", Theme = "@style/MyTheme.Base", Icon = "@drawable/icon", WindowSoftInputMode = SoftInput.StateHidden, ScreenOrientation = ScreenOrientation.Portrait, ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class DiscoverAAActivity : AppCompatActivity
    {
        private int LOGIN = 0;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            CacheManager.InitLanguage(this);

            //Window.RequestFeature(WindowFeatures.NoTitle);
            Window.SetFlags(WindowManagerFlags.Fullscreen, WindowManagerFlags.Fullscreen);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.DiscoverAA);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Empty);
            SupportActionBar.SetIcon(Resource.Drawable.Icon);
            SupportActionBar.SetDisplayHomeAsUpEnabled(false);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            toolbar.FindViewById<TextView>(Resource.Id.lblLogin).Visibility = ViewStates.Visible;
            toolbar.FindViewById<TextView>(Resource.Id.lblLogin).Click += LoginButton_OnClick;

            FindViewById<Spinner>(Resource.Id.spinAppLanguage).Adapter = new SpinnerData(this, CommonData.AppLanguages);
            FindViewById<Spinner>(Resource.Id.spinAppLanguage).SetSelection(CommonData.AppLanguages.IndexOf(CacheManager.AppLanguage));
            FindViewById<Spinner>(Resource.Id.spinAppLanguage).ItemSelected += AppLanguage_ItemSelected;
        }

        void AppLanguage_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            if (FindViewById<Spinner>(Resource.Id.spinAppLanguage).SelectedItem.ToString() != CacheManager.AppLanguage)
            {
                if (FindViewById<Spinner>(Resource.Id.spinAppLanguage).SelectedItem.ToString() == "English")
                {
                    Database.UpdateSettings("English");
                    CacheManager.AppLanguage = Database.GetAppLanguage();
                }
                else
                {
                    Database.UpdateSettings("Bahasa Indonesia");
                    CacheManager.AppLanguage = Database.GetAppLanguage();
                }
                Recreate();
            }
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        protected override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        protected override void OnResume()
        {
            base.OnResume();

            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }
        }

        void LoginButton_OnClick(object sender, EventArgs e)
        {
            var intent = new Intent(this, typeof(LoginActivity));
            StartActivityForResult(intent, LOGIN);
        }

        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);

            if (requestCode == LOGIN)
            {
                if (resultCode == Result.Ok)
                {
                    //var main = new Intent(this, typeof(MainActivity));
                    //StartActivity(main);
                    //FinishAffinity();
                }
            }
        }
    }
}