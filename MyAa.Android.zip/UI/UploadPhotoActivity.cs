using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using System.ComponentModel;
using MyAverisClient;
using MyAverisEntity;
using Android.Provider;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;

namespace MyAa.Droid
{
    [Activity(Label = "UploadPhotoActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class UploadPhotoActivity : AppCompatActivity
    {
        Java.IO.File imageFile, imageDir;
        ProgressDialog _processProgress;
        string strResult;
        byte[] bitmapData = null;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.UploadPhoto);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Photo);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            FindViewById<Button>(Resource.Id.btnUploadPhoto).Click += UploadPhoto_OnClick;

            _processProgress = new ProgressDialog(this);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);
        }

        void UploadPhoto_OnClick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etCategory).Text))
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.InputCategory));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return;
            }

            SelectImage();
        }

        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);

            try
            {
                if (resultCode == Result.Ok)
                {
                    _processProgress.Show();
                    Android.Net.Uri contentUri = null;
                    int height = Resources.DisplayMetrics.HeightPixels;
                    int width = Resources.DisplayMetrics.WidthPixels;
                    if (requestCode == 1)
                    {
                        contentUri = Android.Net.Uri.FromFile(imageFile);

                        Bitmap bmp = NGetBitmap(contentUri);
                        ExifInterface ei = new ExifInterface(contentUri.Path);
                        string orientation = ei.GetAttribute(ExifInterface.TagOrientation);

                        switch (orientation)
                        {
                            case "6":
                                bmp = RotateImage(bmp, 90);
                                break;
                            case "3":
                                bmp = RotateImage(bmp, 180);
                                break;
                            case "8":
                                bmp = RotateImage(bmp, 270);
                                break;
                            case "1":
                            default:
                                break;
                        }

                        bitmapData = null;
                        using (var stream = new MemoryStream())
                        {
                            bmp.Compress(Bitmap.CompressFormat.Jpeg, 50, stream);
                            bitmapData = stream.ToArray();
                        }

                        GC.Collect();
                    }
                    if (requestCode == 2)
                    {
                        contentUri = data.Data;

                        Bitmap bmp = NGetBitmap(contentUri);

                        ExifInterface ei = new ExifInterface(GetRealPathFromURI(contentUri));
                        string orientation = ei.GetAttribute(ExifInterface.TagOrientation);

                        switch (orientation)
                        {
                            case "6":
                                bmp = RotateImage(bmp, 90);
                                break;
                            case "3":
                                bmp = RotateImage(bmp, 180);
                                break;
                            case "8":
                                bmp = RotateImage(bmp, 270);
                                break;
                            case "1":
                            default:
                                break;
                        }

                        bitmapData = null;
                        using (var stream = new MemoryStream())
                        {
                            bmp.Compress(Bitmap.CompressFormat.Jpeg, 50, stream);
                            bitmapData = stream.ToArray();
                        }

                        GC.Collect();
                    }

                    if (bitmapData != null)
                    {
                        _processProgress.Show();

                        BackgroundWorker worker = new BackgroundWorker();
                        worker.DoWork += worker_DoWork;
                        worker.RunWorkerCompleted += worker_RunWorkerCompleted;
                        worker.RunWorkerAsync();
                    }
                    else
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.FailUpload));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                        try { _processProgress.Dismiss(); }
                        catch { }
                    }
                }
            }
            catch
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.FailUpload));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                try { _processProgress.Dismiss(); }
                catch { }
            }
        }

        public String GetRealPathFromURI(Android.Net.Uri contentUri)
        {
            string doc_id = "";
            using (var c1 = ContentResolver.Query(contentUri, null, null, null, null))
            {
                c1.MoveToFirst();
                String document_id = c1.GetString(0);
                doc_id = document_id.Substring(document_id.LastIndexOf(":") + 1);
            }

            string path = null;

            // The projection contains the columns we want to return in our query.
            string selection = Android.Provider.MediaStore.Images.Media.InterfaceConsts.Id + " =? ";
            using (var cursor = ManagedQuery(Android.Provider.MediaStore.Images.Media.ExternalContentUri, null, selection, new string[] { doc_id }, null))
            {
                if (cursor == null) return path;
                var columnIndex = cursor.GetColumnIndexOrThrow(Android.Provider.MediaStore.Images.Media.InterfaceConsts.Data);
                cursor.MoveToFirst();
                path = cursor.GetString(columnIndex);
            }
            return path;
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        private void SelectImage()
        {
            string[] items = { "Take Photo", "Choose from Library", "Cancel" };
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle("Add Photo!");
            alert.SetItems(items, (senderAlert, args) =>
            {
                if (items[args.Which] == "Take Photo")
                {
                    if (IsThereAnAppToTakePictures())
                    {
                        CreateDirectoryForPictures();
                        Intent intent = new Intent(MediaStore.ActionImageCapture);
                        imageFile = new Java.IO.File(imageDir, String.Format("newImage_{0}.jpg", Guid.NewGuid()));
                        intent.PutExtra(MediaStore.ExtraOutput, Android.Net.Uri.FromFile(imageFile));
                        StartActivityForResult(intent, 1);
                    }
                }
                else if (items[args.Which] == "Choose from Library")
                {
                    Intent intent = new Intent();
                    intent.SetType("image/*");
                    intent.SetAction(Intent.ActionGetContent);
                    StartActivityForResult(Intent.CreateChooser(intent, "Select File"), 2);
                }
            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        public static Bitmap RotateImage(Bitmap source, float angle)
        {
            Matrix matrix = new Matrix();
            matrix.PostRotate(angle);
            return Bitmap.CreateBitmap(source, 0, 0, source.Width, source.Height, matrix, true);
        }

        private Bitmap NGetBitmap(Android.Net.Uri uriImage)
        {
            Android.Graphics.Bitmap mBitmap = null;
            mBitmap = Android.Provider.MediaStore.Images.Media.GetBitmap(this.ContentResolver, uriImage);
            mBitmap = ResizeBitmap(mBitmap, 1500, 1500);
            return mBitmap;
        }

        private Bitmap ResizeBitmap(Bitmap image, int maxWidth, int maxHeight)
        {
            if (maxHeight > 0 && maxWidth > 0)
            {
                int width = image.Width;
                int height = image.Height;
                float ratioBitmap = (float)width / (float)height;
                float ratioMax = (float)maxWidth / (float)maxHeight;

                int finalWidth = maxWidth;
                int finalHeight = maxHeight;
                if (ratioMax > 1)
                {
                    finalWidth = (int)((float)maxHeight * ratioBitmap);
                }
                else
                {
                    finalHeight = (int)((float)maxWidth / ratioBitmap);
                }
                image = Bitmap.CreateScaledBitmap(image, finalWidth, finalHeight, true);
                return image;
            }
            else
            {
                return image;
            }
        }

        private bool IsThereAnAppToTakePictures()
        {
            Intent intent = new Intent(MediaStore.ActionImageCapture);
            PackageManager pm = this.PackageManager;
            IList<ResolveInfo> availableActivities = pm.QueryIntentActivities(intent, PackageInfoFlags.MatchDefaultOnly);
            return availableActivities != null && availableActivities.Count > 0;
        }

        private void CreateDirectoryForPictures()
        {
            imageDir = new Java.IO.File(Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryPictures),
                "MyAverisImage");
            if (!imageDir.Exists())
            {
                imageDir.Mkdirs();
            }
        }

        /* Checks if external storage is available for read and write */
        public bool IsExternalStorageWritable()
        {
            if (Android.OS.Environment.ExternalStorageState == Android.OS.Environment.MediaMounted)
            {
                return true;
            }
            return false;
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));
            headers.Add(new KeyValuePair<string, string>("Category", FindViewById<EditText>(Resource.Id.etCategory).Text));
            headers.Add(new KeyValuePair<string, string>("FileName", "Image-" + Guid.NewGuid().ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("UploadPhoto", headers, bitmapData);
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            GC.Collect();

            if (!string.IsNullOrEmpty(strResult))
            {
                try { _processProgress.Dismiss(); }
                catch { }

                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.FailUpload));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return;
            }
            else
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.UpdateSuccess));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                    Finish();
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }

            try { _processProgress.Dismiss(); }
            catch { }
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            base.OnBackPressed();
        }
    }
}