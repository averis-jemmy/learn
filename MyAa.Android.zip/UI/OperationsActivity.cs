using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using Android.Animation;
using Android.Graphics;
using System.ComponentModel;
using MyAverisClient;
using Newtonsoft.Json;
using MyAverisEntity;
using Android.Text.Method;
using Android.Text;

namespace MyAa.Droid
{
    [Activity(Label = "OperationsActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class OperationsActivity : AppCompatActivity
    {
        bool plantExpand = false, surroundExpand = false;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.Operations);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.OperationTitle);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            plantExpand = false;
            surroundExpand = false;
            FindViewById<RelativeLayout>(Resource.Id.layPlantations).Click += Plantations_OnClick;
            FindViewById<RelativeLayout>(Resource.Id.laySurroundings).Click += Surroundings_OnClick;

            CacheManager.ProcessProgress.Dismiss();
        }

        private void Plantations_OnClick(object sender, EventArgs e)
        {
            if (plantExpand)
            {
                plantExpand = false;
                FindViewById<ImageView>(Resource.Id.imgPlantations).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layPlantationsDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layPlantationsDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layPlantationsDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                plantExpand = true;
                FindViewById<ImageView>(Resource.Id.imgPlantations).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layPlantationsDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layPlantationsDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layPlantationsDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layPlantationsDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layPlantationsDes), 0, height);
                mAnimator.Start();
            }
        }

        private void Surroundings_OnClick(object sender, EventArgs e)
        {
            if (surroundExpand)
            {
                surroundExpand = false;
                FindViewById<ImageView>(Resource.Id.imgSurroundings).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.laySurroundingsDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.laySurroundingsDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.laySurroundingsDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                surroundExpand = true;
                FindViewById<ImageView>(Resource.Id.imgSurroundings).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.laySurroundingsDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.laySurroundingsDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.laySurroundingsDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.laySurroundingsDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.laySurroundingsDes), 0, height);
                mAnimator.Start();
            }
        }

        private ValueAnimator SlideAnimator(LinearLayout mLinearLayout, int start, int end)
        {
            ValueAnimator animator = ValueAnimator.OfInt(start, end);
            animator.Update +=
                (object sender, ValueAnimator.AnimatorUpdateEventArgs e) =>
                {
                    var value = (int)animator.AnimatedValue;
                    ViewGroup.LayoutParams layoutParams = mLinearLayout.LayoutParameters;
                    layoutParams.Height = value;
                    mLinearLayout.LayoutParameters = layoutParams;
                };
            return animator;
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        protected override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }
    }
}