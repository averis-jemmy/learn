using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using Android.Animation;
using Android.Graphics;
using System.ComponentModel;
using MyAverisClient;
using Newtonsoft.Json;
using MyAverisEntity;
using Android.Text.Method;
using Android.Text;

namespace MyAa.Droid
{
    [Activity(Label = "DressCodeActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class DressCodeActivity : AppCompatActivity
    {
        bool officeExpand = false, fieldExpand = false;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.DressCode);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.DressCodeTitle);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            officeExpand = false;
            fieldExpand = false;
            FindViewById<RelativeLayout>(Resource.Id.layDressCodeOffice).Click += DressCodeOffice_OnClick;
            FindViewById<RelativeLayout>(Resource.Id.layDressCodeField).Click += DressCodeField_OnClick;

            CacheManager.ProcessProgress.Dismiss();
        }

        private void DressCodeOffice_OnClick(object sender, EventArgs e)
        {
            if (officeExpand)
            {
                officeExpand = false;
                FindViewById<ImageView>(Resource.Id.imgDressCodeOffice).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layDressCodeOfficeDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layDressCodeOfficeDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layDressCodeOfficeDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                officeExpand = true;
                FindViewById<ImageView>(Resource.Id.imgDressCodeOffice).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layDressCodeOfficeDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layDressCodeOfficeDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layDressCodeOfficeDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layDressCodeOfficeDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layDressCodeOfficeDes), 0, height);
                mAnimator.Start();
            }
        }

        private void DressCodeField_OnClick(object sender, EventArgs e)
        {
            if (fieldExpand)
            {
                fieldExpand = false;
                FindViewById<ImageView>(Resource.Id.imgDressCodeField).SetImageResource(Resource.Drawable.ic_expand);

                //collapse
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layDressCodeFieldDes).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layDressCodeFieldDes), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layDressCodeFieldDes).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                fieldExpand = true;
                FindViewById<ImageView>(Resource.Id.imgDressCodeField).SetImageResource(Resource.Drawable.ic_collapse);

                //expand
                FindViewById<LinearLayout>(Resource.Id.layDressCodeFieldDes).Visibility = ViewStates.Visible;
                int parentWidth = ((View)FindViewById<LinearLayout>(Resource.Id.layDressCodeFieldDes).Parent).MeasuredWidth;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(parentWidth, MeasureSpecMode.AtMost);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layDressCodeFieldDes).Measure(widthSpec, heightSpec);
                int height = FindViewById<LinearLayout>(Resource.Id.layDressCodeFieldDes).MeasuredHeight;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layDressCodeFieldDes), 0, height);
                mAnimator.Start();
            }
        }

        private ValueAnimator SlideAnimator(LinearLayout mLinearLayout, int start, int end)
        {
            ValueAnimator animator = ValueAnimator.OfInt(start, end);
            animator.Update +=
                (object sender, ValueAnimator.AnimatorUpdateEventArgs e) =>
                {
                    var value = (int)animator.AnimatedValue;
                    ViewGroup.LayoutParams layoutParams = mLinearLayout.LayoutParameters;
                    layoutParams.Height = value;
                    mLinearLayout.LayoutParameters = layoutParams;
                };
            return animator;
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        protected override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }
    }
}