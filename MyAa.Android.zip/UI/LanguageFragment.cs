using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using System.ComponentModel;
using MyAverisClient;
using Newtonsoft.Json;
using MyAverisCommon;

namespace MyAa.Droid
{
    [Activity(Label = "LanguageFragment")]
    public class LanguageFragment : Fragment
    {
        ListView listView;
        ArrayAdapter<String> adapter;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public override void OnResume()
        {
            base.OnResume();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.LanguageFragment, container, false);

            listView = view.FindViewById<ListView>(Resource.Id.listLanguage);
            adapter = new ArrayAdapter<String>(this.Activity, Android.Resource.Layout.SimpleListItemSingleChoice, CommonData.AppLanguages.ToArray());
            listView.Adapter = adapter;
            listView.ChoiceMode = Android.Widget.ChoiceMode.Single;
            listView.SetItemChecked(CommonData.AppLanguages.IndexOf(CacheManager.AppLanguage), true);
            listView.ItemClick += OnListItemClick;

            return view;
        }

        void OnListItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            string lang = adapter.GetItem(e.Position);
            if (!string.IsNullOrEmpty(lang))
            {
                if (Database.GetAppLanguage() != lang)
                {
                    Database.UpdateSettings(lang);
                    CacheManager.AppLanguage = Database.GetAppLanguage();

                    var intent = new Intent(this.Activity, typeof(MainActivity));
                    StartActivity(intent);
                    this.Activity.FinishAffinity();
                }
            }
        }
    }
}