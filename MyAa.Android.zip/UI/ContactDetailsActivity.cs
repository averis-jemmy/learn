using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Android.Animation;
using MyAverisEntity;
using MyAverisCommon;

namespace MyAa.Droid
{
    [Activity(Label = "ContactDetailsActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class ContactDetailsActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.ContactDetails);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.ContactDetails);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            FindViewById<CheckBox>(Resource.Id.chkHomeAddress).Click += HomeAddress_OnClick;
            FindViewById<CheckBox>(Resource.Id.chkEmergencyAddress).Click += EmergencyAddress_OnClick;

            FindViewById<Spinner>(Resource.Id.spinCurrentCountry).Adapter = new SpinnerData(this, CommonData.GetCountries());
            FindViewById<Spinner>(Resource.Id.spinHomeCountry).Adapter = new SpinnerData(this, CommonData.GetCountries());
            FindViewById<Spinner>(Resource.Id.spinEmergencyCountry).Adapter = new SpinnerData(this, CommonData.GetCountries());

            if (CacheManager.JobInfo != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        void HomeAddress_OnClick(object sender, EventArgs e)
        {
            if (!FindViewById<CheckBox>(Resource.Id.chkHomeAddress).Checked)
            {
                //expand
                FindViewById<LinearLayout>(Resource.Id.layHomeAddressDetail).Visibility = ViewStates.Visible;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layHomeAddressDetail).Measure(widthSpec, heightSpec);

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layHomeAddressDetail), 0, FindViewById<LinearLayout>(Resource.Id.layHomeAddressDetail).MeasuredHeight);
                mAnimator.Start();
            }
            else
            {
                FindViewById<EditText>(Resource.Id.etHomeAddress).Text = string.Empty;
                FindViewById<EditText>(Resource.Id.etHomePostCode).Text = string.Empty;
                FindViewById<Spinner>(Resource.Id.spinHomeCountry).SetSelection(0);
                FindViewById<EditText>(Resource.Id.etHomeTelephoneNumber).Text = string.Empty;
                FindViewById<EditText>(Resource.Id.etHomeMobileNumber).Text = string.Empty;
                //collapse;
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layHomeAddressDetail).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layHomeAddressDetail), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layHomeAddressDetail).Visibility = ViewStates.Gone;
                };
            }
        }

        void EmergencyAddress_OnClick(object sender, EventArgs e)
        {
            if (!FindViewById<CheckBox>(Resource.Id.chkEmergencyAddress).Checked)
            {
                //expand
                FindViewById<LinearLayout>(Resource.Id.layEmergencyAddressDetail).Visibility = ViewStates.Visible;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layEmergencyAddressDetail).Measure(widthSpec, heightSpec);

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layEmergencyAddressDetail), 0, FindViewById<LinearLayout>(Resource.Id.layEmergencyAddressDetail).MeasuredHeight);
                mAnimator.Start();
            }
            else
            {
                FindViewById<EditText>(Resource.Id.etEmergencyAddress).Text = string.Empty;
                FindViewById<EditText>(Resource.Id.etEmergencyPostCode).Text = string.Empty;
                FindViewById<Spinner>(Resource.Id.spinEmergencyCountry).SetSelection(0);
                FindViewById<EditText>(Resource.Id.etEmergencyTelephoneNumber).Text = string.Empty;
                //collapse;
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layEmergencyAddressDetail).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layEmergencyAddressDetail), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layEmergencyAddressDetail).Visibility = ViewStates.Gone;
                };
            }
        }

        private ValueAnimator SlideAnimator(LinearLayout mLinearLayout, int start, int end)
        {
            ValueAnimator animator = ValueAnimator.OfInt(start, end);
            animator.Update +=
                (object sender, ValueAnimator.AnimatorUpdateEventArgs e) =>
                {
                    var value = (int)animator.AnimatedValue;
                    ViewGroup.LayoutParams layoutParams = mLinearLayout.LayoutParameters;
                    layoutParams.Height = value;
                    mLinearLayout.LayoutParameters = layoutParams;
                };
            return animator;
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            FindViewById<EditText>(Resource.Id.etEmailAddress).Text = CacheManager.JobInfo.EmailAddress;

            if (CacheManager.JobInfo.CurrentAddress != null)
            {
                FindViewById<EditText>(Resource.Id.etCurrentAddress).Text = CacheManager.JobInfo.CurrentAddress.Address;
                FindViewById<EditText>(Resource.Id.etCurrentPostCode).Text = CacheManager.JobInfo.CurrentAddress.PostalCode;
                FindViewById<Spinner>(Resource.Id.spinCurrentCountry).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.JobInfo.CurrentAddress.Country));
                FindViewById<EditText>(Resource.Id.etCurrentTelephoneNumber).Text = CacheManager.JobInfo.CurrentAddress.HomeNumber;
                FindViewById<EditText>(Resource.Id.etCurrentMobileNumber).Text = CacheManager.JobInfo.CurrentAddress.MobileNumber;
            }
            if (CacheManager.JobInfo.HomeAddress != null)
            {
                FindViewById<CheckBox>(Resource.Id.chkHomeAddress).PerformClick();
                FindViewById<EditText>(Resource.Id.etHomeAddress).Text = CacheManager.JobInfo.HomeAddress.Address;
                FindViewById<EditText>(Resource.Id.etHomePostCode).Text = CacheManager.JobInfo.HomeAddress.PostalCode;
                FindViewById<Spinner>(Resource.Id.spinHomeCountry).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.JobInfo.HomeAddress.Country));
                FindViewById<EditText>(Resource.Id.etHomeTelephoneNumber).Text = CacheManager.JobInfo.HomeAddress.HomeNumber;
                FindViewById<EditText>(Resource.Id.etHomeMobileNumber).Text = CacheManager.JobInfo.HomeAddress.MobileNumber;
            }
            if (CacheManager.JobInfo.EmergencyAddress != null)
            {
                if (!string.IsNullOrEmpty(CacheManager.JobInfo.EmergencyAddress.Address))
                {
                    FindViewById<CheckBox>(Resource.Id.chkEmergencyAddress).PerformClick();
                    FindViewById<EditText>(Resource.Id.etEmergencyAddress).Text = CacheManager.JobInfo.EmergencyAddress.Address;
                    FindViewById<EditText>(Resource.Id.etEmergencyPostCode).Text = CacheManager.JobInfo.EmergencyAddress.PostalCode;
                    FindViewById<Spinner>(Resource.Id.spinEmergencyCountry).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.JobInfo.EmergencyAddress.Country));
                    FindViewById<EditText>(Resource.Id.etEmergencyTelephoneNumber).Text = CacheManager.JobInfo.EmergencyAddress.HomeNumber;
                }
                FindViewById<EditText>(Resource.Id.etEmergencyMobileNumber).Text = CacheManager.JobInfo.EmergencyAddress.MobileNumber;
            }

            FindViewById<EditText>(Resource.Id.etEmergencyContact).Text = CacheManager.JobInfo.EmergencyContact;
        }

        private void LockData()
        {
            FindViewById<EditText>(Resource.Id.etEmailAddress).Enabled = false;
            FindViewById<EditText>(Resource.Id.etCurrentAddress).Enabled = false;
            FindViewById<EditText>(Resource.Id.etCurrentPostCode).Enabled = false;
            FindViewById<Spinner>(Resource.Id.spinCurrentCountry).Enabled = false;
            FindViewById<EditText>(Resource.Id.etCurrentTelephoneNumber).Enabled = false;
            FindViewById<EditText>(Resource.Id.etCurrentMobileNumber).Enabled = false;
            FindViewById<EditText>(Resource.Id.etHomeAddress).Enabled = false;
            FindViewById<EditText>(Resource.Id.etHomePostCode).Enabled = false;
            FindViewById<Spinner>(Resource.Id.spinHomeCountry).Enabled = false;
            FindViewById<EditText>(Resource.Id.etHomeTelephoneNumber).Enabled = false;
            FindViewById<EditText>(Resource.Id.etHomeMobileNumber).Enabled = false;
            FindViewById<EditText>(Resource.Id.etEmergencyAddress).Enabled = false;
            FindViewById<EditText>(Resource.Id.etEmergencyPostCode).Enabled = false;
            FindViewById<Spinner>(Resource.Id.spinEmergencyCountry).Enabled = false;
            FindViewById<EditText>(Resource.Id.etEmergencyTelephoneNumber).Enabled = false;
            FindViewById<EditText>(Resource.Id.etEmergencyMobileNumber).Enabled = false;
            FindViewById<CheckBox>(Resource.Id.chkHomeAddress).Enabled = false;
            FindViewById<CheckBox>(Resource.Id.chkEmergencyAddress).Enabled = false;
            FindViewById<EditText>(Resource.Id.etEmergencyAddress).Enabled = false;
            FindViewById<EditText>(Resource.Id.etEmergencyContact).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                CacheManager.JobInfo.EmailAddress = FindViewById<EditText>(Resource.Id.etEmailAddress).Text;
                CacheManager.JobInfo.CurrentAddress = new JobApplicationAddressInfo();
                CacheManager.JobInfo.CurrentAddress.Address = FindViewById<EditText>(Resource.Id.etCurrentAddress).Text;
                CacheManager.JobInfo.CurrentAddress.PostalCode = FindViewById<EditText>(Resource.Id.etCurrentPostCode).Text;
                CacheManager.JobInfo.CurrentAddress.Country = FindViewById<Spinner>(Resource.Id.spinCurrentCountry).SelectedItem.ToString();
                CacheManager.JobInfo.CurrentAddress.HomeNumber = FindViewById<EditText>(Resource.Id.etCurrentTelephoneNumber).Text;
                CacheManager.JobInfo.CurrentAddress.MobileNumber = FindViewById<EditText>(Resource.Id.etCurrentMobileNumber).Text;

                CacheManager.JobInfo.EmergencyContact = FindViewById<EditText>(Resource.Id.etEmergencyContact).Text;

                JobApplicationAddress current = new JobApplicationAddress()
                {
                    AddressType = InitialData.AddressType.CurrentAddress,
                    Address = CacheManager.JobInfo.CurrentAddress.Address,
                    PostalCode = CacheManager.JobInfo.CurrentAddress.PostalCode,
                    Country = CacheManager.JobInfo.CurrentAddress.Country,
                    HomeNumber = CacheManager.JobInfo.CurrentAddress.HomeNumber,
                    MobileNumber = CacheManager.JobInfo.CurrentAddress.MobileNumber
                };

                Database.UpdateAddress(current);

                JobApplication app = Database.GetJobApplication();
                app.EmailAddress = CacheManager.JobInfo.EmailAddress;
                app.EmergencyContact = CacheManager.JobInfo.EmergencyContact;

                Database.UpdateJobApplication(app);

                if (!FindViewById<CheckBox>(Resource.Id.chkHomeAddress).Checked)
                {
                    CacheManager.JobInfo.HomeAddress = new JobApplicationAddressInfo();
                    CacheManager.JobInfo.HomeAddress.Address = FindViewById<EditText>(Resource.Id.etHomeAddress).Text;
                    CacheManager.JobInfo.HomeAddress.PostalCode = FindViewById<EditText>(Resource.Id.etHomePostCode).Text;
                    CacheManager.JobInfo.HomeAddress.Country = FindViewById<Spinner>(Resource.Id.spinHomeCountry).SelectedItem.ToString();
                    CacheManager.JobInfo.HomeAddress.HomeNumber = FindViewById<EditText>(Resource.Id.etHomeTelephoneNumber).Text;
                    CacheManager.JobInfo.HomeAddress.MobileNumber = FindViewById<EditText>(Resource.Id.etHomeMobileNumber).Text;

                    JobApplicationAddress home = new JobApplicationAddress()
                    {
                        AddressType = InitialData.AddressType.HomeAddress,
                        Address = CacheManager.JobInfo.HomeAddress.Address,
                        PostalCode = CacheManager.JobInfo.HomeAddress.PostalCode,
                        Country = CacheManager.JobInfo.HomeAddress.Country,
                        HomeNumber = CacheManager.JobInfo.HomeAddress.HomeNumber,
                        MobileNumber = CacheManager.JobInfo.HomeAddress.MobileNumber
                    };

                    Database.UpdateAddress(home);
                }
                else
                {
                    CacheManager.JobInfo.HomeAddress = null;
                    Database.DeleteAddress(InitialData.AddressType.HomeAddress);
                }

                CacheManager.JobInfo.EmergencyAddress = new JobApplicationAddressInfo();
                if (!FindViewById<CheckBox>(Resource.Id.chkEmergencyAddress).Checked)
                {
                    CacheManager.JobInfo.EmergencyAddress.Address = FindViewById<EditText>(Resource.Id.etEmergencyAddress).Text;
                    CacheManager.JobInfo.EmergencyAddress.PostalCode = FindViewById<EditText>(Resource.Id.etEmergencyPostCode).Text;
                    CacheManager.JobInfo.EmergencyAddress.Country = FindViewById<Spinner>(Resource.Id.spinEmergencyCountry).SelectedItem.ToString();
                    CacheManager.JobInfo.EmergencyAddress.HomeNumber = FindViewById<EditText>(Resource.Id.etEmergencyTelephoneNumber).Text;
                }
                else
                {
                    CacheManager.JobInfo.EmergencyAddress.Address = string.Empty;
                    CacheManager.JobInfo.EmergencyAddress.PostalCode = string.Empty;
                    CacheManager.JobInfo.EmergencyAddress.Country = string.Empty;
                    CacheManager.JobInfo.EmergencyAddress.HomeNumber = string.Empty;
                }

                CacheManager.JobInfo.EmergencyAddress.MobileNumber = FindViewById<EditText>(Resource.Id.etEmergencyMobileNumber).Text;

                JobApplicationAddress emergency = new JobApplicationAddress()
                {
                    AddressType = InitialData.AddressType.EmergencyAddress,
                    Address = CacheManager.JobInfo.EmergencyAddress.Address,
                    PostalCode = CacheManager.JobInfo.EmergencyAddress.PostalCode,
                    Country = CacheManager.JobInfo.EmergencyAddress.Country,
                    HomeNumber = CacheManager.JobInfo.EmergencyAddress.HomeNumber,
                    MobileNumber = CacheManager.JobInfo.EmergencyAddress.MobileNumber
                };

                Database.UpdateAddress(emergency);
            }

            Finish();
        }

        private bool ValidateData()
        {
            return true;
        }
    }
}