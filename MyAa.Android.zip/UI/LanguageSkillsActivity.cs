using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using MyAverisEntity;
using MyAverisCommon;

namespace MyAa.Droid
{
    [Activity(Label = "LanguageSkillsActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class LanguageSkillsActivity : AppCompatActivity
    {
        bool readAverage = false, readGood = false, readExcellent = false;
        bool writeAverage = false, writeGood = false, writeExcellent = false;
        bool speakAverage = false, speakGood = false, speakExcellent = false;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.LanguageSkills);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.LanguageSkills);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            if (CacheManager.LanguageInfo != null && !CacheManager.IsLocked)
            {
                FindViewById<Button>(Resource.Id.btnDelete).Visibility = ViewStates.Visible;
                FindViewById<Button>(Resource.Id.btnDelete).Click += Delete_OnClick;
            }
            else
                FindViewById<Button>(Resource.Id.btnDelete).Visibility = ViewStates.Gone;

            FindViewById<Spinner>(Resource.Id.spinLanguage).Adapter = new SpinnerData(this, CommonData.Languages);
            FindViewById<Spinner>(Resource.Id.spinLanguage).ItemSelected += Language_ItemSelected;

            #region RadioButton
            FindViewById<RadioButton>(Resource.Id.rbReadAverage).Click += (sender, e) =>
            {
                if (readAverage)
                {
                    readAverage = false;
                    FindViewById<RadioGroup>(Resource.Id.rgRead).ClearCheck();
                }
                else
                {
                    readAverage = true;
                    readGood = false;
                    readExcellent = false;
                }
            };

            FindViewById<RadioButton>(Resource.Id.rbReadGood).Click += (sender, e) =>
            {
                if (readGood)
                {
                    readGood = false;
                    FindViewById<RadioGroup>(Resource.Id.rgRead).ClearCheck();
                }
                else
                {
                    readAverage = false;
                    readGood = true;
                    readExcellent = false;
                }
            };

            FindViewById<RadioButton>(Resource.Id.rbReadExcellent).Click += (sender, e) =>
            {
                if (readExcellent)
                {
                    readExcellent = false;
                    FindViewById<RadioGroup>(Resource.Id.rgRead).ClearCheck();
                }
                else
                {
                    readAverage = false;
                    readGood = false;
                    readExcellent = true;
                }
            };

            FindViewById<RadioButton>(Resource.Id.rbWriteAverage).Click += (sender, e) =>
            {
                if (writeAverage)
                {
                    writeAverage = false;
                    FindViewById<RadioGroup>(Resource.Id.rgWrite).ClearCheck();
                }
                else
                {
                    writeAverage = true;
                    writeGood = false;
                    writeExcellent = false;
                }
            };

            FindViewById<RadioButton>(Resource.Id.rbWriteGood).Click += (sender, e) =>
            {
                if (writeGood)
                {
                    writeGood = false;
                    FindViewById<RadioGroup>(Resource.Id.rgWrite).ClearCheck();
                }
                else
                {
                    writeAverage = false;
                    writeGood = true;
                    writeExcellent = false;
                }
            };

            FindViewById<RadioButton>(Resource.Id.rbWriteExcellent).Click += (sender, e) =>
            {
                if (writeExcellent)
                {
                    writeExcellent = false;
                    FindViewById<RadioGroup>(Resource.Id.rgWrite).ClearCheck();
                }
                else
                {
                    writeAverage = false;
                    writeGood = false;
                    writeExcellent = true;
                }
            };

            FindViewById<RadioButton>(Resource.Id.rbSpeakAverage).Click += (sender, e) =>
            {
                if (speakAverage)
                {
                    speakAverage = false;
                    FindViewById<RadioGroup>(Resource.Id.rgSpeak).ClearCheck();
                }
                else
                {
                    speakAverage = true;
                    speakGood = false;
                    speakExcellent = false;
                }
            };

            FindViewById<RadioButton>(Resource.Id.rbSpeakGood).Click += (sender, e) =>
            {
                if (speakGood)
                {
                    speakGood = false;
                    FindViewById<RadioGroup>(Resource.Id.rgSpeak).ClearCheck();
                }
                else
                {
                    speakAverage = false;
                    speakGood = true;
                    speakExcellent = false;
                }
            };

            FindViewById<RadioButton>(Resource.Id.rbSpeakExcellent).Click += (sender, e) =>
            {
                if (speakExcellent)
                {
                    speakExcellent = false;
                    FindViewById<RadioGroup>(Resource.Id.rgSpeak).ClearCheck();
                }
                else
                {
                    speakAverage = false;
                    speakGood = false;
                    speakExcellent = true;
                }
            };
            #endregion

            if (CacheManager.LanguageInfo != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        void Language_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            if (FindViewById<Spinner>(Resource.Id.spinLanguage).SelectedItem.ToString() == "Other")
            {
                FindViewById<EditText>(Resource.Id.etLanguage).Visibility = ViewStates.Visible;
            }
            else
            {
                FindViewById<EditText>(Resource.Id.etLanguage).Text = string.Empty;
                FindViewById<EditText>(Resource.Id.etLanguage).Visibility = ViewStates.Gone;
            }
        }

        void Delete_OnClick(object sender, EventArgs e)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle(this.Resources.GetString(Resource.String.Info));
            alert.SetMessage(this.Resources.GetString(Resource.String.DeleteConfirmation));
            alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
            {
                JobApplicationLanguage model = new JobApplicationLanguage()
                {
                    ID = CacheManager.LanguageInfo.UID
                };

                Database.DeleteLanguage(model);

                if (CacheManager.JobInfo.Languages.Count >= CacheManager.LanguagePosition + 1 &&
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition] != null)
                {
                    CacheManager.JobInfo.Languages.RemoveAt(CacheManager.LanguagePosition);
                }

                Finish();
            });
            alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
            {
            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            if (CommonData.Languages.Contains(CacheManager.LanguageInfo.Language))
                FindViewById<Spinner>(Resource.Id.spinLanguage).SetSelection(CommonData.Languages.IndexOf(CacheManager.LanguageInfo.Language));
            else
            {
                FindViewById<Spinner>(Resource.Id.spinLanguage).SetSelection(CommonData.Languages.IndexOf("Other"));
                FindViewById<EditText>(Resource.Id.etLanguage).Text = CacheManager.LanguageInfo.Language;
            }

            if (CacheManager.LanguageInfo.ReadAbility.HasValue)
            {
                if (CacheManager.LanguageInfo.ReadAbility.GetValueOrDefault() == 1)
                {
                    FindViewById<RadioButton>(Resource.Id.rbReadAverage).Checked = true;
                    readAverage = true;
                }
                if (CacheManager.LanguageInfo.ReadAbility.GetValueOrDefault() == 2)
                {
                    FindViewById<RadioButton>(Resource.Id.rbReadGood).Checked = true;
                    readGood = true;
                }
                if (CacheManager.LanguageInfo.ReadAbility.GetValueOrDefault() == 3)
                {
                    FindViewById<RadioButton>(Resource.Id.rbReadExcellent).Checked = true;
                    readExcellent = true;
                }
            }

            if (CacheManager.LanguageInfo.WriteAbility.HasValue)
            {
                if (CacheManager.LanguageInfo.WriteAbility.GetValueOrDefault() == 1)
                {
                    FindViewById<RadioButton>(Resource.Id.rbWriteAverage).Checked = true;
                    writeAverage = true;
                }
                if (CacheManager.LanguageInfo.WriteAbility.GetValueOrDefault() == 2)
                {
                    FindViewById<RadioButton>(Resource.Id.rbWriteGood).Checked = true;
                    writeGood = true;
                }
                if (CacheManager.LanguageInfo.WriteAbility.GetValueOrDefault() == 3)
                {
                    FindViewById<RadioButton>(Resource.Id.rbWriteExcellent).Checked = true;
                    writeExcellent = true;
                }
            }

            if (CacheManager.LanguageInfo.SpeakAbility.HasValue)
            {
                if (CacheManager.LanguageInfo.SpeakAbility.GetValueOrDefault() == 1)
                {
                    FindViewById<RadioButton>(Resource.Id.rbSpeakAverage).Checked = true;
                    speakAverage = true;
                }
                if (CacheManager.LanguageInfo.SpeakAbility.GetValueOrDefault() == 2)
                {
                    FindViewById<RadioButton>(Resource.Id.rbSpeakGood).Checked = true;
                    speakGood = true;
                }
                if (CacheManager.LanguageInfo.SpeakAbility.GetValueOrDefault() == 3)
                {
                    FindViewById<RadioButton>(Resource.Id.rbSpeakExcellent).Checked = true;
                    speakExcellent = true;
                }
            }
        }

        private void LockData()
        {
            FindViewById<Spinner>(Resource.Id.spinLanguage).Enabled = false;
            FindViewById<EditText>(Resource.Id.etLanguage).Enabled = false;

            FindViewById<RadioButton>(Resource.Id.rbReadAverage).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbReadGood).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbReadExcellent).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbWriteAverage).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbWriteGood).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbWriteExcellent).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbSpeakAverage).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbSpeakGood).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbSpeakExcellent).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                if (CacheManager.JobInfo.Languages == null)
                    CacheManager.JobInfo.Languages = new List<JobApplicationLanguageInfo>();

                if (CacheManager.LanguageInfo == null)
                {
                    JobApplicationLanguageInfo info = new JobApplicationLanguageInfo();
                    info.UID = Guid.NewGuid();
                    info.Language = FindViewById<Spinner>(Resource.Id.spinLanguage).SelectedItem.ToString();
                    if (FindViewById<Spinner>(Resource.Id.spinLanguage).SelectedItem.ToString() == "Other")
                        info.Language = FindViewById<EditText>(Resource.Id.etLanguage).Text;

                    if (FindViewById<RadioButton>(Resource.Id.rbReadAverage).Checked)
                        info.ReadAbility = 1;
                    if (FindViewById<RadioButton>(Resource.Id.rbReadGood).Checked)
                        info.ReadAbility = 2;
                    if (FindViewById<RadioButton>(Resource.Id.rbReadExcellent).Checked)
                        info.ReadAbility = 3;

                    if (FindViewById<RadioButton>(Resource.Id.rbWriteAverage).Checked)
                        info.WriteAbility = 1;
                    if (FindViewById<RadioButton>(Resource.Id.rbWriteGood).Checked)
                        info.WriteAbility = 2;
                    if (FindViewById<RadioButton>(Resource.Id.rbWriteExcellent).Checked)
                        info.WriteAbility = 3;

                    if (FindViewById<RadioButton>(Resource.Id.rbSpeakAverage).Checked)
                        info.SpeakAbility = 1;
                    if (FindViewById<RadioButton>(Resource.Id.rbSpeakGood).Checked)
                        info.SpeakAbility = 2;
                    if (FindViewById<RadioButton>(Resource.Id.rbSpeakExcellent).Checked)
                        info.SpeakAbility = 3;

                    CacheManager.JobInfo.Languages.Add(info);

                    JobApplicationLanguage model = new JobApplicationLanguage()
                    {
                        ID = info.UID,
                        Language = info.Language,
                        ReadAbility = info.ReadAbility,
                        WriteAbility = info.WriteAbility,
                        SpeakAbility = info.SpeakAbility
                    };

                    Database.UpdateLanguage(model);
                }
                else
                {
                    if (CacheManager.JobInfo.Languages.Count >= CacheManager.LanguagePosition + 1 &&
                        CacheManager.JobInfo.Languages[CacheManager.LanguagePosition] != null)
                    {
                        Guid UID = CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].UID;
                        CacheManager.JobInfo.Languages[CacheManager.LanguagePosition] = new JobApplicationLanguageInfo();
                        CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].UID = UID;

                        CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].Language = FindViewById<Spinner>(Resource.Id.spinLanguage).SelectedItem.ToString();
                        if (FindViewById<Spinner>(Resource.Id.spinLanguage).SelectedItem.ToString() == "Other")
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].Language = FindViewById<EditText>(Resource.Id.etLanguage).Text;

                        if (FindViewById<RadioButton>(Resource.Id.rbReadAverage).Checked)
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].ReadAbility = 1;
                        if (FindViewById<RadioButton>(Resource.Id.rbReadGood).Checked)
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].ReadAbility = 2;
                        if (FindViewById<RadioButton>(Resource.Id.rbReadExcellent).Checked)
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].ReadAbility = 3;

                        if (FindViewById<RadioButton>(Resource.Id.rbWriteAverage).Checked)
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].WriteAbility = 1;
                        if (FindViewById<RadioButton>(Resource.Id.rbWriteGood).Checked)
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].WriteAbility = 2;
                        if (FindViewById<RadioButton>(Resource.Id.rbWriteExcellent).Checked)
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].WriteAbility = 3;

                        if (FindViewById<RadioButton>(Resource.Id.rbSpeakAverage).Checked)
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].SpeakAbility = 1;
                        if (FindViewById<RadioButton>(Resource.Id.rbSpeakGood).Checked)
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].SpeakAbility = 2;
                        if (FindViewById<RadioButton>(Resource.Id.rbSpeakExcellent).Checked)
                            CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].SpeakAbility = 3;

                        JobApplicationLanguage model = new JobApplicationLanguage()
                        {
                            ID = CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].UID,
                            Language = CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].Language,
                            ReadAbility = CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].ReadAbility,
                            WriteAbility = CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].WriteAbility,
                            SpeakAbility = CacheManager.JobInfo.Languages[CacheManager.LanguagePosition].SpeakAbility
                        };

                        Database.UpdateLanguage(model);
                    }
                }
            }

            Finish();
        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(FindViewById<Spinner>(Resource.Id.spinLanguage).SelectedItem.ToString()))
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.LanguageConfirmation));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
                {
                    Finish();
                });
                alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return false;
            }
            else
            {
                if (FindViewById<Spinner>(Resource.Id.spinLanguage).SelectedItem.ToString() == "Other" &&
                    string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etLanguage).Text))
                {
                    Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                    alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                    alert.SetMessage(this.Resources.GetString(Resource.String.LanguageConfirmation));
                    alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
                    {
                        Finish();
                    });
                    alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
                    {
                    });

                    RunOnUiThread(() =>
                    {
                        alert.Show();
                    });
                    return false;
                }
                else
                {
                    string languageName = FindViewById<Spinner>(Resource.Id.spinLanguage).SelectedItem.ToString();
                    if (languageName == "Other")
                        languageName = FindViewById<EditText>(Resource.Id.etLanguage).Text;

                    if (CacheManager.JobInfo.Languages != null)
                    {
                        bool exists = false;
                        foreach (JobApplicationLanguageInfo info in CacheManager.JobInfo.Languages)
                        {
                            if (info.Language == languageName &&
                                (CacheManager.LanguageInfo == null || CacheManager.LanguageInfo.Language != languageName))
                            {
                                exists = true;
                            }
                        }

                        if (exists)
                        {
                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                            alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                            alert.SetMessage(this.Resources.GetString(Resource.String.SameLanguageConfirmation));
                            alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
                            {
                                Finish();
                            });
                            alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
                            {
                            });

                            RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                            return false;
                        }
                    }
                }
            }
            return true;
        }
    }
}