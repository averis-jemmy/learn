using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using MyAverisEntity;
using MyAverisCommon;

namespace MyAa.Droid
{
    [Activity(Label = "ActivitiesActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class ActivitiesActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.Activities);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Activities);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            if (CacheManager.ActivityInfo != null && !CacheManager.IsLocked)
            {
                FindViewById<Button>(Resource.Id.btnDelete).Visibility = ViewStates.Visible;
                FindViewById<Button>(Resource.Id.btnDelete).Click += Delete_OnClick;
            }
            else
                FindViewById<Button>(Resource.Id.btnDelete).Visibility = ViewStates.Gone;

            FindViewById<Spinner>(Resource.Id.spinCountry).Adapter = new SpinnerData(this, CommonData.GetCountries());

            FindViewById<CheckBox>(Resource.Id.chkPresent).CheckedChange += Present_CheckedChange;

            if (!CacheManager.IsLocked)
            {
                FindViewById<TextView>(Resource.Id.etStartDate).Click += StartDate_OnClick;
                FindViewById<TextView>(Resource.Id.etEndDate).Click += EndDate_OnClick;
            }

            if (CacheManager.ActivityInfo != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        void Present_CheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            if (FindViewById<CheckBox>(Resource.Id.chkPresent).Checked)
                FindViewById<TextView>(Resource.Id.etEndDate).Text = string.Empty;
        }

        private void StartDate_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DateTime? endDate = null;
            try
            {
                endDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etStartDate).Text = time.ToString("dd - MMM - yyyy");
            }, selected, DateTime.Now.AddYears(-50), endDate.HasValue ? endDate : DateTime.Now);
            frag.Show(FragmentManager, DatePickerFragment.TAG);
        }

        private void EndDate_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DateTime? startDate = null;
            try
            {
                startDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etEndDate).Text = time.ToString("dd - MMM - yyyy");
            }, selected, startDate.HasValue ? startDate : DateTime.Now.AddYears(-50), DateTime.Now);
            frag.Show(FragmentManager, DatePickerFragment.TAG);

            FindViewById<CheckBox>(Resource.Id.chkPresent).Checked = false;
        }

        void Delete_OnClick(object sender, EventArgs e)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle(this.Resources.GetString(Resource.String.Info));
            alert.SetMessage(this.Resources.GetString(Resource.String.DeleteConfirmation));
            alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
            {
                JobApplicationActivity model = new JobApplicationActivity()
                {
                    ID = CacheManager.ActivityInfo.UID
                };

                Database.DeleteActivity(model);

                if (CacheManager.JobInfo.Activities.Count >= CacheManager.ActivityPosition + 1 &&
                            CacheManager.JobInfo.Activities[CacheManager.ActivityPosition] != null)
                {
                    CacheManager.JobInfo.Activities.RemoveAt(CacheManager.ActivityPosition);
                }

                Finish();
            });
            alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
            {
            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            FindViewById<EditText>(Resource.Id.etName).Text = CacheManager.ActivityInfo.Organisation;
            FindViewById<EditText>(Resource.Id.etNatureOfActivities).Text = CacheManager.ActivityInfo.NatureOfActivities;

            if (CacheManager.ActivityInfo.FromDate.HasValue)
                FindViewById<TextView>(Resource.Id.etStartDate).Text = CacheManager.ActivityInfo.FromDate.Value.ToString("dd - MMM - yyyy");

            if (CacheManager.ActivityInfo.ToDate.HasValue)
            {
                FindViewById<CheckBox>(Resource.Id.chkPresent).Checked = false;
                FindViewById<TextView>(Resource.Id.etEndDate).Text = CacheManager.ActivityInfo.ToDate.Value.ToString("dd - MMM - yyyy");
            }

            FindViewById<Spinner>(Resource.Id.spinCountry).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.ActivityInfo.Country));
        }

        private void LockData()
        {
            FindViewById<CheckBox>(Resource.Id.chkPresent).Enabled = false;
            FindViewById<EditText>(Resource.Id.etName).Enabled = false;
            FindViewById<EditText>(Resource.Id.etNatureOfActivities).Enabled = false;

            FindViewById<Spinner>(Resource.Id.spinCountry).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                if (CacheManager.JobInfo.Activities == null)
                    CacheManager.JobInfo.Activities = new List<JobApplicationActivityInfo>();

                if (CacheManager.ActivityInfo == null)
                {
                    JobApplicationActivityInfo info = new JobApplicationActivityInfo();
                    info.UID = Guid.NewGuid();
                    info.Organisation = FindViewById<EditText>(Resource.Id.etName).Text;
                    info.NatureOfActivities = FindViewById<EditText>(Resource.Id.etNatureOfActivities).Text;

                    try
                    {
                        info.FromDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                        "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        info.FromDate = null;
                    }

                    try
                    {
                        info.ToDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                        "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        info.ToDate = null;
                    }

                    info.Country = FindViewById<Spinner>(Resource.Id.spinCountry).SelectedItem.ToString();

                    CacheManager.JobInfo.Activities.Add(info);

                    JobApplicationActivity model = new JobApplicationActivity()
                    {
                        ID = info.UID,
                        Organisation = info.Organisation,
                        NatureOfActivities = info.NatureOfActivities,
                        Country = info.Country,
                        FromDate = info.FromDate,
                        ToDate = info.ToDate
                    };

                    Database.UpdateActivity(model);
                }
                else
                {
                    if (CacheManager.JobInfo.Activities.Count >= CacheManager.ActivityPosition + 1 &&
                        CacheManager.JobInfo.Activities[CacheManager.ActivityPosition] != null)
                    {
                        Guid UID = CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].UID;
                        CacheManager.JobInfo.Activities[CacheManager.ActivityPosition] = new JobApplicationActivityInfo();
                        CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].UID = UID;

                        CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].Organisation = FindViewById<EditText>(Resource.Id.etName).Text;
                        CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].NatureOfActivities = FindViewById<EditText>(Resource.Id.etNatureOfActivities).Text;

                        try
                        {
                            CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].FromDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                            "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        }
                        catch
                        {
                            CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].FromDate = null;
                        }

                        try
                        {
                            CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].ToDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                            "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        }
                        catch
                        {
                            CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].ToDate = null;
                        }

                        CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].Country = FindViewById<Spinner>(Resource.Id.spinCountry).SelectedItem.ToString();

                        JobApplicationActivity model = new JobApplicationActivity()
                        {
                            ID = CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].UID,
                            Organisation = CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].Organisation,
                            NatureOfActivities = CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].NatureOfActivities,
                            Country = CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].Country,
                            FromDate = CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].FromDate,
                            ToDate = CacheManager.JobInfo.Activities[CacheManager.ActivityPosition].ToDate
                        };

                        Database.UpdateActivity(model);
                    }
                }
            }

            Finish();
        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etName).Text))
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.OrganisationConfirmation));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
                {
                    Finish();
                });
                alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return false;
            }
            return true;
        }
    }
}