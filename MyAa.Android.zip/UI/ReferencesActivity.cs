using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using MyAverisEntity;

namespace MyAa.Droid
{
    [Activity(Label = "ReferencesActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class ReferencesActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.References);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.References);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            if (CacheManager.JobInfo != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            if (CacheManager.JobInfo.References != null && CacheManager.JobInfo.References.Count > 0)
            {
                if (CacheManager.JobInfo.References[0] != null)
                {
                    FindViewById<EditText>(Resource.Id.etName1).Text = CacheManager.JobInfo.References[0].Name;
                    FindViewById<EditText>(Resource.Id.etOccupation1).Text = CacheManager.JobInfo.References[0].Occupation;

                    if (CacheManager.JobInfo.References[0].YearsKnown.HasValue)
                        FindViewById<EditText>(Resource.Id.etYearsKnown1).Text = CacheManager.JobInfo.References[0].YearsKnown.GetValueOrDefault().ToString();
                    FindViewById<EditText>(Resource.Id.etAddress1).Text = CacheManager.JobInfo.References[0].Address;
                    FindViewById<EditText>(Resource.Id.etEmployer1).Text = CacheManager.JobInfo.References[0].Employer;
                    FindViewById<EditText>(Resource.Id.etMobileNumber1).Text = CacheManager.JobInfo.References[0].MobileNumber;
                    FindViewById<EditText>(Resource.Id.etHomeNumber1).Text = CacheManager.JobInfo.References[0].HomeNumber;
                    FindViewById<EditText>(Resource.Id.etOfficeNumber1).Text = CacheManager.JobInfo.References[0].OfficeNumber;
                }

                if (CacheManager.JobInfo.References.Count > 1 && CacheManager.JobInfo.References[1] != null)
                {
                    FindViewById<EditText>(Resource.Id.etName2).Text = CacheManager.JobInfo.References[1].Name;
                    FindViewById<EditText>(Resource.Id.etOccupation2).Text = CacheManager.JobInfo.References[1].Occupation;

                    if (CacheManager.JobInfo.References[1].YearsKnown.HasValue)
                        FindViewById<EditText>(Resource.Id.etYearsKnown2).Text = CacheManager.JobInfo.References[1].YearsKnown.GetValueOrDefault().ToString();
                    FindViewById<EditText>(Resource.Id.etAddress2).Text = CacheManager.JobInfo.References[1].Address;
                    FindViewById<EditText>(Resource.Id.etEmployer2).Text = CacheManager.JobInfo.References[1].Employer;
                    FindViewById<EditText>(Resource.Id.etMobileNumber2).Text = CacheManager.JobInfo.References[1].MobileNumber;
                    FindViewById<EditText>(Resource.Id.etHomeNumber2).Text = CacheManager.JobInfo.References[1].HomeNumber;
                    FindViewById<EditText>(Resource.Id.etOfficeNumber2).Text = CacheManager.JobInfo.References[1].OfficeNumber;
                }
            }
        }

        private void LockData()
        {
            FindViewById<EditText>(Resource.Id.etName1).Enabled = false;
            FindViewById<EditText>(Resource.Id.etOccupation1).Enabled = false;
            FindViewById<EditText>(Resource.Id.etYearsKnown1).Enabled = false;
            FindViewById<EditText>(Resource.Id.etAddress1).Enabled = false;
            FindViewById<EditText>(Resource.Id.etEmployer1).Enabled = false;
            FindViewById<EditText>(Resource.Id.etMobileNumber1).Enabled = false;
            FindViewById<EditText>(Resource.Id.etHomeNumber1).Enabled = false;
            FindViewById<EditText>(Resource.Id.etOfficeNumber1).Enabled = false;

            FindViewById<EditText>(Resource.Id.etName2).Enabled = false;
            FindViewById<EditText>(Resource.Id.etOccupation2).Enabled = false;
            FindViewById<EditText>(Resource.Id.etYearsKnown2).Enabled = false;
            FindViewById<EditText>(Resource.Id.etAddress2).Enabled = false;
            FindViewById<EditText>(Resource.Id.etEmployer2).Enabled = false;
            FindViewById<EditText>(Resource.Id.etMobileNumber2).Enabled = false;
            FindViewById<EditText>(Resource.Id.etHomeNumber2).Enabled = false;
            FindViewById<EditText>(Resource.Id.etOfficeNumber2).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                CacheManager.JobInfo.References = new List<JobApplicationReferenceInfo>();
                Database.DeleteReferences();

                if (!ValidateData())
                    return;

                if (!string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etName1).Text))
                {
                    byte? yearsKnown = null;

                    try
                    {
                        yearsKnown = byte.Parse(FindViewById<EditText>(Resource.Id.etYearsKnown1).Text);
                    }
                    catch { }

                    JobApplicationReferenceInfo info = new JobApplicationReferenceInfo()
                    {
                        Name = FindViewById<EditText>(Resource.Id.etName1).Text,
                        Occupation = FindViewById<EditText>(Resource.Id.etOccupation1).Text,
                        YearsKnown = yearsKnown,
                        Address = FindViewById<EditText>(Resource.Id.etAddress1).Text,
                        Employer = FindViewById<EditText>(Resource.Id.etEmployer1).Text,
                        MobileNumber = FindViewById<EditText>(Resource.Id.etMobileNumber1).Text,
                        HomeNumber = FindViewById<EditText>(Resource.Id.etHomeNumber1).Text,
                        OfficeNumber = FindViewById<EditText>(Resource.Id.etOfficeNumber1).Text
                    };
                    CacheManager.JobInfo.References.Add(info);

                    JobApplicationReference item = new JobApplicationReference()
                    {
                        Name = FindViewById<EditText>(Resource.Id.etName1).Text,
                        Occupation = FindViewById<EditText>(Resource.Id.etOccupation1).Text,
                        YearsKnown = yearsKnown,
                        Address = FindViewById<EditText>(Resource.Id.etAddress1).Text,
                        Employer = FindViewById<EditText>(Resource.Id.etEmployer1).Text,
                        MobileNumber = FindViewById<EditText>(Resource.Id.etMobileNumber1).Text,
                        HomeNumber = FindViewById<EditText>(Resource.Id.etHomeNumber1).Text,
                        OfficeNumber = FindViewById<EditText>(Resource.Id.etOfficeNumber1).Text
                    };
                    Database.UpdateReference(item);
                }

                if (!string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etName2).Text) && FindViewById<EditText>(Resource.Id.etName1).Text != FindViewById<EditText>(Resource.Id.etName2).Text)
                {
                    byte? yearsKnown = null;

                    try
                    {
                        yearsKnown = byte.Parse(FindViewById<EditText>(Resource.Id.etYearsKnown2).Text);
                    }
                    catch { }

                    JobApplicationReferenceInfo info = new JobApplicationReferenceInfo()
                    {
                        Name = FindViewById<EditText>(Resource.Id.etName2).Text,
                        Occupation = FindViewById<EditText>(Resource.Id.etOccupation2).Text,
                        YearsKnown = yearsKnown,
                        Address = FindViewById<EditText>(Resource.Id.etAddress2).Text,
                        Employer = FindViewById<EditText>(Resource.Id.etEmployer2).Text,
                        MobileNumber = FindViewById<EditText>(Resource.Id.etMobileNumber2).Text,
                        HomeNumber = FindViewById<EditText>(Resource.Id.etHomeNumber2).Text,
                        OfficeNumber = FindViewById<EditText>(Resource.Id.etOfficeNumber2).Text
                    };
                    CacheManager.JobInfo.References.Add(info);

                    JobApplicationReference item = new JobApplicationReference()
                    {
                        Name = FindViewById<EditText>(Resource.Id.etName2).Text,
                        Occupation = FindViewById<EditText>(Resource.Id.etOccupation2).Text,
                        YearsKnown = yearsKnown,
                        Address = FindViewById<EditText>(Resource.Id.etAddress2).Text,
                        Employer = FindViewById<EditText>(Resource.Id.etEmployer2).Text,
                        MobileNumber = FindViewById<EditText>(Resource.Id.etMobileNumber2).Text,
                        HomeNumber = FindViewById<EditText>(Resource.Id.etHomeNumber2).Text,
                        OfficeNumber = FindViewById<EditText>(Resource.Id.etOfficeNumber2).Text
                    };
                    Database.UpdateReference(item);
                }
            }

            Finish();
        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etName1).Text) && string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etName2).Text))
            {
                Finish();
                return false;
            }

            if (FindViewById<EditText>(Resource.Id.etName1).Text == FindViewById<EditText>(Resource.Id.etName2).Text)
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                alert.SetMessage(this.Resources.GetString(Resource.String.ReferenceConfirmation));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.Yes), (senderAlert, args) =>
                {
                    Finish();
                });
                alert.SetNegativeButton(this.Resources.GetString(Resource.String.No), (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return true;
            }
            return true;
        }
    }
}