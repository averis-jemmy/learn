using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using Android.Animation;
using MyAverisEntity;
using MyAverisCommon;

namespace MyAa.Droid
{
    [Activity(Label = "RemunerationActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class RemunerationActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.Remuneration);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.RemunerationTitle);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            if (CacheManager.JobInfo != null && CacheManager.JobInfo.PackageDetail != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            try
            {
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.BaseSalary))
                        FindViewById<EditText>(Resource.Id.etBaseSalary).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.BaseSalary);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.ExpectedSalary))
                        FindViewById<EditText>(Resource.Id.etExpectedSalary).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.ExpectedSalary);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.FixedBonus))
                        FindViewById<EditText>(Resource.Id.etFixedBonus).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.FixedBonus);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.FixedAllowance))
                        FindViewById<EditText>(Resource.Id.etFixedAllowance).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.FixedAllowance);
                }
                catch { }

                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.OtherBenefit))
                        FindViewById<EditText>(Resource.Id.etOtherBenefit).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.OtherBenefit);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.NoticePeriod))
                        FindViewById<EditText>(Resource.Id.etNoticePeriod).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.NoticePeriod);
                }
                catch { }
            }
            catch { }
        }

        private void LockData()
        {
            FindViewById<EditText>(Resource.Id.etBaseSalary).Enabled = false;
            FindViewById<EditText>(Resource.Id.etExpectedSalary).Enabled = false;
            FindViewById<EditText>(Resource.Id.etFixedBonus).Enabled = false;
            FindViewById<EditText>(Resource.Id.etFixedAllowance).Enabled = false;
            FindViewById<EditText>(Resource.Id.etOtherBenefit).Enabled = false;
            FindViewById<EditText>(Resource.Id.etNoticePeriod).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                if (CacheManager.JobInfo.PackageDetail == null)
                    CacheManager.JobInfo.PackageDetail = new JobApplicationPackageDetailInfo();

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etBaseSalary).Text);
                    CacheManager.JobInfo.PackageDetail.BaseSalary = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etBaseSalary).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.BaseSalary = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etExpectedSalary).Text);
                    CacheManager.JobInfo.PackageDetail.ExpectedSalary = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etExpectedSalary).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.ExpectedSalary = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etFixedBonus).Text);
                    CacheManager.JobInfo.PackageDetail.FixedBonus = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etFixedBonus).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.FixedBonus = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etFixedAllowance).Text);
                    CacheManager.JobInfo.PackageDetail.FixedAllowance = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etFixedAllowance).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.FixedAllowance = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etOtherBenefit).Text);
                    CacheManager.JobInfo.PackageDetail.OtherBenefit = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etOtherBenefit).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.OtherBenefit = string.Empty;
                }

                CacheManager.JobInfo.PackageDetail.NoticePeriod = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etNoticePeriod).Text);

                JobApplicationPackageDetail model = new JobApplicationPackageDetail()
                {
                    BaseSalary = CacheManager.JobInfo.PackageDetail.BaseSalary,
                    ExpectedSalary = CacheManager.JobInfo.PackageDetail.ExpectedSalary,
                    FixedBonus = CacheManager.JobInfo.PackageDetail.FixedBonus,
                    FixedAllowance = CacheManager.JobInfo.PackageDetail.FixedAllowance,
                    OtherBenefit = CacheManager.JobInfo.PackageDetail.OtherBenefit,
                    NoticePeriod = CacheManager.JobInfo.PackageDetail.NoticePeriod
                };

                Database.UpdatePackageDetail(model);
            }

            Finish();
        }

        private bool ValidateData()
        {
            return true;
        }
    }
}