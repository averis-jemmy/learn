using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System.ComponentModel;
using MyAverisClient;
using MyAverisEntity;
using Newtonsoft.Json;

namespace MyAa.Droid
{
    [Activity(Label = "ApplicationListFragment")]
    public class ApplicationListFragment : Fragment
    {
        ProgressDialog _processProgress;
        String strResult;
        ListView listView;
        EditText etSearchText;
        CustomApplicationList adapter;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            _processProgress = new ProgressDialog(this.Activity);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);

            CacheManager.ProcessProgress = new ProgressDialog(this.Activity);
            CacheManager.ProcessProgress.Indeterminate = true;
            CacheManager.ProcessProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            CacheManager.ProcessProgress.SetMessage("Loading...");
            CacheManager.ProcessProgress.SetCancelable(false);
        }

        public override void OnResume()
        {
            base.OnResume();

            CacheManager.JobApplicationInfos = new List<ShortJobApplicationInfo>();
            adapter = new CustomApplicationList(this.Activity, CacheManager.JobApplicationInfos);
            listView.Adapter = adapter;

            _processProgress.Show();

            try
            {
                etSearchText.Text = string.Empty;
            }
            catch { }

            BackgroundWorker refreshWorker = new BackgroundWorker();
            refreshWorker.DoWork += refreshWorker_DoWork;
            refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
            refreshWorker.RunWorkerAsync();
        }

        public override void OnPause()
        {
            base.OnPause();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.ApplicationListFragment, container, false);
            listView = view.FindViewById<ListView>(Resource.Id.listJob); // get reference to the ListView in the layout
            // populate the listview with data
            adapter = new CustomApplicationList(this.Activity, CacheManager.JobApplicationInfos);
            listView.Adapter = adapter;

            listView.ItemClick += OnListItemClick;  // to be defined

            etSearchText = view.FindViewById<EditText>(Resource.Id.etSearchText);
            etSearchText.TextChanged += OnSearchTextChanged;

            return view;
        }

        void OnSearchTextChanged(object sender, Android.Text.TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(etSearchText.Text))
            {
                try
                {
                    var infos = (from item in CacheManager.JobApplicationInfos
                                 where (item.FullName != null && item.FullName.ToLower().Contains(etSearchText.Text.ToLower())) ||
                                 (item.PositionApplied != null && item.PositionApplied.ToLower().Contains(etSearchText.Text.ToLower()))
                                 select item).ToList();
                    adapter = new CustomApplicationList(this.Activity, infos);
                    listView.Adapter = adapter;
                }
                catch { }
            }
            else
            {
                adapter = new CustomApplicationList(this.Activity, CacheManager.JobApplicationInfos);
                listView.Adapter = adapter;
            }
            //adapter.Filter.InvokeFilter(etSearchText.Text);
        }

        void OnListItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            CacheManager.JobID = CacheManager.JobApplicationInfos[e.Position].ID;
            CacheManager.PositionApplied = CacheManager.JobApplicationInfos[e.Position].PositionApplied;

            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += worker_DoWork;
            worker.RunWorkerCompleted += worker_RunWorkerCompleted;
            worker.RunWorkerAsync();
        }

        void refreshWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));
            headers.Add(new KeyValuePair<string, string>("ApplicationType", CacheManager.ApplicationType));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetAllJobApplications", headers);
        }

        void refreshWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this.Activity, typeof(MainActivity));
                            StartActivity(intent);
                            this.Activity.FinishAffinity();
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.FailRefresh));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        List<ShortJobApplicationInfo> infos = JsonConvert.DeserializeObject<List<ShortJobApplicationInfo>>(strResult);
                        if (infos != null && infos.Count > 0)
                        {
                            CacheManager.JobApplicationInfos = infos;
                            adapter = new CustomApplicationList(this.Activity, CacheManager.JobApplicationInfos);
                            listView.Adapter = adapter;
                        }
                        else
                        {
                            adapter = new CustomApplicationList(this.Activity, CacheManager.JobApplicationInfos);
                            listView.Adapter = adapter;

                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                            alert.SetTitle(this.Resources.GetString(Resource.String.Info));
                            alert.SetMessage(this.Resources.GetString(Resource.String.NoPending));
                            alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                            {
                            });

                            this.Activity.RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                        }
                    }
                }
                else
                {
                    Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                    alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                    alert.SetMessage(this.Resources.GetString(Resource.String.FailRefresh));
                    alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                    {
                    });

                    this.Activity.RunOnUiThread(() =>
                    {
                        alert.Show();
                    });
                }
            }
            catch
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                alert.SetMessage(this.Resources.GetString(Resource.String.FailRefresh));
                alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                {
                });

                this.Activity.RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }

            try
            {
                _processProgress.Dismiss();
            }
            catch { }
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.JobID.ToString() + "\"");
            strResult = client.ProcessRequest("GetJobApplication", headers);
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        try
                        {
                            CacheManager.ProcessProgress.Dismiss();
                        }
                        catch { }
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this.Activity, typeof(MainActivity));
                            StartActivity(intent);
                            this.Activity.FinishAffinity();
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        try
                        {
                            CacheManager.ProcessProgress.Dismiss();
                        }
                        catch { }
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.FailRefresh));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        JobApplicationInfo info = null;
                        try
                        {
                            info = JsonConvert.DeserializeObject<JobApplicationInfo>(strResult);
                        }
                        catch { }

                        if (info != null)
                        {
                            CacheManager.JobInfo = info;
                            var intent = new Intent(this.Activity, typeof(JobApplicationDisplayActivity));
                            StartActivity(intent);
                        }
                        else
                        {
                            try
                            {
                                CacheManager.ProcessProgress.Dismiss();
                            }
                            catch { }
                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                            alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                            alert.SetMessage(this.Resources.GetString(Resource.String.FailRefresh));
                            alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                            {
                            });

                            this.Activity.RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                        }
                    }
                }
                else
                {
                    try
                    {
                        CacheManager.ProcessProgress.Dismiss();
                    }
                    catch { }
                }
            }
            catch
            {
                try
                {
                    CacheManager.ProcessProgress.Dismiss();
                }
                catch { }
            }
        }
    }
}