using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using System.ComponentModel;
using MyAverisClient;
using MyAverisEntity;
using Newtonsoft.Json;
using Android.Support.V7.App;
using Square.Picasso;
using Square.OkHttp;

namespace MyAa.Droid
{
    [Activity(Label = "PhotoListActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class PhotoListActivity : AppCompatActivity
    {
        ProgressDialog _processProgress;
        String strResult;
        PhotoGridViewAdapter adapter;
        GridView gv;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            CacheManager.RestoreData();
            CacheManager.InitLanguage(this);

            SetContentView(Resource.Layout.PhotoList);

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Photo);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            gv = FindViewById<GridView>(Resource.Id.grid_view);
            gv.ScrollStateChanged += (sender, e) =>
            {
                //Picasso picasso = new Picasso.Builder(this)
                //        .Downloader(new OkHttpDownloader(UnsafeOkHttpClient.GetUnsafeOkHttpClient()))
                //        .Build();

                Picasso picasso = Picasso.With(this);
                if (e.ScrollState == ScrollState.Idle || e.ScrollState == ScrollState.TouchScroll)
                {
                    picasso.ResumeTag(this);
                }
                else
                {
                    picasso.PauseTag(this);
                }
            };
            gv.ItemClick += GridView_ItemClick;

            RegisterForContextMenu(gv);

            _processProgress = new ProgressDialog(this);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);

            _processProgress.Show();

            BackgroundWorker refreshWorker = new BackgroundWorker();
            refreshWorker.DoWork += refreshWorker_DoWork;
            refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
            refreshWorker.RunWorkerAsync();
        }

        public override void OnCreateContextMenu(IContextMenu menu, View v, IContextMenuContextMenuInfo menuInfo)
        {
            if (v.Id == Resource.Id.grid_view)
            {
                if (CacheManager.IsRecruiter)
                {
                    try
                    {
                        CacheManager.PhotoAdapterPosition = ((Android.Widget.AdapterView.AdapterContextMenuInfo)menuInfo).Position;
                        CacheManager.PhotoID = adapter[((Android.Widget.AdapterView.AdapterContextMenuInfo)menuInfo).Position].ID;
                    }
                    catch { }
                    var info = (AdapterView.AdapterContextMenuInfo)menuInfo;
                    var menuItems = Resources.GetStringArray(Resource.Array.Menu);
                    for (var i = 0; i < menuItems.Length; i++)
                        menu.Add(Menu.None, i, i, menuItems[i]);
                }
            }
        }

        public override bool OnContextItemSelected(IMenuItem item)
        {
            var info = (AdapterView.AdapterContextMenuInfo)item.MenuInfo;
            var menuItemIndex = item.ItemId;
            var menuItems = Resources.GetStringArray(Resource.Array.Menu);
            var menuItemName = menuItems[menuItemIndex];

            switch(menuItemName)
            {
                case "Open":
                    var intent = new Intent(this, typeof(PhotoViewPagerActivity));
                    StartActivity(intent);
                    break;
                case "Delete":
                    _processProgress.Show();

                    BackgroundWorker deleteWorker = new BackgroundWorker();
                    deleteWorker.DoWork += deleteWorker_DoWork;
                    deleteWorker.RunWorkerCompleted += deleteWorker_RunWorkerCompleted;
                    deleteWorker.RunWorkerAsync();
                    break;
                default:
                    break;
            }

            return true;
        }

        void deleteWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.PhotoID.ToString() + "\"");
            strResult = client.ProcessRequest("DeletePhoto", headers);
        }

        void deleteWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    try { _processProgress.Dismiss(); }
                    catch { }

                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.FailDelete));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                        return;
                    }
                }
            }
            catch { }

            BackgroundWorker refreshWorker = new BackgroundWorker();
            refreshWorker.DoWork += refreshWorker_DoWork;
            refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
            refreshWorker.RunWorkerAsync();
        }

        void GridView_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            CacheManager.PhotoAdapterPosition = e.Position;
            var intent = new Intent(this, typeof(PhotoViewPagerActivity));
            StartActivity(intent);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        void refreshWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.Category + "\"");
            strResult = client.ProcessRequest("GetPhotoFromCategory", headers);
        }

        void refreshWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.SessionExpired));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle(this.Resources.GetString(Resource.String.Error));
                        alert.SetMessage(this.Resources.GetString(Resource.String.FailRefresh));
                        alert.SetPositiveButton(this.Resources.GetString(Resource.String.OK), (senderAlert, args) =>
                        {
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        List<PhotoInfo> infos = JsonConvert.DeserializeObject<List<PhotoInfo>>(strResult);
                        var photos = (from item in infos
                                      select new PhotoInfo()
                                      {
                                          ID = item.ID,
                                          Name = item.Name,
                                          Category = item.Category,
                                          FilePath = CacheManager.ImageURL + item.FilePath
                                      }).ToList();

                        CacheManager.Photos = photos;
                        adapter = new PhotoGridViewAdapter(this, photos);
                        gv.Adapter = adapter;
                    }
                }
            }
            catch { }
            try { _processProgress.Dismiss(); }
            catch { }
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        protected override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }
    }
}