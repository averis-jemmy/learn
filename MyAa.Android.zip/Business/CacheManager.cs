using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MyAverisEntity;
using Android.Graphics;
using Android.Gms.Maps.Model;
using Android.Preferences;
using MyAverisCommon;
using Android.Content.Res;
using Java.Util;

namespace MyAa.Droid
{
    public static class CacheManager
    {
        public static string AppLanguage;
        public static string PackageName;
        public static int VersionNumber;
        public static JobApplicationInfo JobInfo;
        public static JobApplicationFamilyInfo FamilyInfo;
        public static int FamilyPosition;
        public static JobApplicationEducationInfo EducationInfo;
        public static int EducationPosition;
        public static JobApplicationLanguageInfo LanguageInfo;
        public static int LanguagePosition;
        public static JobApplicationWorkingHistoryInfo WorkingHistoryInfo;
        public static int WorkingHistoryPosition;
        public static JobApplicationActivityInfo ActivityInfo;
        public static int ActivityPosition;
        public static int JobApplicationID;
        private static string MainURL = "https://m-dev.averis.biz/";
        public static string URL = MainURL + "MyAverisServiceHttps/AverisMobile.svc/";
        public static string ImageURL = MainURL + "MyAverisServiceHttps/images/";
        public static string ProfileURL = MainURL + "MyAverisServiceHttps/images/profile/";
        public static string ApplicationType = "MyAA";
        public static Context mContext;
        public static string PhoneNumber;
        public static Guid UserID;
        public static Guid TokenID;
        public static Guid JobID;
        public static Guid VideoID;
        public static Guid PhotoID;
        public static string DeviceToken;
        public static bool IsRecruiter;
        public static bool HasProfilePicture;
        public static string PositionApplied;
        public static bool IsLocked = false;
        public static List<ShortJobApplicationInfo> JobApplicationInfos = new List<ShortJobApplicationInfo>();
        public static Bitmap ImageProf;
        public static string Category;
        public static string VideoCode;
        public static List<PhotoInfo> Photos;
        public static List<VideoInfo> Videos;
        public static int PhotoAdapterPosition = 0;
        public static Bitmap ProfileBitmap;
        public static bool ReturnFromCamera = false;
        public static bool FromNotification = false;
        public static LatLng AACoordinate = new LatLng(3.111784, 101.667185);

        public static ProgressDialog ProcessProgress;

        public const string DeveloperKey = "AIzaSyDOzdyJZYgGMfx0QKQeomz45vlJaCNiyX8";

        public static void Init(Context context)
        {
            mContext = context;

            try
            {
                PackageName = context.PackageName;
                VersionNumber = context.PackageManager.GetPackageInfo(context.PackageName, 0).VersionCode;
            }
            catch { }
        }

        public static void InitLanguage(Context context)
        {
            try
            {
                Configuration config = context.Resources.Configuration;
                if (Database.GetAppLanguage() == "Bahasa Indonesia")
                {
                    config.Locale = new Locale("in", "ID");
                    context.CreateConfigurationContext(config);
                }
                else
                {
                    config.Locale = Locale.English;
                    context.CreateConfigurationContext(config);
                }
            }
            catch { }
        }

        public static void RestoreData()
        {
            try
            {
                if (CacheManager.mContext == null)
                {
                    Database.newInstance(System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaa.db3"));
                    Database.CreateTables();

                    if (string.IsNullOrEmpty(Database.GetAppLanguage()))
                        Database.UpdateSettings("English");

                    Init(Application.Context);

                    var user = GetFromSharedPreferences();

                    TokenID = user.TokenID;
                    UserID = user.UserID;
                    IsRecruiter = user.IsRecruiter;
                    HasProfilePicture = user.HasProfilePicture;
                    PositionApplied = user.PositionApplied;
                    LoadData();

                    AppLanguage = Database.GetAppLanguage();
                }
            }
            catch { }
        }

        public static void LoadData()
        {
            try
            {
                Database.newInstance(System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaa.db3"));
                Database.CreateTables();

                #region Load Data
                JobApplication jobApp = Database.GetJobApplication();
                if (jobApp != null)
                {
                    JobApplicationID = jobApp.ID;
                    IsLocked = jobApp.IsLocked;
                    JobInfo = new JobApplicationInfo()
                    {
                        Photo = jobApp.Photo,
                        Title = jobApp.Title,
                        FirstName = jobApp.FirstName,
                        LastName = jobApp.LastName,
                        KnownAs = jobApp.KnownAs,
                        ChineseCharacter = jobApp.ChineseCharacter,
                        Gender = jobApp.Gender,
                        DateOfBirth = jobApp.DateOfBirth,
                        PlaceOfBirth = jobApp.PlaceOfBirth,
                        CountryOfBirth = jobApp.CountryOfBirth,
                        Nationality = jobApp.Nationality,
                        Race = jobApp.Race,
                        MaritalStatus = jobApp.MaritalStatus,
                        Religion = jobApp.Religion,
                        IdentityNo = jobApp.IdentityNo,
                        IsPassport = jobApp.IsPassport,
                        DateOfIssue = jobApp.DateOfIssue,
                        DateOfExpiry = jobApp.DateOfExpiry,
                        PlaceOfIssue = jobApp.PlaceOfIssue,
                        CountryOfIssue = jobApp.CountryOfIssue,
                        EmailAddress = jobApp.EmailAddress,
                        EmergencyContact = jobApp.EmergencyContact,
                        ServiceCompleted = jobApp.ServiceCompleted,
                        HighestRankAttained = jobApp.HighestRankAttained,
                        ExemptionReason = jobApp.ExemptionReason,
                        LiabilityForDuties = jobApp.LiabilityForDuties,
                        ApplicationStatus = jobApp.ApplicationStatus,
                        IsLocked = jobApp.IsLocked
                    };
                }

                JobApplicationAddress current = Database.GetAddress(InitialData.AddressType.CurrentAddress);
                if (current != null && JobInfo != null)
                {
                    JobInfo.CurrentAddress = new JobApplicationAddressInfo()
                    {
                        AddressType = current.AddressType,
                        Address = current.Address,
                        PostalCode = current.PostalCode,
                        Country = current.Country,
                        HomeNumber = current.HomeNumber,
                        MobileNumber = current.MobileNumber
                    };
                }

                JobApplicationAddress home = Database.GetAddress(InitialData.AddressType.HomeAddress);
                if (home != null && JobInfo != null)
                {
                    JobInfo.HomeAddress = new JobApplicationAddressInfo()
                    {
                        AddressType = home.AddressType,
                        Address = home.Address,
                        PostalCode = home.PostalCode,
                        Country = home.Country,
                        HomeNumber = home.HomeNumber,
                        MobileNumber = home.MobileNumber
                    };
                }

                JobApplicationAddress emergency = Database.GetAddress(InitialData.AddressType.EmergencyAddress);
                if (emergency != null && JobInfo != null)
                {
                    JobInfo.EmergencyAddress = new JobApplicationAddressInfo()
                    {
                        AddressType = emergency.AddressType,
                        Address = emergency.Address,
                        PostalCode = emergency.PostalCode,
                        Country = emergency.Country,
                        HomeNumber = emergency.HomeNumber,
                        MobileNumber = emergency.MobileNumber
                    };
                }

                List<JobApplicationFamily> families = Database.GetFamilies();
                if (families != null && families.Count > 0)
                {
                    JobInfo.Families = new List<JobApplicationFamilyInfo>();
                    foreach (JobApplicationFamily item in families)
                    {
                        JobInfo.Families.Add(new JobApplicationFamilyInfo()
                        {
                            UID = item.ID,
                            FirstName = item.FirstName,
                            LastName = item.LastName,
                            Relationship = item.Relationship,
                            IdentityNo = item.IdentityNo,
                            JobTitle = item.JobTitle,
                            Employer = item.Employer,
                            Gender = item.Gender,
                            DateOfBirth = item.DateOfBirth,
                            Nationality = item.Nationality,
                            CountryOfBirth = item.CountryOfBirth,
                            IsSameCountry = item.IsSameCountry
                        });
                    }
                }

                List<JobApplicationEducation> educations = Database.GetEducations();
                if (educations != null && educations.Count > 0)
                {
                    JobInfo.Educations = new List<JobApplicationEducationInfo>();
                    foreach (JobApplicationEducation item in educations)
                    {
                        JobInfo.Educations.Add(new JobApplicationEducationInfo()
                        {
                            UID = item.ID,
                            Institution = item.Institution,
                            CourseOfStudy = item.CourseOfStudy,
                            Country = item.Country,
                            StartDate = item.StartDate,
                            EndDate = item.EndDate,
                            Qualification = item.Qualification
                        });
                    }
                }

                List<JobApplicationLanguage> languages = Database.GetLanguages();
                if (languages != null && languages.Count > 0)
                {
                    JobInfo.Languages = new List<JobApplicationLanguageInfo>();
                    foreach (JobApplicationLanguage item in languages)
                    {
                        JobInfo.Languages.Add(new JobApplicationLanguageInfo()
                        {
                            UID = item.ID,
                            Language = item.Language,
                            SpeakAbility = item.SpeakAbility,
                            ReadAbility = item.ReadAbility,
                            WriteAbility = item.WriteAbility
                        });
                    }
                }

                List<JobApplicationWorkingHistory> workingHistories = Database.GetWorkingHistories();
                if (workingHistories != null && workingHistories.Count > 0)
                {
                    JobInfo.WorkingHistories = new List<JobApplicationWorkingHistoryInfo>();
                    foreach (JobApplicationWorkingHistory item in workingHistories)
                    {
                        JobInfo.WorkingHistories.Add(new JobApplicationWorkingHistoryInfo()
                        {
                            UID = item.ID,
                            Company = item.Company,
                            LastPositionHeld = item.LastPositionHeld,
                            Country = item.Country,
                            StartDate = item.StartDate,
                            EndDate = item.EndDate,
                            NameOfSuperior = item.NameOfSuperior,
                            DesignationOfSuperior = item.DesignationOfSuperior,
                            LastDrawnSalary = item.LastDrawnSalary,
                            ReasonForLeaving = item.ReasonForLeaving
                        });
                    }
                }

                List<JobApplicationActivity> activities = Database.GetActivities();
                if (activities != null && activities.Count > 0)
                {
                    JobInfo.Activities = new List<JobApplicationActivityInfo>();
                    foreach (JobApplicationActivity item in activities)
                    {
                        JobInfo.Activities.Add(new JobApplicationActivityInfo()
                        {
                            UID = item.ID,
                            Organisation = item.Organisation,
                            NatureOfActivities = item.NatureOfActivities,
                            Country = item.Country,
                            FromDate = item.FromDate,
                            ToDate = item.ToDate
                        });
                    }
                }

                List<JobApplicationReference> references = Database.GetReferences();
                if (references != null && references.Count > 0)
                {
                    JobInfo.References = new List<JobApplicationReferenceInfo>();
                    foreach (JobApplicationReference item in references)
                    {
                        JobInfo.References.Add(new JobApplicationReferenceInfo()
                        {
                            Name = item.Name,
                            Occupation = item.Occupation,
                            YearsKnown = item.YearsKnown,
                            Address = item.Address,
                            Employer = item.Employer,
                            MobileNumber = item.MobileNumber,
                            HomeNumber = item.HomeNumber,
                            OfficeNumber = item.OfficeNumber
                        });
                    }
                }

                List<JobApplicationDeclaration> declarations = Database.GetDeclarations();
                if (declarations != null && declarations.Count > 0)
                {
                    JobInfo.Declarations = new List<JobApplicationDeclarationInfo>();
                    foreach (JobApplicationDeclaration item in declarations)
                    {
                        JobInfo.Declarations.Add(new JobApplicationDeclarationInfo()
                        {
                            DeclarationID = item.DeclarationID,
                            Answer = item.Answer,
                            Remarks = item.Remarks
                        });
                    }
                }

                JobApplicationPackageDetail detail = Database.GetPackageDetail();
                if (detail != null)
                {
                    JobInfo.PackageDetail = new JobApplicationPackageDetailInfo()
                    {
                        BaseSalary = detail.BaseSalary,
                        ExpectedSalary = detail.ExpectedSalary,
                        ContractualBonus = detail.ContractualBonus,
                        PerformanceBonus = detail.PerformanceBonus,
                        HousingAllowance = detail.HousingAllowance,
                        TransportAllowance = detail.TransportAllowance,
                        ConnectivityAllowance = detail.ConnectivityAllowance,
                        ProjectAlowance = detail.ProjectAlowance,
                        SpecialSkillsAllowance = detail.SpecialSkillsAllowance,
                        CarParkAllowance = detail.CarParkAllowance,
                        CarParkClaim = detail.CarParkClaim,
                        PhoneClaim = detail.PhoneClaim,
                        MileageClaim = detail.MileageClaim,
                        MealClaim = detail.MealClaim,
                        OvertimeClaim = detail.OvertimeClaim,
                        StandbyClaim = detail.StandbyClaim,
                        SelfMedicalBenefit = detail.SelfMedicalBenefit,
                        FamilyMedicalBenefit = detail.FamilyMedicalBenefit,
                        SelfInsuranceBenefit = detail.SelfInsuranceBenefit,
                        FamilyInsuranceBenefit = detail.FamilyInsuranceBenefit,
                        OpticalBenefit = detail.OpticalBenefit,
                        DentalBenefit = detail.DentalBenefit,
                        AnnualLeave = detail.AnnualLeave,
                        MedicalLeave = detail.MedicalLeave,
                        RetirementBenefit = detail.RetirementBenefit,
                        EPFNumber = detail.EPFNumber,
                        SOCSONumber = detail.SOCSONumber,
                        IncomeTaxNumber = detail.IncomeTaxNumber,
                        BankAccountNumber = detail.BankAccountNumber,
                        FixedBonus = detail.FixedBonus,
                        FixedAllowance = detail.FixedAllowance,
                        OtherBenefit = detail.OtherBenefit,
                        NoticePeriod = detail.NoticePeriod
                    };
                }

                JobApplicationAdditional additional = Database.GetAdditional();
                if (additional != null)
                {
                    JobInfo.Additional = new JobApplicationAdditionalInfo()
                    {
                        ReferenceCheck = additional.ReferenceCheck,
                        ReferenceRemarks = additional.ReferenceRemarks,
                        DateAvailable = additional.DateAvailable,
                        CanTravel = additional.CanTravel,
                        CanRelocate = additional.CanRelocate,
                        ReasonForJoining = additional.ReasonForJoining,
                        CareerObjective = additional.CareerObjective,
                        Recommendation = additional.Recommendation,
                        KnowingCompany = additional.KnowingCompany
                    };
                }
                #endregion
            }
            catch { }
        }

        public static void SaveIntoSharedPreferences(UserInfo info, string token)
        {
            var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(mContext);
            try
            {
                sharedPreferences.Edit().PutString(QuickstartPreferences.USER_ID, info.UserID.ToString()).Apply();
                sharedPreferences.Edit().PutString(QuickstartPreferences.TOKEN_ID, info.TokenID.ToString()).Apply();
                sharedPreferences.Edit().PutString(QuickstartPreferences.EMAIL_ADDRESS, info.Email).Apply();
                sharedPreferences.Edit().PutString(QuickstartPreferences.USER_NAME, info.UserName).Apply();
                sharedPreferences.Edit().PutString(QuickstartPreferences.PHONE_NUMBER, info.PhoneNumber).Apply();
                sharedPreferences.Edit().PutString(QuickstartPreferences.DEVICE_TYPE, InitialData.DeviceType.Android).Apply();
                sharedPreferences.Edit().PutString(QuickstartPreferences.DEVICE_TOKEN, token).Apply();
                sharedPreferences.Edit().PutBoolean(QuickstartPreferences.IS_RECRUITER, info.IsRecruiter).Apply();
                sharedPreferences.Edit().PutString(QuickstartPreferences.POSITION_APPLIED, info.PositionApplied).Apply();
                sharedPreferences.Edit().PutBoolean(QuickstartPreferences.HAS_PROFILE_PICTURE, info.HasProfilePicture.GetValueOrDefault()).Apply();
            }
            catch { }
        }

        public static User GetFromSharedPreferences()
        {
            var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(mContext);
            try
            {
                var user = new User();
                user.UserID = Guid.Parse(sharedPreferences.GetString(QuickstartPreferences.USER_ID, string.Empty));
                user.TokenID = Guid.Parse(sharedPreferences.GetString(QuickstartPreferences.TOKEN_ID, string.Empty));
                user.EmailAddress = sharedPreferences.GetString(QuickstartPreferences.EMAIL_ADDRESS, string.Empty);
                user.Name = sharedPreferences.GetString(QuickstartPreferences.USER_NAME, string.Empty);
                user.PhoneNumber = sharedPreferences.GetString(QuickstartPreferences.PHONE_NUMBER, string.Empty);
                user.DeviceType = sharedPreferences.GetString(QuickstartPreferences.DEVICE_TYPE, string.Empty);
                user.DeviceToken = sharedPreferences.GetString(QuickstartPreferences.DEVICE_TOKEN, string.Empty);
                user.IsRecruiter = sharedPreferences.GetBoolean(QuickstartPreferences.IS_RECRUITER, false);
                user.PositionApplied = sharedPreferences.GetString(QuickstartPreferences.POSITION_APPLIED, string.Empty);
                user.HasProfilePicture = sharedPreferences.GetBoolean(QuickstartPreferences.HAS_PROFILE_PICTURE, false);

                return user;
            }
            catch { }
            return null;
        }

        public static void ClearSharedPreferences()
        {
            var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(mContext);
            try
            {
                UserID = Guid.Empty;
                TokenID = Guid.Empty;
                IsRecruiter = false;
                HasProfilePicture = false;
                PositionApplied = string.Empty;
                sharedPreferences.Edit().Clear().Apply();
            }
            catch { }
        }

        public static KeyValuePair<string, string> GetOfficeDetail(string officeCode)
        {
            KeyValuePair<string, string> model = new KeyValuePair<string, string>();

            switch (officeCode)
            {
                case "Medan":
                    model = new KeyValuePair<string, string>("Uniplaza Building 6th Floor, East Tower.\nJl. Let. Jend. Haryono MT No A-1 Medan 20231 Sumatra Utara, Indonesia", "+62 61 4532 155/388/532");
                    break;
                case "Pekanbaru":
                    model = new KeyValuePair<string, string>("Jl. Soekarno Hatta No 7-10 Kel. Sidomulyo Timur, Kec. Marpoyan Damai, Pekanbaru 28125 Riau, Indonesia", "+62 761 8399 13/14/15");
                    break;
                case "Jakarta":
                    model = new KeyValuePair<string, string>("RGE Office Complex.\nJl. M.H. Thamrin No 31 Jakarta 10230 Jakarta Pusat, Indonesia", "+62 21 2301 119");
                    break;
                case "Jambi":
                    model = new KeyValuePair<string, string>("Jl.Kol. H. Yunus Sanis No 12C Kel. Kebun Handil, Kec. Jelutung, Jambi 36137 Jambi, Indonesia", "+62 741 4443 57");
                    break;
                default:
                    break;
            }

            return model;
        }
    }
}