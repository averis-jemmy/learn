﻿using System;

namespace MyAa.Droid
{
    public static class QuickstartPreferences
    {
        public const string APP_VERSION = "appVersion";
        public const string SENT_TOKEN_TO_SERVER = "sentTokenToServer";
        public const string REGISTRATION_COMPLETE = "registrationComplete";
        public const string USER_ID = "userId";
        public const string USER_NAME = "userName";
        public const string EMAIL_ADDRESS = "emailAddress";
        public const string PHONE_NUMBER = "phoneNumber";
        public const string TOKEN_ID = "tokenId";
        public const string IS_RECRUITER = "isRecruiter";
        public const string DEVICE_TYPE = "deviceType";
        public const string HAS_PROFILE_PICTURE = "hasProfilePicture";
        public const string POSITION_APPLIED = "positionApplied";
        public const string DEVICE_TOKEN = "deviceToken";
    }
}