using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MyAverisEntity;
using Android.Graphics;
using Java.Security.Cert;
using Javax.Net.Ssl;
using Square.OkHttp;

namespace MyAa.Droid
{
    public class UnsafeOkHttpClient
    {
        public static OkHttpClient GetUnsafeOkHttpClient()
        {
            try
            {
                // Install the all-trusting trust manager
                ITrustManager[] trustManager = new ITrustManager[] { new MyTrustManager() };
                SSLContext sslContext = SSLContext.GetInstance("TLS");
                sslContext.Init(null, trustManager, new Java.Security.SecureRandom());

                // Create an ssl socket factory with our all-trusting manager
                SSLSocketFactory sslSocketFactory = sslContext.SocketFactory;

                OkHttpClient okHttpClient = new OkHttpClient();
                okHttpClient.SetSslSocketFactory(sslSocketFactory);
                okHttpClient.SetProtocols(new List<Protocol>() {Square.OkHttp.Protocol.Http11 });
                okHttpClient.SetHostnameVerifier(new MyHostnameVerifier());

                return okHttpClient;
            }
            catch (Exception e)
            {
            }

            return null;
        }

        class MyTrustManager : Java.Lang.Object, IX509TrustManager
        {
            public void CheckClientTrusted(X509Certificate[] chain, string authType) { }
            public void CheckServerTrusted(X509Certificate[] chain, string authType) { }
            public X509Certificate[] GetAcceptedIssuers() { return null; }
        }

        class MyHostnameVerifier : Java.Lang.Object, IHostnameVerifier
        {
            public bool Verify(string hostname, ISSLSession session) { return true; }
        }
    }
}