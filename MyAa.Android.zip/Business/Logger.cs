using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System.IO;

namespace MyAa.Droid
{
    public static class Logger
    {
        public static void Log(string title, string message)
        {
            try
            {
                StreamWriter writer = new StreamWriter(System.IO.Path.Combine(Android.OS.Environment.ExternalStorageDirectory.AbsolutePath, "log.txt"), true);
                writer.WriteLine(title + "\t" + message);
                writer.Flush();
                writer.Close();
            }
            catch { }
        }
    }
}