using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MyAverisEntity;
using Android.Graphics;
using System.Net;

namespace MyAa.Droid
{
    public class VideosList : BaseAdapter<VideoInfo>
    {
        List<VideoInfo> items;
        Activity context;
        public VideosList(Activity context, List<VideoInfo> items)
            : base()
        {
            this.context = context;
            this.items = items;
        }
        public override long GetItemId(int position)
        {
            return position;
        }
        public override VideoInfo this[int position]
        {
            get { return items[position]; }
        }
        public override int Count
        {
            get { return items.Count; }
        }
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            var item = items[position];
            View view = convertView;
            if (view == null)
            {
                view = context.LayoutInflater.Inflate(Resource.Layout.CustomVideoList, null);
            }

            view.FindViewById<TextView>(Resource.Id.Text1).Text = item.Name;
            view.FindViewById<ImageView>(Resource.Id.Image1).SetImageBitmap(GetImageBitmapFromUrl("http://i3.ytimg.com/vi/" + item.VideoCode + "/default.jpg"));
            return view;
        }

        private Bitmap GetImageBitmapFromUrl(string url)
        {
             Bitmap imageBitmap = null;

             using (var webClient = new WebClient())
             {
                  var imageBytes = webClient.DownloadData(url);
                  if (imageBytes != null && imageBytes.Length > 0)
                  {
                       imageBitmap = BitmapFactory.DecodeByteArray(imageBytes, 0, imageBytes.Length);
                  }
             }

             return imageBitmap;
        }
    }
}