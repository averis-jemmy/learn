﻿using Android.App;
using Android.Preferences;
using Android.Gms.Gcm.Iid;
using Android;
using Android.Gms.Gcm;
using Android.Util;
using Android.Support.V4.Content;
using System;
using Android.Content;
using System.ComponentModel;
using MyAverisClient;
using System.Collections.Generic;


namespace MyAa.Droid
{
    [Service(Exported = false)]
    public class RegistrationIntentService : IntentService
    {
        const string TAG = "RegIntentService";
        static readonly string[] TOPICS = { "global", "averis" };
        string strResult = string.Empty;

        public RegistrationIntentService()
            : base(TAG)
        {
        }

        protected override void OnHandleIntent(Intent intent)
        {
            var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(this);
            int versionCode = 1;
            try
            {
                versionCode = PackageManager.GetPackageInfo(PackageName, 0).VersionCode;
            }
            catch { }
            try
            {
                lock (TAG)
                {
                    var instanceID = InstanceID.GetInstance(this);
                    try
                    {
                        if (versionCode.ToString() != sharedPreferences.GetString(QuickstartPreferences.APP_VERSION, string.Empty))
                        {
                            instanceID.DeleteInstanceID();
                            instanceID = InstanceID.GetInstance(this);
                            sharedPreferences.Edit().PutBoolean(QuickstartPreferences.SENT_TOKEN_TO_SERVER, false).Apply();
                        }
                        //instanceID.DeleteToken(GetString(Resource.String.gcm_defaultSenderId),
                        //GoogleCloudMessaging.InstanceIdScope);
                    }
                    catch { }

                    if (!sharedPreferences.GetBoolean(QuickstartPreferences.SENT_TOKEN_TO_SERVER, false))
                    {
                        var token = instanceID.GetToken(GetString(Resource.String.gcm_defaultSenderId),
                            GoogleCloudMessaging.InstanceIdScope, null);
                        Log.Info(TAG, "GCM Registration Token: " + token);
                        CacheManager.DeviceToken = token;
                        if (SendRegistrationToServer())
                        {
                            SubscribeTopics(token);
                            sharedPreferences.Edit().PutString(QuickstartPreferences.APP_VERSION, versionCode.ToString()).Apply();
                            sharedPreferences.Edit().PutBoolean(QuickstartPreferences.SENT_TOKEN_TO_SERVER, true).Apply();
                        }
                        else
                            sharedPreferences.Edit().PutBoolean(QuickstartPreferences.SENT_TOKEN_TO_SERVER, false).Apply();
                    }
                }
            }
            catch (Exception e)
            {
                Log.Debug(TAG, "Failed to complete token refresh", e);
                sharedPreferences.Edit().PutBoolean(QuickstartPreferences.SENT_TOKEN_TO_SERVER, false).Apply();
            }
            var registrationComplete = new Intent(QuickstartPreferences.REGISTRATION_COMPLETE);
            LocalBroadcastManager.GetInstance(this).SendBroadcast(registrationComplete);
        }

        bool SendRegistrationToServer()
        {
            string deviceToken = CacheManager.DeviceToken;

            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + deviceToken + "\"");
            strResult = client.ProcessRequest("UpdateDeviceToken", headers);

            var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(this);
            if (!string.IsNullOrEmpty(strResult))
                return false;
            else
            {
                Database.UpdateUserDeviceToken(CacheManager.DeviceToken);
                sharedPreferences.Edit().PutString(QuickstartPreferences.DEVICE_TOKEN, CacheManager.DeviceToken).Apply();
            }

            return true;
        }

        void SubscribeTopics(string token)
        {
            foreach (var topic in TOPICS)
            {
                var pubSub = GcmPubSub.GetInstance(this);
                pubSub.Subscribe(token, "/topics/" + topic, null);
            }
        }
    }
}